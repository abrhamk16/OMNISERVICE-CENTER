/* ============================================================
   seeker.js — the Service Seeker stream.
   Sidebar per spec: Home, About, Services, Map, AI Agent, Contact.
   ============================================================ */

const Seeker = {
  nav: [
    { key: 'home', label: 'Home', icon: '🏠' },
    { key: 'about', label: 'About', icon: 'ℹ️' },
    { key: 'services', label: 'Services', icon: '🧭' },
    { key: 'map', label: 'Map', icon: '🗺️' },
    { key: 'omni', label: 'AI Agent', icon: '✦' },
    { key: 'contact', label: 'Contact', icon: '✉️' }
  ],

  categories: [],
  chatLog: [],

  async mount(root, page = 'home') {
    if (!this.categories.length) this.categories = await API.categories().catch(() => []);
    Shell.render(root, {
      role: 'seeker',
      nav: this.nav,
      active: page,
      onNav: (key) => router.go('/seeker/' + key),
      title: (this.nav.find((n) => n.key === page) || this.nav[0]).label
    });
    this.renderPage(el('#page'), page);
  },

  renderPage(host, page) {
    const fn = {
      home: () => this.home(host),
      about: () => this.about(host),
      services: () => this.services(host),
      map: () => this.map(host),
      omni: () => this.omni(host),
      contact: () => this.contact(host)
    }[page];
    (fn || (() => this.home(host)))();
  },

  /* ---------------- HOME ---------------- */
  async home(host) {
    const user = Session.user;
    host.innerHTML = `
      <div class="panel mb-6" style="background:var(--grad-soft);border-color:#DDE6FB">
        <div class="row gap-4" style="justify-content:space-between;align-items:flex-start;flex-wrap:wrap">
          <div class="row gap-4" style="align-items:center">
            <div class="avatar-upload" id="seeker-avatar-wrap">
              ${avatarHTML(user.fullName, user.avatarUrl, 62)}
              <input type="file" accept="image/*" id="seeker-avatar-input" title="Change profile picture">
              <span class="avatar-upload-badge">📷</span>
            </div>
            <div>
              <h2 style="font-size:23px">Hello, ${esc((user.fullName || '').split(' ')[0])}</h2>
              <p class="muted mt-2" style="max-width:56ch">
                Describe a job in your own words and OMNI will work out what you need and who nearby can do it.
              </p>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm" id="edit-profile">Edit profile</button>
        </div>
        <div class="demo-input-row mt-4" style="max-width:640px">
          <input class="input" id="home-ask" placeholder="e.g. My kitchen pipe is leaking, I need help today">
          <button class="btn btn-primary" id="home-go">Find providers</button>
        </div>
      </div>

      <div class="stat-grid mb-6" id="home-stats">
        <div class="stat"><div class="stat-label">Open requests</div><div class="stat-value"><span class="skeleton" style="display:inline-block;width:40px;height:26px"></span></div></div>
        <div class="stat"><div class="stat-label">Quotations waiting</div><div class="stat-value"><span class="skeleton" style="display:inline-block;width:40px;height:26px"></span></div></div>
        <div class="stat"><div class="stat-label">Jobs booked</div><div class="stat-value"><span class="skeleton" style="display:inline-block;width:40px;height:26px"></span></div></div>
        <div class="stat"><div class="stat-label">Jobs completed</div><div class="stat-value"><span class="skeleton" style="display:inline-block;width:40px;height:26px"></span></div></div>
      </div>

      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>Your requests</h2>
            <p>Every job you've posted, from first match through to review.</p>
          </div>
          <button class="btn btn-ghost btn-sm" id="new-request">Post a new request</button>
        </div>
        <div id="request-list"><div class="empty"><span class="spinner"></span></div></div>
      </div>`;

    el('#home-go').onclick = () => {
      const q = el('#home-ask').value.trim();
      if (!q) return;
      sessionStorage.setItem('omni_pending_q', q);
      router.go('/seeker/omni');
    };
    el('#home-ask').onkeydown = (e) => { if (e.key === 'Enter') el('#home-go').click(); };
    el('#new-request').onclick = () => this.openRequestModal();
    el('#edit-profile').onclick = () => this.openProfileEditor();

    const attachAvatarPicker = () => {
      const input = el('#seeker-avatar-input');
      if (!input) return;
      wireImagePicker(
        input,
        async (dataUrl) => {
          try {
            const { user: updated } = await API.updateMe({ avatarUrl: dataUrl });
            Session.user = updated;
            el('#seeker-avatar-wrap').innerHTML =
              avatarHTML(updated.fullName, updated.avatarUrl, 62) +
              '<input type="file" accept="image/*" id="seeker-avatar-input" title="Change profile picture"><span class="avatar-upload-badge">📷</span>';
            attachAvatarPicker();
            toast('Profile picture updated.', 'ok');
          } catch (e) {
            toast(e.message, 'err');
          }
        },
        { maxDim: 300 }
      );
    };
    attachAvatarPicker();

    await this.loadRequests();
  },

  openProfileEditor() {
    const user = Session.user;
    openModal(
      'Edit your profile',
      `
      <div class="field">
        <label>Full name</label>
        <input class="input" id="pf-name" value="${esc(user.fullName || '')}">
      </div>
      <div class="field-row">
        <div class="field">
          <label>Phone</label>
          <input class="input" id="pf-phone" value="${esc(user.phone || '')}">
        </div>
        <div class="field">
          <label>City</label>
          <input class="input" id="pf-city" value="${esc(user.city || '')}">
        </div>
      </div>
      <div class="field">
        <label>About you <span class="muted">(optional)</span></label>
        <textarea class="textarea" id="pf-bio" placeholder="A line or two providers will see when you request their service.">${esc(user.bio || '')}</textarea>
      </div>
      <button class="btn btn-primary btn-block" id="pf-save">Save changes</button>`,
      (body) => {
        el('#pf-save', body).onclick = async (ev) => {
          ev.target.disabled = true;
          try {
            const { user: updated } = await API.updateMe({
              fullName: el('#pf-name', body).value.trim(),
              phone: el('#pf-phone', body).value.trim(),
              city: el('#pf-city', body).value.trim(),
              bio: el('#pf-bio', body).value.trim()
            });
            Session.user = updated;
            closeModal();
            toast('Profile updated.', 'ok');
            this.home(el('#page'));
          } catch (e) {
            toast(e.message, 'err');
            ev.target.disabled = false;
          }
        };
      }
    );
  },

  async loadRequests() {
    const listHost = el('#request-list');
    const statHost = el('#home-stats');
    if (!listHost) return;

    try {
      const requests = await API.myRequests();
      const bookings = await API.myBookings();

      if (statHost) {
        const open = requests.filter((r) =>
          ['submitted', 'matching', 'responses', 'provider_selected'].includes(r.status)
        ).length;
        const quotes = requests.reduce((n, r) => n + (r.quotations || []).filter((q) => q.status === 'pending').length, 0);
        const booked = bookings.filter((b) => ['accepted', 'scheduled', 'in_progress'].includes(b.status)).length;
        const done = bookings.filter((b) => b.status === 'completed').length;

        statHost.innerHTML = `
          <div class="stat ${open ? 'stat-accent' : ''}"><div class="stat-label">Open requests</div><div class="stat-value">${open}</div></div>
          <div class="stat"><div class="stat-label">Quotations waiting</div><div class="stat-value">${quotes}</div><div class="stat-note">${quotes ? 'Review and choose a provider' : 'Nothing to review'}</div></div>
          <div class="stat"><div class="stat-label">Jobs booked</div><div class="stat-value">${booked}</div></div>
          <div class="stat"><div class="stat-label">Jobs completed</div><div class="stat-value">${done}</div></div>`;
      }

      if (!requests.length) {
        listHost.innerHTML = `
          <div class="empty">
            <h3>No requests yet</h3>
            <p>Post what you need and OMNI will match you with verified providers nearby.</p>
            <button class="btn btn-primary mt-4" id="empty-new">Post your first request</button>
          </div>`;
        el('#empty-new').onclick = () => this.openRequestModal();
        return;
      }

      listHost.innerHTML = `<div class="stack gap-3">${requests.map((r) => this.requestCard(r)).join('')}</div>`;
      this.bindRequestCards();
    } catch (e) {
      listHost.innerHTML = `<div class="empty"><h3>Couldn't load your requests</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  requestCard(r) {
    const pendingQuotes = (r.quotations || []).filter((q) => q.status === 'pending');
    return `
      <div class="rq-card" data-request="${r.id}">
        <div class="rq-head">
          <div class="grow">
            <div class="rq-desc">${esc(r.description)}</div>
            <div class="rq-meta">
              <span>${esc(r.city || 'Location not set')}</span>
              <span>Posted ${timeAgo(r.createdAt)}</span>
              ${r.timing && r.timing.label !== 'flexible' ? `<span>Needed: ${esc(r.timing.label)}</span>` : ''}
            </div>
          </div>
          ${statusBadge(r.status)}
        </div>

        ${this.lifecycleBar(r.status)}

        ${
          pendingQuotes.length
            ? `<div class="stack gap-2 mt-4">
                 <div class="small muted">${pendingQuotes.length} quotation${pendingQuotes.length > 1 ? 's' : ''} received</div>
                 ${pendingQuotes
                   .map(
                     (q) => `
                   <div class="quote-item">
                     <div>
                       <div style="font-weight:500">${esc(q.providerName)}</div>
                       <div class="small muted">${esc(q.message || 'No message')}${
                         q.estimatedDays ? ` · about ${q.estimatedDays} day${q.estimatedDays > 1 ? 's' : ''}` : ''
                       }</div>
                     </div>
                     <div class="row gap-3">
                       ${trustRing(q.trustScore, 'Trust')}
                       <div class="quote-price">${money(q.price)}</div>
                       <button class="btn btn-primary btn-sm" data-accept="${q.id}">Accept</button>
                     </div>
                   </div>`
                   )
                   .join('')}
               </div>`
            : ''
        }

        ${
          r.booking && r.booking.status === 'completed' && !r.reviewed
            ? `<div class="row gap-2 mt-4">
                 <button class="btn btn-primary btn-sm" data-review="${r.booking.id}">Leave a review</button>
               </div>`
            : ''
        }

        ${
          ['matching', 'submitted'].includes(r.status)
            ? `<div class="row gap-2 mt-4">
                 <button class="btn btn-ghost btn-sm" data-rematch="${r.id}">Re-run matching</button>
                 <button class="btn btn-quiet btn-sm" data-cancel="${r.id}">Cancel request</button>
               </div>`
            : ''
        }

        ${r.booking && r.booking.status !== 'cancelled' ? this.paymentRow(r.booking) : ''}
      </div>`;
  },

  paymentRow(booking) {
    const paid = booking.paymentStatus === 'paid';
    return `
      <div class="row gap-3 mt-4" style="justify-content:space-between;flex-wrap:wrap;padding-top:14px;border-top:1px solid var(--line-soft)">
        <div class="row gap-2">
          <span class="small muted">Booking total</span>
          <b>${money(booking.price)}</b>
          ${statusBadge(paid ? 'succeeded' : 'unpaid')}
        </div>
        ${
          paid
            ? `<button class="btn btn-ghost btn-sm" data-view-receipt="${booking.paymentId}">View receipt</button>`
            : `<button class="btn btn-primary btn-sm" data-pay="${booking.id}" data-amount="${booking.price}">Pay now</button>`
        }
      </div>`;
  },

  lifecycleBar(status) {
    const flow = ['submitted', 'matching', 'responses', 'accepted', 'scheduled', 'in_progress', 'completed', 'reviewed'];
    const labels = {
      submitted: 'Posted', matching: 'Matching', responses: 'Quotes',
      accepted: 'Accepted', scheduled: 'Scheduled', in_progress: 'In progress',
      completed: 'Done', reviewed: 'Reviewed'
    };
    if (['cancelled', 'rejected', 'expired', 'failed'].includes(status)) return '';
    const idx = flow.indexOf(status);
    return `
      <div class="lifecycle mt-4">
        ${flow
          .map((step, i) => {
            const done = idx >= 0 && i < idx;
            const current = i === idx;
            return `
            ${i > 0 ? `<div class="lc-bar ${done || current ? 'done' : ''}"></div>` : ''}
            <div class="lc-step">
              <div class="lc-node">
                <div class="lc-dot ${done ? 'done' : ''} ${current ? 'current' : ''}">${done ? '✓' : i + 1}</div>
                <div class="lc-label">${labels[step]}</div>
              </div>
            </div>`;
          })
          .join('')}
      </div>`;
  },

  bindRequestCards() {
    els('[data-accept]').forEach((btn) => {
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          await API.acceptQuotation(btn.dataset.accept);
          toast('Provider booked. They have been notified.', 'ok');
          this.loadRequests();
        } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
      };
    });
    els('[data-rematch]').forEach((btn) => {
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          const res = await API.rematch(btn.dataset.rematch);
          toast(`Matched to ${res.request.candidates.length} providers.`, 'ok');
          this.loadRequests();
        } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
      };
    });
    els('[data-cancel]').forEach((btn) => {
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          await API.setRequestStatus(btn.dataset.cancel, 'cancelled');
          toast('Request cancelled.');
          this.loadRequests();
        } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
      };
    });
    els('[data-review]').forEach((btn) => {
      btn.onclick = () => this.openReviewModal(btn.dataset.review);
    });
    els('[data-pay]').forEach((btn) => {
      btn.onclick = () => {
        Payment.open({
          purpose: 'booking',
          bookingId: btn.dataset.pay,
          amount: Number(btn.dataset.amount),
          purposeLabel: 'Paying for your booking',
          onSuccess: () => {
            toast('Payment complete.', 'ok');
            this.loadRequests();
          }
        });
      };
    });
    els('[data-view-receipt]').forEach((btn) => {
      btn.onclick = async () => {
        try {
          const payment = await API.payment(btn.dataset.viewReceipt);
          Payment.showReceipt(payment);
        } catch (e) {
          toast(e.message, 'err');
        }
      };
    });
  },

  /* ---------------- request modal ---------------- */
  openRequestModal(prefill = '') {
    const subOptions = this.categories
      .map(
        (c) => `<optgroup label="${esc(c.label)}">${c.subcategories
          .map((s) => `<option value="${s.key}">${esc(s.label)}</option>`)
          .join('')}</optgroup>`
      )
      .join('');

    openModal(
      'Post a service request',
      `
      <div class="field">
        <label for="rq-desc">What do you need?</label>
        <textarea class="textarea" id="rq-desc" placeholder="Describe the job in your own words — OMNI reads this to work out the service, the area and how urgent it is.">${esc(prefill)}</textarea>
      </div>
      <div class="field-row">
        <div class="field">
          <label for="rq-city">City or area</label>
          <input class="input" id="rq-city" value="${esc(Session.user.city || '')}" placeholder="e.g. Azezo, Gondar">
        </div>
        <div class="field">
          <label for="rq-budget">Budget in ETB <span class="muted">(optional)</span></label>
          <input class="input" id="rq-budget" type="number" min="0" placeholder="e.g. 2000">
        </div>
      </div>
      <div class="field">
        <label for="rq-sub">Service category <span class="muted">(optional — OMNI detects it)</span></label>
        <select class="select" id="rq-sub"><option value="">Let OMNI decide</option>${subOptions}</select>
      </div>
      <button class="btn btn-primary btn-block" id="rq-submit">Post request and find providers</button>`,
      (body) => {
        el('#rq-desc', body).focus();
        el('#rq-submit', body).onclick = async (ev) => {
          const description = el('#rq-desc', body).value.trim();
          if (!description) { toast('Describe what you need first.', 'err'); return; }
          ev.target.disabled = true;
          ev.target.textContent = 'Matching…';
          try {
            const coords = Geo.coords || DEFAULT_ORIGIN;
            const res = await API.createRequest({
              description,
              city: el('#rq-city', body).value.trim(),
              budget: Number(el('#rq-budget', body).value) || null,
              subcategoryKey: el('#rq-sub', body).value || null,
              lat: coords.lat,
              lng: coords.lng,
              autoMatch: true
            });
            closeModal();
            const n = res.analysis.matches.length;
            toast(n ? `Matched to ${n} provider${n > 1 ? 's' : ''}. They've been notified.` : 'Request posted.', 'ok');
            this.loadRequests();
          } catch (e) {
            toast(e.message, 'err');
            ev.target.disabled = false;
            ev.target.textContent = 'Post request and find providers';
          }
        };
      }
    );
  },

  openReviewModal(bookingId) {
    let rating = 5;
    openModal(
      'Leave a review',
      `
      <div class="field">
        <label>How did the job go?</label>
        <div class="row gap-2" id="rv-stars">
          ${[1, 2, 3, 4, 5].map((i) => `<span class="star star-input on" data-v="${i}">★</span>`).join('')}
        </div>
      </div>
      <div class="field">
        <label for="rv-text">Your comment</label>
        <textarea class="textarea" id="rv-text" placeholder="What went well, what could be better."></textarea>
      </div>
      <div class="notice notice-blue mb-4">
        <span>ⓘ</span>
        <div>Reviews change the provider's trust score immediately — that score is what ranks them in future searches.</div>
      </div>
      <button class="btn btn-primary btn-block" id="rv-submit">Submit review</button>`,
      (body) => {
        const starEls = els('#rv-stars .star', body);
        starEls.forEach((s) => {
          s.onclick = () => {
            rating = Number(s.dataset.v);
            starEls.forEach((x) => x.classList.toggle('on', Number(x.dataset.v) <= rating));
          };
        });
        el('#rv-submit', body).onclick = async (ev) => {
          ev.target.disabled = true;
          try {
            const res = await API.leaveReview({
              bookingId,
              rating,
              comment: el('#rv-text', body).value.trim()
            });
            closeModal();
            toast(`Review saved — provider trust score is now ${res.newTrustScore}.`, 'ok');
            this.loadRequests();
          } catch (e) { toast(e.message, 'err'); ev.target.disabled = false; }
        };
      }
    );
  },

  /* ---------------- ABOUT ---------------- */
  about(host) {
    host.innerHTML = `
      <div class="panel mb-6">
        <h2 style="font-size:24px">Every service. One smart center.</h2>
        <p class="mt-3" style="max-width:70ch;color:var(--ink-soft)">
          Finding a reliable service provider in Ethiopia usually means asking around, calling numbers
          passed between friends, and hoping the person who shows up does good work. Providers have the
          mirror problem: good work doesn't reach the people looking for it.
        </p>
        <p class="mt-3" style="max-width:70ch;color:var(--ink-soft)">
          OMNISERVICE CENTER puts both sides in one place. You describe a job in plain language, OMNI
          works out which service it is and ranks verified providers by trust score, distance and
          availability, and the whole job — quotation, booking, completion, review — stays tracked in
          one place.
        </p>
      </div>

      <div class="chart-grid">
        <div class="panel">
          <h3 style="font-size:17px" class="mb-4">How a job moves through the platform</h3>
          ${this.lifecycleBar('responses')}
          <p class="small muted mt-4" style="max-width:60ch">
            Each stage is recorded. If something goes wrong, the state it failed at is part of the record —
            that history is what the trust score is calculated from.
          </p>
        </div>
        <div class="panel">
          <h3 style="font-size:17px" class="mb-4">What the trust score measures</h3>
          <div class="stack gap-3">
            ${[
              ['Review ratings', 'Average star rating across completed jobs', '40%'],
              ['Completion rate', 'Jobs finished versus jobs cancelled', '25%'],
              ['Response time', 'How fast the provider replies to requests', '20%'],
              ['Job volume', 'Track record depth, capped so it can\'t dominate', '15%']
            ]
              .map(
                ([name, desc, weight]) => `
              <div class="row gap-3" style="align-items:flex-start">
                <span class="badge badge-blue" style="min-width:44px;justify-content:center">${weight}</span>
                <div>
                  <div style="font-weight:500;font-size:14px">${name}</div>
                  <div class="small muted">${desc}</div>
                </div>
              </div>`
              )
              .join('')}
          </div>
          <p class="small muted mt-4">Cancellations subtract from the score. Nothing here is set by hand.</p>
        </div>
      </div>

      <div class="notice notice-amber mt-6">
        <span>ⓘ</span>
        <div><b>About the data on this platform.</b> Providers, reviews and job history shown here are
        demo data generated for demonstration purposes, clearly flagged wherever they appear. No real
        business, review, statistic or partnership is represented as real.</div>
      </div>`;
  },

  /* ---------------- SERVICES ---------------- */
  async services(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div>
          <h2>Service sectors</h2>
          <p>Twelve sectors, each broken into the services providers actually list under them.</p>
        </div>
      </div>
      <div class="sector-grid" id="sector-grid"></div>
      <div id="sector-detail" class="mt-6"></div>`;

    const counts = await API.mapFeed().catch(() => []);
    const grid = el('#sector-grid');
    grid.innerHTML = this.categories
      .map((c) => {
        const n = counts.filter((p) => p.categoryKey === c.key).length;
        return `
        <button class="sector-card" data-cat="${c.key}">
          <div class="sector-icon">${c.icon}</div>
          <h3>${esc(c.label)}</h3>
          <div class="sector-meta">${n} verified provider${n === 1 ? '' : 's'}</div>
          <div class="sector-subs">
            ${c.subcategories.slice(0, 3).map((s) => `<span class="sector-sub">${esc(s.label)}</span>`).join('')}
            ${c.subcategories.length > 3 ? `<span class="sector-sub">+${c.subcategories.length - 3}</span>` : ''}
          </div>
        </button>`;
      })
      .join('');

    els('.sector-card', grid).forEach((card) => {
      card.onclick = () => this.showSector(card.dataset.cat);
    });
  },

  async showSector(categoryKey) {
    const cat = this.categories.find((c) => c.key === categoryKey);
    const host = el('#sector-detail');
    host.innerHTML = `<div class="panel"><div class="empty"><span class="spinner"></span></div></div>`;
    host.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    const providers = await API.providers({ categoryKey }).catch(() => []);
    host.innerHTML = `
      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>${cat.icon} ${esc(cat.label)}</h2>
            <p>${providers.length} verified provider${providers.length === 1 ? '' : 's'} across ${cat.subcategories.length} service${cat.subcategories.length === 1 ? '' : 's'}</p>
          </div>
          <select class="select" id="sub-filter" style="max-width:230px">
            <option value="">All services in this sector</option>
            ${cat.subcategories.map((s) => `<option value="${s.key}">${esc(s.label)}</option>`).join('')}
          </select>
        </div>
        <div class="provider-list" id="sector-providers"></div>
      </div>`;

    const render = (subKey) => {
      const list = subKey ? providers.filter((p) => p.subcategoryKeys.includes(subKey)) : providers;
      el('#sector-providers').innerHTML = list.length
        ? list.map((p) => this.providerCard(p)).join('')
        : `<div class="empty"><h3>No providers listed here yet</h3><p>Post a request anyway — providers are notified as they join this service.</p></div>`;
      this.bindProviderCards();
    };
    render('');
    el('#sub-filter').onchange = (e) => render(e.target.value);
  },

  providerCard(p, rank) {
    const avail = AVAILABILITY_LABELS[p.availability] || AVAILABILITY_LABELS.by_appointment;
    const subLabels = p.subcategoryKeys
      .map((k) => {
        for (const c of this.categories) {
          const s = c.subcategories.find((x) => x.key === k);
          if (s) return s.label;
        }
        return k;
      })
      .filter(Boolean);

    return `
      <div class="provider-card ${rank === 1 ? 'ranked-1' : ''}">
        ${rank ? `<span class="rank-pill ${rank === 1 ? 'top' : ''}">${rank}</span>` : ''}
        ${avatarHTML(p.businessName, p.avatarUrl, 44)}
        <div class="provider-main">
          <div class="row gap-2" style="flex-wrap:wrap">
            <span class="provider-name">${esc(p.businessName)}</span>
            ${p.isDemoData ? '<span class="demo-flag">Demo data</span>' : ''}
          </div>
          <div class="provider-meta">${esc(p.city)}${p.yearsActive ? ` · ${p.yearsActive} years active` : ''}</div>
          ${p.bio ? `<div class="provider-bio">${esc(p.bio)}</div>` : ''}
          <div class="provider-tags">
            ${subLabels.map((l) => `<span class="sector-sub">${esc(l)}</span>`).join('')}
            <span class="badge ${avail.cls}">${avail.text}</span>
            <span class="badge">Price ${priceDots(p.priceIndex || 3)}</span>
          </div>
          ${
            p.reasons && p.reasons.length
              ? `<div class="match-reasons">${p.reasons.map((r) => `<span class="match-reason">${esc(r)}</span>`).join('')}</div>`
              : ''
          }
          <div class="provider-actions">
            <button class="btn btn-primary btn-sm" data-hire="${p.id}" data-name="${esc(p.businessName)}">Request this provider</button>
            <button class="btn btn-ghost btn-sm" data-view="${p.id}">View profile</button>
          </div>
        </div>
        <div class="provider-right">${trustRing(p.trustScore)}</div>
      </div>`;
  },

  bindProviderCards() {
    els('[data-hire]').forEach((btn) => {
      btn.onclick = () => this.openRequestModal(`I need help from ${btn.dataset.name}: `);
    });
    els('[data-view]').forEach((btn) => {
      btn.onclick = () => this.showProviderProfile(btn.dataset.view);
    });
  },

  async showProviderProfile(id) {
    openModal('Provider profile', `<div class="empty"><span class="spinner"></span></div>`);
    try {
      const [p, reviews, offerings] = await Promise.all([
        API.provider(id),
        API.providerReviews(id),
        API.providerOfferings(id).catch(() => [])
      ]);
      const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;
      closeModal();
      openModal(
        p.businessName,
        `
        <div class="row gap-4 mb-4" style="align-items:flex-start">
          ${avatarHTML(p.businessName, p.avatarUrl, 56)}
          <div class="grow">
            <div class="muted small">${esc(p.city)}${p.yearsActive ? ` · ${p.yearsActive} years active` : ''}</div>
            ${p.bio ? `<p class="mt-2" style="font-size:14px;color:var(--ink-soft)">${esc(p.bio)}</p>` : ''}
          </div>
          ${trustRing(p.trustScore)}
        </div>
        <div class="row gap-4 mb-6" style="flex-wrap:wrap">
          <div><div class="small muted">Rating</div><div class="row gap-2">${stars(avg)} <span class="small">${avg ? avg.toFixed(1) : '—'}</span></div></div>
          <div><div class="small muted">Reviews</div><div>${reviews.length}</div></div>
          <div><div class="small muted">Price level</div><div>${priceDots(p.priceIndex || 3)}</div></div>
        </div>
        ${
          offerings.length
            ? `<h4 style="font-size:15px" class="mb-2">What they offer</h4>
               <div class="offer-grid mb-6">
                 ${offerings
                   .map(
                     (o) => `
                   <div class="offer-card">
                     ${o.photoUrl ? `<img class="offer-photo" src="${esc(o.photoUrl)}" alt="${esc(o.name)}">` : `<div class="offer-photo-empty">${o.type === 'product' ? '📦' : '🛠️'}</div>`}
                     <div class="offer-body">
                       <div class="offer-type">${o.type === 'product' ? 'Product' : 'Service'}</div>
                       <div class="offer-name">${esc(o.name)}</div>
                       ${o.description ? `<div class="offer-desc">${esc(o.description)}</div>` : ''}
                       ${o.price !== null ? `<div class="offer-price">${money(o.price)}${o.unit ? ` / ${esc(o.unit)}` : ''}</div>` : ''}
                     </div>
                   </div>`
                   )
                   .join('')}
               </div>`
            : ''
        }
        <h4 style="font-size:15px" class="mb-2">Recent reviews</h4>
        ${
          reviews.length
            ? `<div class="stack gap-2">${reviews
                .slice(0, 6)
                .map(
                  (r) => `
              <div class="card" style="padding:13px 15px">
                <div class="row gap-2">${stars(r.rating)}<span class="small muted">${timeAgo(r.createdAt)}</span>${r.isDemoData ? '<span class="demo-flag">Demo</span>' : ''}</div>
                ${r.comment ? `<div class="small mt-2" style="color:var(--ink-soft)">${esc(r.comment)}</div>` : ''}
              </div>`
                )
                .join('')}</div>`
            : '<div class="empty"><p>No reviews yet.</p></div>'
        }
        <button class="btn btn-primary btn-block mt-6" id="pp-hire">Request this provider</button>`,
        (body) => {
          el('#pp-hire', body).onclick = () => {
            closeModal();
            this.openRequestModal(`I need help from ${p.businessName}: `);
          };
        }
      );
    } catch (e) {
      closeModal();
      toast(e.message, 'err');
    }
  },

  /* ---------------- MAP ---------------- */
  async map(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div>
          <h2>Provider map</h2>
          <p>Every verified provider with a listed location. Filter by service, then pick a marker.</p>
        </div>
      </div>
      <div class="map-layout">
        <div class="map-side">
          <div class="field" style="margin-bottom:0">
            <label for="map-sub">Filter by service</label>
            <select class="select" id="map-sub">
              <option value="">All services</option>
              ${this.categories
                .map(
                  (c) =>
                    `<optgroup label="${esc(c.label)}">${c.subcategories
                      .map((s) => `<option value="${s.key}">${esc(s.label)}</option>`)
                      .join('')}</optgroup>`
                )
                .join('')}
            </select>
          </div>
          <div class="small muted" id="map-count">Loading…</div>
          <div class="map-results" id="map-results"></div>
        </div>
        <div id="map"></div>
      </div>`;

    const map = L.map('map').setView([12.603, 37.4521], 12);
    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(map);

    // Map tiles are the one part of the app that needs internet. If they can't
    // load, say so plainly and keep the markers and the list working.
    let tileWarningShown = false;
    tiles.on('tileerror', () => {
      if (tileWarningShown) return;
      tileWarningShown = true;
      const banner = document.createElement('div');
      banner.className = 'notice notice-amber';
      banner.style.cssText = 'position:absolute;top:12px;left:12px;right:12px;z-index:500;background:#FEF4E6';
      banner.innerHTML = `<span>ⓘ</span><div>Map tiles need an internet connection. Provider locations and the list beside the map still work offline.</div>`;
      const wrap = el('#map');
      wrap.style.position = 'relative';
      wrap.appendChild(banner);
    });

    let markers = [];

    const load = async (subcategoryKey) => {
      markers.forEach((m) => map.removeLayer(m));
      markers = [];
      el('#map-results').innerHTML = `<div class="empty"><span class="spinner"></span></div>`;

      const providers = await API.mapFeed({ subcategoryKey }).catch(() => []);
      el('#map-count').textContent = `${providers.length} provider${providers.length === 1 ? '' : 's'} shown`;

      const bounds = [];
      providers.forEach((p) => {
        const marker = L.circleMarker([p.lat, p.lng], {
          radius: 7,
          color: '#2563EB',
          fillColor: p.trustScore >= 80 ? '#2563EB' : '#7C3AED',
          fillOpacity: 0.85,
          weight: 2
        }).addTo(map);

        marker.bindPopup(`
          <h4>${esc(p.businessName)}</h4>
          <div style="color:#6B7893;font-size:12.5px">${esc(p.city)}</div>
          <div style="margin-top:6px">Trust score <b>${p.trustScore}</b></div>
          ${p.isDemoData ? '<div style="margin-top:6px;font-size:11.5px;color:#B45309">Demo data</div>' : ''}
          <button onclick="Seeker.showProviderProfile('${p.id}')"
                  style="margin-top:9px;padding:6px 13px;border:none;border-radius:999px;background:#2563EB;color:#fff;cursor:pointer;font-size:12.5px">
            View profile
          </button>`);

        markers.push(marker);
        bounds.push([p.lat, p.lng]);
      });

      if (bounds.length) map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });

      el('#map-results').innerHTML = providers.length
        ? providers
            .slice()
            .sort((a, b) => b.trustScore - a.trustScore)
            .map(
              (p, i) => `
          <div class="map-result" data-i="${providers.indexOf(p)}">
            <div class="row gap-2" style="justify-content:space-between">
              <span style="font-weight:500;font-size:13.5px">${esc(p.businessName)}</span>
              <span class="badge badge-blue">${p.trustScore}</span>
            </div>
            <div class="small muted">${esc(p.city)}</div>
          </div>`
            )
            .join('')
        : `<div class="empty"><p>No providers listed for this service yet.</p></div>`;

      els('.map-result').forEach((row) => {
        row.onclick = () => {
          const marker = markers[Number(row.dataset.i)];
          if (!marker) return;
          els('.map-result').forEach((r) => r.classList.remove('active'));
          row.classList.add('active');
          map.setView(marker.getLatLng(), 15);
          marker.openPopup();
        };
      });
    };

    el('#map-sub').onchange = (e) => load(e.target.value);
    await load('');
    setTimeout(() => map.invalidateSize(), 120);
  },

  /* ---------------- OMNI AGENT ---------------- */
  omni(host) {
    host.innerHTML = `
      <div class="omni-wrap">
        <div class="omni-head">
          <div class="omni-avatar">AI</div>
          <div class="grow">
            <div style="font-family:var(--font-head);font-weight:600;font-size:15px">OMNI</div>
            <div class="small muted">Reads your request, finds the service, ranks providers</div>
          </div>
          <span class="badge badge-green">Live</span>
        </div>
        <div class="omni-log" id="omni-log"></div>
        <div class="omni-foot">
          <div class="demo-chips mb-2" id="omni-chips">
            ${['My pipe is leaking, I need a plumber today', 'I need a tutor for maths exams', 'Find me a photographer for an event', 'My laptop wont turn on']
              .map((q) => `<button class="demo-chip" data-q="${esc(q)}">${esc(q)}</button>`)
              .join('')}
          </div>
          <div class="omni-input-row">
            <input class="input" id="omni-input" placeholder="Tell OMNI what you need…" aria-label="Message OMNI">
            <button class="btn btn-primary" id="omni-send">Send</button>
          </div>
        </div>
      </div>`;

    const log = el('#omni-log');
    const input = el('#omni-input');

    if (!this.chatLog.length) {
      this.chatLog.push({
        who: 'omni',
        text: `Hi ${(Session.user.fullName || '').split(' ')[0]}. Describe what you need in your own words — I'll work out which service it is, where you are and how soon you need it, then rank the providers who fit.`
      });
    }
    this.paintChat();

    els('#omni-chips .demo-chip').forEach((chip) => {
      chip.onclick = () => { input.value = chip.dataset.q; send(); };
    });
    el('#omni-send').onclick = send;
    input.onkeydown = (e) => { if (e.key === 'Enter') send(); };
    input.focus();

    const self = this;
    async function send() {
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      self.chatLog.push({ who: 'me', text });
      self.chatLog.push({ who: 'omni', typing: true });
      self.paintChat();

      try {
        const origin = Geo.coords || DEFAULT_ORIGIN;
        const r = await API.ask(text, origin);
        self.chatLog.pop();
        self.chatLog.push({ who: 'omni', text: r.reply, analysis: r });
      } catch (e) {
        self.chatLog.pop();
        self.chatLog.push({ who: 'omni', text: e.message });
      }
      self.paintChat();
    }
  },

  paintChat() {
    const log = el('#omni-log');
    if (!log) return;
    log.innerHTML = this.chatLog
      .map((m) => {
        if (m.typing) {
          return `<div class="msg"><div class="omni-avatar" style="width:30px;height:30px;font-size:11px">AI</div>
            <div class="msg-bubble"><span class="typing"><i></i><i></i><i></i></span></div></div>`;
        }
        if (m.who === 'me') {
          return `<div class="msg me"><div class="msg-bubble">${esc(m.text)}</div></div>`;
        }
        return `
          <div class="msg">
            <div class="omni-avatar" style="width:30px;height:30px;font-size:11px">AI</div>
            <div class="grow">
              <div class="msg-bubble">${esc(m.text)}</div>
              ${m.analysis ? this.analysisBlock(m.analysis) : ''}
            </div>
          </div>`;
      })
      .join('');
    log.scrollTop = log.scrollHeight;

    els('[data-omni-hire]', log).forEach((btn) => {
      btn.onclick = () => this.openRequestModal(`I need help from ${btn.dataset.name}: `);
    });
    els('[data-omni-view]', log).forEach((btn) => {
      btn.onclick = () => this.showProviderProfile(btn.dataset.omniView);
    });
  },

  analysisBlock(a) {
    if (!a.understood) {
      return `<div class="omni-analysis">
        <div class="omni-analysis-head">No category matched</div>
        <div class="omni-analysis-body">
          <div class="omni-reasoning"><ul>${a.reasoning.map((l) => `<li>${esc(l)}</li>`).join('')}</ul></div>
        </div>
      </div>`;
    }
    return `
      <div class="omni-analysis">
        <div class="omni-analysis-head">
          <span>✦</span> What OMNI extracted from your message
        </div>
        <div class="omni-analysis-body">
          <div class="omni-chips">
            <span class="badge badge-blue">Service: ${esc(a.subcategory.label)}</span>
            <span class="badge badge-violet">Sector: ${esc(a.category.label)}</span>
            ${a.city ? `<span class="badge">Location: ${esc(a.city)}</span>` : '<span class="badge">Location: not stated</span>'}
            <span class="badge">Timing: ${esc(a.timing.label)}</span>
          </div>

          ${
            a.matches.length
              ? `<div class="stack gap-2 mt-4">
                  ${a.matches
                    .slice(0, 5)
                    .map(
                      (m, i) => `
                    <div class="quote-item">
                      <div class="row gap-3">
                        <span class="rank-pill ${i === 0 ? 'top' : ''}">${i + 1}</span>
                        <div>
                          <div style="font-weight:500;font-size:14px">${esc(m.businessName)}</div>
                          <div class="small muted">${esc(m.city)}${m.distanceKm !== null ? ` · ${m.distanceKm} km away` : ''}</div>
                          ${m.reasons.length ? `<div class="match-reasons">${m.reasons.map((r) => `<span class="match-reason">${esc(r)}</span>`).join('')}</div>` : ''}
                        </div>
                      </div>
                      <div class="row gap-2">
                        <span class="badge badge-blue">Trust ${m.trustScore}</span>
                        <button class="btn btn-ghost btn-sm" data-omni-view="${m.providerId}">Profile</button>
                        <button class="btn btn-primary btn-sm" data-omni-hire="1" data-name="${esc(m.businessName)}">Request</button>
                      </div>
                    </div>`
                    )
                    .join('')}
                </div>`
              : '<div class="notice notice-amber mt-4"><span>ⓘ</span><div>No verified provider is listed for this service yet.</div></div>'
          }

          <div class="omni-reasoning">
            <b>Ranking logic</b>
            <ul>${a.reasoning.map((l) => `<li>${esc(l)}</li>`).join('')}</ul>
          </div>
        </div>
      </div>`;
  },

  /* ---------------- CONTACT ---------------- */
  async contact(host) {
    host.innerHTML = `
      <div class="chart-grid">
        <div class="panel">
          <div class="panel-head">
            <div>
              <h2>Notifications</h2>
              <p>Updates on your requests, quotations and bookings.</p>
            </div>
            <button class="btn btn-ghost btn-sm" id="read-all">Mark all read</button>
          </div>
          <div class="stack gap-2" id="notif-list"><div class="empty"><span class="spinner"></span></div></div>
        </div>

        <div class="panel">
          <h2 style="font-size:19px" class="mb-4">Get in touch</h2>
          <div class="stack gap-4">
            <div>
              <div class="small muted">Platform support</div>
              <div>support@omniservice.center</div>
            </div>
            <div>
              <div class="small muted">Provider onboarding</div>
              <div>providers@omniservice.center</div>
            </div>
            <div>
              <div class="small muted">Launch city</div>
              <div>Gondar, Amhara Region, Ethiopia</div>
            </div>
            <div>
              <div class="small muted">Languages</div>
              <div>English and Amharic</div>
            </div>
          </div>
          <div class="notice notice-blue mt-6">
            <span>ⓘ</span>
            <div>Contact details above are placeholders for this build, not live support channels.</div>
          </div>
        </div>
      </div>`;

    el('#read-all').onclick = async () => {
      await API.markAllRead().catch(() => {});
      this.contact(host);
    };

    try {
      const notifs = await API.notifications();
      el('#notif-list').innerHTML = notifs.length
        ? notifs
            .slice(0, 25)
            .map(
              (n) => `
          <div class="notif ${n.read ? '' : 'unread'}">
            ${n.read ? '' : '<span class="notif-dot"></span>'}
            <div class="grow">
              <div class="notif-title">${esc(n.title)}</div>
              <div class="notif-body">${esc(n.body)}</div>
              <div class="notif-time">${timeAgo(n.createdAt)}</div>
            </div>
          </div>`
            )
            .join('')
        : '<div class="empty"><h3>Nothing yet</h3><p>Updates about your requests will show up here.</p></div>';
    } catch (e) {
      el('#notif-list').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  }
};
