const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { signToken, requireAuth } = require('../middleware');

const router = express.Router();

function publicUser(u) {
  const { passwordHash, ...rest } = u;
  return rest;
}

const MAX_IMAGE_DATA_URI_LENGTH = 400000;
function validImageDataUri(value) {
  if (value === null) return true; // explicit clear
  if (typeof value !== 'string') return false;
  if (!/^data:image\/(png|jpe?g|webp);base64,/.test(value)) return false;
  return value.length <= MAX_IMAGE_DATA_URI_LENGTH;
}

router.post('/register/seeker', (req, res) => {
  const { fullName, email, phone, password, city } = req.body;
  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'Full name, email, and password are required.' });
  }
  if (db.find('users', (u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }
  const user = {
    id: db.id('usr'),
    role: 'seeker',
    fullName,
    email,
    phone: phone || '',
    city: city || '',
    bio: '',
    avatarUrl: null,
    passwordHash: bcrypt.hashSync(password, 8),
    createdAt: db.now()
  };
  db.insert('users', user);
  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user) });
});

router.post('/register/provider', (req, res) => {
  const {
    fullName, email, phone, password,
    businessName, categoryKey, subcategoryKeys, city, bio, yearsActive, priceIndex
  } = req.body;

  if (!fullName || !email || !password || !businessName || !subcategoryKeys || !subcategoryKeys.length) {
    return res.status(400).json({
      error: 'Full name, email, password, business name, and at least one service category are required.'
    });
  }
  if (db.find('users', (u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const user = {
    id: db.id('usr'),
    role: 'provider',
    fullName,
    email,
    phone: phone || '',
    city: city || '',
    bio: '',
    avatarUrl: null,
    passwordHash: bcrypt.hashSync(password, 8),
    createdAt: db.now()
  };
  db.insert('users', user);

  const provider = {
    id: db.id('prov'),
    userId: user.id,
    businessName,
    ownerName: fullName,
    categoryKey: categoryKey || null,
    subcategoryKeys,
    city: city || '',
    lat: null,
    lng: null,
    bio: bio || '',
    yearsActive: yearsActive || 0,
    priceIndex: priceIndex || 3,
    availability: 'by_appointment',
    status: 'pending', // must be verified by admin before appearing in matches
    documents: [],
    trustScore: 0,
    isDemoData: false,
    createdAt: db.now()
  };
  db.insert('providerProfiles', provider);

  db.insert('notifications', {
    id: db.id('notif'),
    userId: user.id,
    title: 'Application received',
    body: 'Your provider application is under review. You\u2019ll be notified once verified and visible in search.',
    read: false,
    createdAt: db.now()
  });

  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user), provider });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
  const user = db.find('users', (u) => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Incorrect email or password.' });
  }
  const token = signToken(user);
  const provider = user.role === 'provider' ? db.find('providerProfiles', (p) => p.userId === user.id) : null;
  res.json({ token, user: publicUser(user), provider });
});

router.get('/me', requireAuth, (req, res) => {
  const user = db.find('users', (u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  const provider = user.role === 'provider' ? db.find('providerProfiles', (p) => p.userId === user.id) : null;
  res.json({ user: publicUser(user), provider });
});

// Update the personal profile shared by every role — name, phone, city, bio,
// and profile picture. Business-specific fields (business name, services,
// offerings) live on the provider profile and are edited via /api/providers/me/profile.
router.patch('/me', requireAuth, (req, res) => {
  const user = db.find('users', (u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const allowed = ['fullName', 'phone', 'city', 'bio', 'avatarUrl'];
  const patch = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  if (patch.avatarUrl !== undefined && !validImageDataUri(patch.avatarUrl)) {
    return res.status(400).json({ error: 'That image is an unsupported format or too large.' });
  }
  if (patch.fullName !== undefined && !String(patch.fullName).trim()) {
    return res.status(400).json({ error: 'Name can\u2019t be empty.' });
  }

  const updated = db.update('users', user.id, patch);

  // Keep the provider profile's owner name / seeker-facing name in sync.
  if (user.role === 'provider' && patch.fullName !== undefined) {
    const provider = db.find('providerProfiles', (p) => p.userId === user.id);
    if (provider) db.update('providerProfiles', provider.id, { ownerName: patch.fullName });
  }

  res.json({ user: publicUser(updated) });
});

module.exports = router;
