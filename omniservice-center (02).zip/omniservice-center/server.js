// server.js — OMNISERVICE CENTER API + static frontend
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const db = require('./src/db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '4mb' })); // headroom for compressed profile-picture / offering-photo uploads

// If the database has never been seeded, seed it on first boot so `npm start`
// alone is enough to get a working demo.
if (!fs.existsSync(db.DB_PATH) || db.all('categories').length === 0) {
  console.log('No database found — seeding initial dataset...');
  require('./src/seed').seed();
}

// --- API ---
app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/categories', require('./src/routes/categories'));
app.use('/api/providers', require('./src/routes/providers'));
app.use('/api/requests', require('./src/routes/requests'));
app.use('/api/quotations', require('./src/routes/quotations'));
app.use('/api/reviews', require('./src/routes/reviews'));
app.use('/api/omni', require('./src/routes/omni'));
app.use('/api', require('./src/routes/inbox'));
app.use('/api/admin', require('./src/routes/admin'));
app.use('/api/payments', require('./src/routes/payments'));
app.use('/api/favorites', require('./src/routes/favorites'));

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    providers: db.all('providerProfiles').length,
    users: db.all('users').length,
    time: db.now()
  });
});

// --- Static frontend ---
app.use(express.static(path.join(__dirname, 'public')));

// Client-side routing fallback (anything not /api/* serves the app shell).
app.get(/^\/(?!api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

app.listen(PORT, () => {
  console.log(`\n  OMNISERVICE CENTER running at http://localhost:${PORT}`);
  console.log(`  API health check:            http://localhost:${PORT}/api/health\n`);
  console.log('  Demo accounts (password: demo1234)');
  console.log('    seeker1@omniservice.center    — Service Seeker stream');
  console.log('    provider1@omniservice.center  — Service Provider stream');
  console.log('    admin@omniservice.center      — Admin Command Center\n');
});
