/* ============================================================
   api.js — the single place the frontend talks to the server.
   Every view calls these functions; none of them build URLs
   themselves, so pointing the app at a different backend is a
   one-line change here.
   ============================================================ */

const API_BASE = '/api';

const Session = {
  get token() { return localStorage.getItem('omni_token'); },
  set token(v) { v ? localStorage.setItem('omni_token', v) : localStorage.removeItem('omni_token'); },
  get user() {
    try { return JSON.parse(localStorage.getItem('omni_user') || 'null'); } catch { return null; }
  },
  set user(v) { v ? localStorage.setItem('omni_user', JSON.stringify(v)) : localStorage.removeItem('omni_user'); },
  get provider() {
    try { return JSON.parse(localStorage.getItem('omni_provider') || 'null'); } catch { return null; }
  },
  set provider(v) { v ? localStorage.setItem('omni_provider', JSON.stringify(v)) : localStorage.removeItem('omni_provider'); },
  clear() { this.token = null; this.user = null; this.provider = null; }
};

async function request(method, path, body) {
  const res = await fetch(API_BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(Session.token ? { Authorization: `Bearer ${Session.token}` } : {})
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });

  let data = null;
  const text = await res.text();
  if (text) {
    try { data = JSON.parse(text); } catch { data = { error: 'The server returned an unreadable response.' }; }
  }

  if (res.status === 401 && Session.token) {
    Session.clear();
    window.dispatchEvent(new CustomEvent('omni:signed-out'));
  }
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status}).`);
  return data;
}

const API = {
  // auth
  login: (email, password) => request('POST', '/auth/login', { email, password }),
  registerSeeker: (payload) => request('POST', '/auth/register/seeker', payload),
  registerProvider: (payload) => request('POST', '/auth/register/provider', payload),
  me: () => request('GET', '/auth/me'),

  // catalogue
  categories: () => request('GET', '/categories'),

  // providers
  providers: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null));
    return request('GET', `/providers${q.toString() ? '?' + q : ''}`);
  },
  provider: (id) => request('GET', `/providers/${id}`),
  providerReviews: (id) => request('GET', `/providers/${id}/reviews`),
  myProviderProfile: () => request('GET', '/providers/me/profile'),
  updateProviderProfile: (patch) => request('PATCH', '/providers/me/profile', patch),
  providerOfferings: (id) => request('GET', `/providers/${id}/offerings`),
  addOffering: (payload) => request('POST', '/providers/me/offerings', payload),
  updateOffering: (id, patch) => request('PATCH', `/providers/me/offerings/${id}`, patch),
  deleteOffering: (id) => request('DELETE', `/providers/me/offerings/${id}`),

  // availability / scheduling
  updateProviderSchedule: (patch) => request('PATCH', '/providers/me/schedule', patch),
  providerSlots: (id, date) => request('GET', `/providers/${id}/slots?date=${encodeURIComponent(date)}`),

  // favorites
  favorites: () => request('GET', '/favorites/mine'),
  addFavorite: (providerId) => request('POST', `/favorites/${providerId}`),
  removeFavorite: (providerId) => request('DELETE', `/favorites/${providerId}`),

  // personal profile (either role) — name, phone, city, bio, profile picture
  updateMe: (patch) => request('PATCH', '/auth/me', patch),

  // OMNI
  ask: (message, coords) => request('POST', '/omni/ask', { message, ...(coords || {}) }),
  mapFeed: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null));
    return request('GET', `/omni/map${q.toString() ? '?' + q : ''}`);
  },

  // requests
  createRequest: (payload) => request('POST', '/requests', payload),
  myRequests: () => request('GET', '/requests/mine'),
  providerQueue: () => request('GET', '/requests/for-provider'),
  rematch: (id) => request('POST', `/requests/${id}/match`),
  setRequestStatus: (id, status) => request('PATCH', `/requests/${id}/status`, { status }),

  // quotations & bookings
  sendQuotation: (payload) => request('POST', '/quotations', payload),
  quotationsFor: (requestId) => request('GET', `/quotations/for-request/${requestId}`),
  acceptQuotation: (id, scheduledFor) => request('POST', `/quotations/${id}/accept`, { scheduledFor }),
  myBookings: () => request('GET', '/quotations/bookings/mine'),
  setBookingStatus: (id, status, scheduledFor) =>
    request('PATCH', `/quotations/bookings/${id}/status`, { status, scheduledFor }),

  // reviews
  leaveReview: (payload) => request('POST', '/reviews', payload),

  // inbox
  sendMessage: (payload) => request('POST', '/messages', payload),
  messages: (params = {}) => {
    const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null));
    return request('GET', `/messages${q.toString() ? '?' + q : ''}`);
  },
  notifications: () => request('GET', '/notifications'),
  markNotificationRead: (id) => request('PATCH', `/notifications/${id}/read`),
  markAllRead: () => request('POST', '/notifications/read-all'),

  // admin
  adminStats: () => request('GET', '/admin/stats'),
  adminProviders: (status) => request('GET', `/admin/providers${status ? '?status=' + status : ''}`),
  adminVerify: (id, decision, note) => request('PATCH', `/admin/providers/${id}/verify`, { decision, note }),
  adminUsers: (role) => request('GET', `/admin/users${role ? '?role=' + role : ''}`),
  adminRequests: () => request('GET', '/admin/requests'),
  reportCompanies: () => request('GET', '/admin/reports/companies'),
  reportUsers: () => request('GET', '/admin/reports/users'),
  reportPayments: () => request('GET', '/admin/reports/payments'),

  // payments
  paymentMethods: () => request('GET', '/payments/methods'),
  initiatePayment: (payload) => request('POST', '/payments/initiate', payload),
  confirmPayment: (id) => request('POST', `/payments/${id}/confirm`),
  myPayments: () => request('GET', '/payments/mine'),
  paymentsForBooking: (bookingId) => request('GET', `/payments/for-booking/${bookingId}`),
  payment: (id) => request('GET', `/payments/${id}`)
};

/* ---------- shared helpers ---------- */

const el = (sel, root = document) => root.querySelector(sel);
const els = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

function toast(message, kind = '') {
  const host = el('#toasts');
  const node = document.createElement('div');
  node.className = `toast ${kind ? 'toast-' + kind : ''}`;
  node.textContent = message;
  host.appendChild(node);
  setTimeout(() => {
    node.style.opacity = '0';
    node.style.transition = 'opacity .25s';
    setTimeout(() => node.remove(), 260);
  }, 3600);
}

function money(n) {
  return new Intl.NumberFormat('en-ET').format(Math.round(n || 0)) + ' ETB';
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}

function initials(name) {
  return (name || '?')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('');
}

// Renders a profile picture when one is set, otherwise the initials circle
// every screen already used — same markup, so this is a drop-in swap.
function avatarHTML(name, avatarUrl, size = 33) {
  const style = size !== 33 ? ` style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px"` : '';
  if (avatarUrl) {
    return `<img class="avatar" src="${esc(avatarUrl)}" alt="${esc(name || '')}"${style}>`;
  }
  return `<div class="avatar"${style}>${esc(initials(name))}</div>`;
}

// Downscales and compresses an image file in the browser before it's ever
// sent to the server — keeps the JSON datastore small and uploads fast.
// Resolves to a data: URI (image/jpeg) or rejects with a friendly message.
function compressImageToDataUrl(file, maxDim = 480, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type || !file.type.startsWith('image/')) {
      return reject(new Error('Choose an image file (JPG, PNG or WEBP).'));
    }
    if (file.size > 12 * 1024 * 1024) {
      return reject(new Error('That image is too large — try one under 12MB.'));
    }
    const img = new Image();
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read that file.'));
    reader.onload = () => {
      img.onerror = () => reject(new Error('That doesn\u2019t look like a valid image.'));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function trustRing(score, label = 'Trust score') {
  const circumference = 2 * Math.PI * 16;
  const dash = (score / 100) * circumference;
  return `
    <div class="trust" title="${label}: ${score}/100 — calculated from reviews, completed jobs, response time and cancellations">
      <svg class="trust-ring" viewBox="0 0 38 38" aria-hidden="true">
        <circle class="bg" cx="19" cy="19" r="16"></circle>
        <circle class="fg" cx="19" cy="19" r="16"
          stroke-dasharray="${dash} ${circumference}"></circle>
      </svg>
      <div>
        <div class="trust-val">${score}</div>
        <div class="trust-lbl">${esc(label)}</div>
      </div>
    </div>`;
}

function stars(rating) {
  return `<span class="stars" aria-label="${rating} out of 5">${[1, 2, 3, 4, 5]
    .map((i) => `<span class="star ${i <= Math.round(rating) ? 'on' : ''}">★</span>`)
    .join('')}</span>`;
}

function priceDots(index) {
  return `<span class="price-dots" title="Relative price level ${index}/5">${[1, 2, 3, 4, 5]
    .map((i) => `<span class="price-dot ${i <= index ? 'on' : ''}"></span>`)
    .join('')}</span>`;
}

const DAY_ORDER = [
  { key: 'mon', label: 'Mon' }, { key: 'tue', label: 'Tue' }, { key: 'wed', label: 'Wed' },
  { key: 'thu', label: 'Thu' }, { key: 'fri', label: 'Fri' }, { key: 'sat', label: 'Sat' },
  { key: 'sun', label: 'Sun' }
];

function fmtTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

const AVAILABILITY_LABELS = {
  available_now: { text: 'Available now', cls: 'badge-green' },
  by_appointment: { text: 'By appointment', cls: 'badge-blue' },
  unavailable: { text: 'Not taking work', cls: '' }
};

const STATUS_LABELS = {
  draft: 'Draft', submitted: 'Submitted', matching: 'Finding providers',
  responses: 'Quotations in', provider_selected: 'Provider selected',
  accepted: 'Accepted', scheduled: 'Scheduled', in_progress: 'In progress',
  completed: 'Completed', confirmed: 'Confirmed', reviewed: 'Reviewed',
  cancelled: 'Cancelled', rejected: 'Rejected', expired: 'Expired',
  disputed: 'Disputed', failed: 'Failed', pending: 'Pending review',
  verified: 'Verified', suspended: 'Suspended', declined: 'Declined',
  succeeded: 'Paid', unpaid: 'Unpaid'
};

function statusBadge(status) {
  const map = {
    completed: 'badge-green', confirmed: 'badge-green', reviewed: 'badge-green', verified: 'badge-green', succeeded: 'badge-green',
    accepted: 'badge-blue', scheduled: 'badge-blue', in_progress: 'badge-blue', matching: 'badge-blue',
    responses: 'badge-violet', provider_selected: 'badge-violet',
    pending: 'badge-amber', submitted: 'badge-amber', disputed: 'badge-amber', unpaid: 'badge-amber',
    cancelled: 'badge-red', rejected: 'badge-red', failed: 'badge-red', expired: 'badge-red', suspended: 'badge-red'
  };
  return `<span class="badge ${map[status] || ''}">${esc(STATUS_LABELS[status] || status)}</span>`;
}

/* ---------- modal ---------- */
function openModal(title, bodyHTML, onMount) {
  closeModal();
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.id = 'modal-back';
  back.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head">
        <h3>${esc(title)}</h3>
        <button class="modal-close" aria-label="Close">&times;</button>
      </div>
      <div class="modal-body">${bodyHTML}</div>
    </div>`;
  document.body.appendChild(back);
  back.addEventListener('click', (e) => { if (e.target === back) closeModal(); });
  el('.modal-close', back).addEventListener('click', closeModal);
  document.addEventListener('keydown', escClose);
  if (onMount) onMount(el('.modal-body', back));
  return back;
}
function escClose(e) { if (e.key === 'Escape') closeModal(); }
function closeModal() {
  const existing = el('#modal-back');
  if (existing) existing.remove();
  document.removeEventListener('keydown', escClose);
}

/* ---------- geolocation (optional, improves distance ranking) ---------- */
const Geo = {
  coords: null,
  async request() {
    if (this.coords) return this.coords;
    if (!navigator.geolocation) return null;
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          this.coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          resolve(this.coords);
        },
        () => resolve(null),
        { timeout: 6000 }
      );
    });
  }
};

// Wires a hidden/visible <input type=file> to compress+resolve to a data URI,
// used by every profile-picture and offering-photo uploader in the app.
function wireImagePicker(inputEl, onDataUrl, { maxDim = 480, quality = 0.82 } = {}) {
  inputEl.addEventListener('change', async () => {
    const file = inputEl.files[0];
    if (!file) return;
    try {
      const dataUrl = await compressImageToDataUrl(file, maxDim, quality);
      onDataUrl(dataUrl);
    } catch (e) {
      toast(e.message, 'err');
    } finally {
      inputEl.value = '';
    }
  });
}

// Gondar city centre — the default origin when the browser gives us nothing.
const DEFAULT_ORIGIN = { lat: 12.603, lng: 37.4521 };
