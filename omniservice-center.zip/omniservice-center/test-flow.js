// test-flow.js — end-to-end check of the full service lifecycle.
// Run with the server already listening: node test-flow.js
const BASE = 'http://localhost:3000/api';

async function call(method, path, { token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`${method} ${path} -> ${res.status}: ${text.slice(0, 200)}`);
  }
  if (!res.ok) throw new Error(`${method} ${path} -> ${res.status}: ${JSON.stringify(json)}`);
  return json;
}

const db = require('./src/db');
const ok = (msg) => console.log(`  PASS  ${msg}`);

(async () => {
  console.log('\nOMNISERVICE CENTER — end-to-end lifecycle test\n');

  const health = await call('GET', '/health');
  ok(`API healthy — ${health.providers} providers, ${health.users} users`);

  const cats = await call('GET', '/categories');
  if (cats.length !== 12) throw new Error(`expected 12 sectors, got ${cats.length}`);
  ok(`12 service sectors loaded`);

  // 1. Seeker logs in
  const seeker = await call('POST', '/auth/login', {
    body: { email: 'seeker1@omniservice.center', password: 'demo1234' }
  });
  ok(`Seeker logged in as ${seeker.user.fullName}`);

  // 2. OMNI understands free text
  const ask = await call('POST', '/omni/ask', {
    body: { message: 'my kitchen pipe is leaking badly, need a plumber in Gondar today', lat: 12.603, lng: 37.4521 }
  });
  if (!ask.understood || ask.subcategory.key !== 'plumbing') throw new Error('OMNI failed to detect plumbing');
  if (ask.city !== 'gondar') throw new Error('OMNI failed to detect Gondar');
  if (ask.timing.label !== 'today') throw new Error('OMNI failed to detect timing');
  ok(`OMNI parsed intent=${ask.subcategory.label}, city=${ask.city}, timing=${ask.timing.label}, ${ask.matches.length} matches`);
  ok(`  top match: ${ask.matches[0].businessName} (score ${ask.matches[0].matchScore}) — ${ask.matches[0].reasons.join('; ')}`);

  // OMNI handles something completely different
  const ask2 = await call('POST', '/omni/ask', {
    body: { message: 'I want a tutor to help me prepare for my exams next week' }
  });
  if (ask2.subcategory.key !== 'tutoring') throw new Error('OMNI failed on tutoring query');
  ok(`OMNI parsed a different query: ${ask2.subcategory.label}, timing=${ask2.timing.label}`);

  // OMNI honestly reports when it can't match
  const ask3 = await call('POST', '/omni/ask', { body: { message: 'asdkjh qwe zxcv' } });
  if (ask3.understood) throw new Error('OMNI should not have understood gibberish');
  ok('OMNI correctly reports when it cannot match a query');

  // 3. Seeker posts a request with auto-matching
  const created = await call('POST', '/requests', {
    token: seeker.token,
    body: {
      description: 'my kitchen pipe is leaking badly, need a plumber in Gondar today',
      lat: 12.603,
      lng: 37.4521,
      autoMatch: true
    }
  });
  const requestId = created.request.id;
  if (created.request.status !== 'matching') throw new Error('request should be in matching state');
  ok(`Request created and auto-matched to ${created.request.candidates.length} providers`);

  // 4. Top-matched provider logs in
  const topProviderId = created.analysis.matches[0].providerId;
  const providerProfile = db.find('providerProfiles', (p) => p.id === topProviderId);
  const providerUser = db.find('users', (u) => u.id === providerProfile.userId);
  const provider = await call('POST', '/auth/login', {
    body: { email: providerUser.email, password: 'demo1234' }
  });
  const trustBefore = providerProfile.trustScore;
  ok(`Provider logged in: ${provider.provider.businessName} (trust score ${trustBefore})`);

  // Provider sees the request in their queue
  const queue = await call('GET', '/requests/for-provider', { token: provider.token });
  if (!queue.find((r) => r.id === requestId)) throw new Error('request missing from provider queue');
  ok(`Request appears in provider's incoming queue`);

  // 5. Provider sends a quotation
  const quotation = await call('POST', '/quotations', {
    token: provider.token,
    body: { requestId, price: 1500, message: 'I can be there within 2 hours.', estimatedDays: 1 }
  });
  ok(`Quotation sent: ${quotation.price} ETB`);

  // 6. Seeker sees and accepts it
  const quotes = await call('GET', `/quotations/for-request/${requestId}`, { token: seeker.token });
  if (quotes.length !== 1) throw new Error('seeker should see exactly one quotation');
  const booking = await call('POST', `/quotations/${quotation.id}/accept`, { token: seeker.token, body: {} });
  ok(`Quotation accepted — booking ${booking.id} created`);

  // 7. Schedule -> in progress -> complete
  await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'scheduled', scheduledFor: new Date(Date.now() + 86400000).toISOString() }
  });
  await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'in_progress' }
  });
  await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'completed' }
  });
  ok('Booking moved through scheduled → in progress → completed');

  // 8. Seeker reviews, trust score recalculates
  const review = await call('POST', '/reviews', {
    token: seeker.token,
    body: { bookingId: booking.id, rating: 5, comment: 'Fast, clean work and fair price.' }
  });
  ok(`Review saved — trust score recalculated ${trustBefore} → ${review.newTrustScore}`);
  ok(`  breakdown: ${review.breakdown.completedJobs} jobs, avg rating ${review.breakdown.avgRating}, ${review.breakdown.completionRate}% completion`);

  // 9. Notifications reached both sides
  const providerNotifs = await call('GET', '/notifications', { token: provider.token });
  const seekerNotifs = await call('GET', '/notifications', { token: seeker.token });
  if (!providerNotifs.length || !seekerNotifs.length) throw new Error('notifications missing');
  ok(`Notifications delivered — provider: ${providerNotifs.length}, seeker: ${seekerNotifs.length}`);

  // 10. Messaging between the two parties
  const msg = await call('POST', '/messages', {
    token: seeker.token,
    body: { requestId, toUserId: providerUser.id, body: 'Thanks, the leak is fully fixed.' }
  });
  const thread = await call('GET', `/messages?requestId=${requestId}`, { token: provider.token });
  if (!thread.find((m) => m.id === msg.id)) throw new Error('message not visible to provider');
  ok('Messaging works in both directions');

  // 11. Admin portal
  const admin = await call('POST', '/auth/login', {
    body: { email: 'admin@omniservice.center', password: 'demo1234' }
  });
  const stats = await call('GET', '/admin/stats', { token: admin.token });
  ok(`Admin stats — ${stats.providers.verified} verified providers, ${stats.activity.completedJobs} completed jobs, ${stats.financial.platformCommission} ETB commission`);

  const pending = await call('GET', '/admin/providers?status=pending', { token: admin.token });
  ok(`Verification queue: ${pending.length} pending applications`);

  if (pending.length) {
    const before = pending[0].status;
    await call('PATCH', `/admin/providers/${pending[0].id}/verify`, {
      token: admin.token,
      body: { decision: 'verified', note: 'Documents check out.' }
    });
    ok(`Admin verified a provider (${before} → verified)`);
  }

  const companyReport = await call('GET', '/admin/reports/companies', { token: admin.token });
  const userReport = await call('GET', '/admin/reports/users', { token: admin.token });
  ok(`Reports generated — ${companyReport.length} company rows, ${userReport.length} user rows`);

  // 12. Access control actually blocks
  let blocked = false;
  try {
    await call('GET', '/admin/stats', { token: seeker.token });
  } catch {
    blocked = true;
  }
  if (!blocked) throw new Error('seeker should NOT be able to read admin stats');
  ok('Role-based access control blocks seekers from the admin portal');

  // 13. New provider registration lands in pending, not verified
  const reg = await call('POST', '/auth/register/provider', {
    body: {
      fullName: 'Test Applicant',
      email: `test${Date.now()}@example.com`,
      password: 'test1234',
      businessName: 'Test Electrical Co.',
      subcategoryKeys: ['electrical'],
      categoryKey: 'home_construction',
      city: 'Gondar'
    }
  });
  if (reg.provider.status !== 'pending') throw new Error('new provider should start as pending');
  ok('New provider registration starts as pending, invisible in search until verified');

  console.log('\nAll checks passed.\n');
})().catch((e) => {
  console.error('\n  FAIL  ' + e.message + '\n');
  process.exit(1);
});
