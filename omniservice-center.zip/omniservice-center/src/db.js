// src/db.js
// A real, file-persisted JSON datastore. No native modules required, so the
// project runs anywhere `node` runs. Swap this module out for a SQL/Mongo
// driver later without touching route logic — every route only calls the
// functions exported here.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_PATH = path.join(__dirname, 'data', 'db.json');

const EMPTY = {
  users: [],
  providerProfiles: [],
  categories: [],
  requests: [],
  quotations: [],
  bookings: [],
  reviews: [],
  messages: [],
  notifications: [],
  ads: [],
  promotions: [],
  disputes: []
};

let cache = null;
let saveTimer = null;

function load() {
  if (cache) return cache;
  if (!fs.existsSync(DB_PATH)) {
    cache = JSON.parse(JSON.stringify(EMPTY));
    persist();
    return cache;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  cache = raw.trim() ? JSON.parse(raw) : JSON.parse(JSON.stringify(EMPTY));
  // Ensure every collection exists even if db.json was hand-edited.
  for (const key of Object.keys(EMPTY)) {
    if (!Array.isArray(cache[key])) cache[key] = [];
  }
  return cache;
}

function persist() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(cache, null, 2), 'utf-8');
}

// Debounced save so bursts of writes in one request cycle don't thrash disk.
function save() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    persist();
    saveTimer = null;
  }, 50);
}

// Force an immediate synchronous flush — used by seed script and tests.
function saveSync() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  persist();
}

function id(prefix) {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

function now() {
  return new Date().toISOString();
}

// ---- generic collection helpers -------------------------------------

function all(collection) {
  return load()[collection];
}

function find(collection, predicate) {
  return load()[collection].find(predicate) || null;
}

function filter(collection, predicate) {
  return load()[collection].filter(predicate);
}

function insert(collection, record) {
  const data = load();
  data[collection].push(record);
  save();
  return record;
}

function update(collection, matchId, patch) {
  const data = load();
  const idx = data[collection].findIndex((r) => r.id === matchId);
  if (idx === -1) return null;
  data[collection][idx] = { ...data[collection][idx], ...patch, updatedAt: now() };
  save();
  return data[collection][idx];
}

function remove(collection, matchId) {
  const data = load();
  const before = data[collection].length;
  data[collection] = data[collection].filter((r) => r.id !== matchId);
  save();
  return data[collection].length < before;
}

function resetTo(seedData) {
  cache = seedData;
  saveSync();
}

module.exports = {
  load,
  save,
  saveSync,
  id,
  now,
  all,
  find,
  filter,
  insert,
  update,
  remove,
  resetTo,
  DB_PATH
};
