const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');

const router = express.Router();

function notify(userId, title, body) {
  db.insert('notifications', {
    id: db.id('notif'),
    userId,
    title,
    body,
    read: false,
    createdAt: db.now()
  });
}

// Provider submits a quotation against a request they were matched to.
router.post('/', requireAuth, requireRole('provider'), (req, res) => {
  const { requestId, price, message, estimatedDays, availableFrom } = req.body;
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
  if (provider.status !== 'verified') {
    return res.status(403).json({ error: 'Your account must be verified before you can send quotations.' });
  }

  const request = db.find('requests', (r) => r.id === requestId);
  if (!request) return res.status(404).json({ error: 'Request not found.' });
  if (!['matching', 'responses'].includes(request.status)) {
    return res.status(400).json({ error: 'This request is no longer accepting quotations.' });
  }
  if (db.find('quotations', (q) => q.requestId === requestId && q.providerId === provider.id)) {
    return res.status(409).json({ error: 'You already sent a quotation for this request.' });
  }
  if (typeof price !== 'number' || price <= 0) {
    return res.status(400).json({ error: 'Enter a price in ETB greater than zero.' });
  }

  // Response time feeds the provider's trust score.
  const responseMinutes = Math.max(
    1,
    Math.round((Date.now() - new Date(request.createdAt).getTime()) / 60000)
  );

  const quotation = {
    id: db.id('quo'),
    requestId,
    providerId: provider.id,
    providerName: provider.businessName,
    trustScore: provider.trustScore,
    price,
    message: message || '',
    estimatedDays: estimatedDays || null,
    availableFrom: availableFrom || null,
    responseMinutes,
    status: 'pending',
    createdAt: db.now()
  };
  db.insert('quotations', quotation);

  if (request.status === 'matching') db.update('requests', request.id, { status: 'responses' });
  notify(request.seekerId, 'New quotation received', `${provider.businessName} quoted ${price} ETB for your request.`);

  res.status(201).json(quotation);
});

router.get('/for-request/:requestId', requireAuth, (req, res) => {
  const quotations = db
    .filter('quotations', (q) => q.requestId === req.params.requestId)
    .slice()
    .sort((a, b) => b.trustScore - a.trustScore);
  res.json(quotations);
});

// Seeker accepts a quotation -> creates the booking and closes the others.
router.post('/:id/accept', requireAuth, requireRole('seeker'), (req, res) => {
  const quotation = db.find('quotations', (q) => q.id === req.params.id);
  if (!quotation) return res.status(404).json({ error: 'Quotation not found.' });

  const request = db.find('requests', (r) => r.id === quotation.requestId);
  if (!request) return res.status(404).json({ error: 'Request not found.' });
  if (request.seekerId !== req.user.id) return res.status(403).json({ error: 'This is not your request.' });
  if (db.find('bookings', (b) => b.requestId === request.id)) {
    return res.status(409).json({ error: 'A provider has already been booked for this request.' });
  }

  db.update('quotations', quotation.id, { status: 'accepted' });
  for (const other of db.filter('quotations', (q) => q.requestId === request.id && q.id !== quotation.id)) {
    db.update('quotations', other.id, { status: 'declined' });
    const p = db.find('providerProfiles', (x) => x.id === other.providerId);
    if (p) notify(p.userId, 'Quotation not selected', 'The seeker chose another provider for this request.');
  }

  const booking = {
    id: db.id('bkg'),
    requestId: request.id,
    quotationId: quotation.id,
    providerId: quotation.providerId,
    seekerId: request.seekerId,
    price: quotation.price,
    responseMinutes: quotation.responseMinutes,
    status: 'accepted',
    scheduledFor: req.body.scheduledFor || quotation.availableFrom || null,
    createdAt: db.now()
  };
  db.insert('bookings', booking);
  db.update('requests', request.id, { status: 'accepted' });

  const provider = db.find('providerProfiles', (p) => p.id === quotation.providerId);
  if (provider) notify(provider.userId, 'Quotation accepted', 'You have been booked. Confirm the schedule with the seeker.');

  res.status(201).json(booking);
});

router.get('/bookings/mine', requireAuth, (req, res) => {
  let bookings;
  if (req.user.role === 'provider') {
    const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
    if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
    bookings = db.filter('bookings', (b) => b.providerId === provider.id && !b.isDemoData);
  } else {
    bookings = db.filter('bookings', (b) => b.seekerId === req.user.id && !b.isDemoData);
  }

  const enriched = bookings
    .slice()
    .reverse()
    .map((b) => ({
      ...b,
      request: db.find('requests', (r) => r.id === b.requestId),
      provider: db.find('providerProfiles', (p) => p.id === b.providerId),
      review: db.find('reviews', (r) => r.bookingId === b.id)
    }));
  res.json(enriched);
});

router.patch('/bookings/:id/status', requireAuth, (req, res) => {
  const { status, scheduledFor } = req.body;
  const valid = ['accepted', 'scheduled', 'in_progress', 'completed', 'cancelled'];
  if (!valid.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${valid.join(', ')}.` });
  }
  const booking = db.find('bookings', (b) => b.id === req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found.' });

  const patch = { status };
  if (scheduledFor) patch.scheduledFor = scheduledFor;
  const updated = db.update('bookings', booking.id, patch);

  const requestStatusMap = {
    scheduled: 'scheduled',
    in_progress: 'in_progress',
    completed: 'completed',
    cancelled: 'cancelled'
  };
  if (requestStatusMap[status]) db.update('requests', booking.requestId, { status: requestStatusMap[status] });

  if (status === 'completed') notify(booking.seekerId, 'Job marked complete', 'Confirm the work and leave a review.');

  res.json(updated);
});

module.exports = router;
