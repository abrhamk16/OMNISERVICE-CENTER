const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');
const { computeTrustScore } = require('../trustScore');

const router = express.Router();

// Public search/browse — filter by category, subcategory, city, min trust score.
router.get('/', (req, res) => {
  const { categoryKey, subcategoryKey, city, minTrust, availability } = req.query;
  let providers = db.filter('providerProfiles', (p) => p.status === 'verified');

  if (categoryKey) providers = providers.filter((p) => p.categoryKey === categoryKey);
  if (subcategoryKey) providers = providers.filter((p) => p.subcategoryKeys.includes(subcategoryKey));
  if (city) providers = providers.filter((p) => p.city.toLowerCase().includes(city.toLowerCase()));
  if (minTrust) providers = providers.filter((p) => p.trustScore >= Number(minTrust));
  if (availability) providers = providers.filter((p) => p.availability === availability);

  providers = providers.slice().sort((a, b) => b.trustScore - a.trustScore);
  res.json(providers);
});

router.get('/:id', (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  res.json(provider);
});

router.get('/:id/reviews', (req, res) => {
  const reviews = db.filter('reviews', (r) => r.providerId === req.params.id).slice().reverse();
  res.json(reviews);
});

// Provider viewing/editing their own profile
router.get('/me/profile', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
  res.json(provider);
});

router.patch('/me/profile', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });

  const allowed = ['businessName', 'bio', 'city', 'lat', 'lng', 'priceIndex', 'availability', 'subcategoryKeys', 'categoryKey'];
  const patch = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  const updated = db.update('providerProfiles', provider.id, patch);
  res.json(updated);
});

// Recompute a provider's trust score from current bookings/reviews (used after each completed job).
router.post('/:id/recompute-trust', requireAuth, (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  const reviews = db.filter('reviews', (r) => r.providerId === provider.id);
  const bookings = db.filter('bookings', (b) => b.providerId === provider.id);
  const { score, breakdown } = computeTrustScore({ reviews, bookings });
  const updated = db.update('providerProfiles', provider.id, { trustScore: score });
  res.json({ trustScore: updated.trustScore, breakdown });
});

module.exports = router;
