/* ============================================================
   admin.js — the Admin Command Center.
   Per spec: every Seeker and Provider feature, plus Reports
   (users and companies) and Start Apps.
   ============================================================ */

const Admin = {
  nav: [
    { key: 'overview', label: 'Overview', icon: '📊' },
    { key: 'verify', label: 'Verification', icon: '✓' },
    { key: 'providers', label: 'Providers', icon: '🛠️' },
    { key: 'users', label: 'Users', icon: '👥' },
    { key: 'requests', label: 'Requests', icon: '📋' },
    { key: 'services', label: 'Services', icon: '🧭' },
    { key: 'map', label: 'Map', icon: '🗺️' },
    { key: 'omni', label: 'AI Agent', icon: '✦' },
    { key: 'reports', label: 'Reports', icon: '📑' },
    { key: 'apps', label: 'Start Apps', icon: '⚡' },
    { key: 'contact', label: 'Contact', icon: '✉️' }
  ],

  categories: [],

  async mount(root, page = 'overview') {
    if (!this.categories.length) this.categories = await API.categories().catch(() => []);
    Seeker.categories = this.categories;

    let pendingCount = 0;
    try {
      pendingCount = (await API.adminProviders('pending')).length;
    } catch {}

    const nav = this.nav.map((n) => (n.key === 'verify' && pendingCount ? { ...n, count: pendingCount } : n));

    Shell.render(root, {
      role: 'admin',
      nav,
      active: page,
      onNav: (key) => router.go('/admin/' + key),
      title: (this.nav.find((n) => n.key === page) || this.nav[0]).label
    });
    this.renderPage(el('#page'), page);
  },

  renderPage(host, page) {
    const fn = {
      overview: () => this.overview(host),
      verify: () => this.verify(host),
      providers: () => this.providers(host),
      users: () => this.users(host),
      requests: () => this.requests(host),
      services: () => Seeker.services(host),
      map: () => Seeker.map(host),
      omni: () => Seeker.omni(host),
      reports: () => this.reports(host),
      apps: () => this.apps(host),
      contact: () => this.contact(host)
    }[page];
    (fn || (() => this.overview(host)))();
  },

  /* ---------------- OVERVIEW ---------------- */
  async overview(host) {
    host.innerHTML = `<div class="empty"><span class="spinner"></span></div>`;
    try {
      const s = await API.adminStats();
      const maxSector = Math.max(...s.bySector.map((x) => x.providers), 1);
      const maxRating = Math.max(...s.ratingSpread.map((r) => r.count), 1);

      host.innerHTML = `
        <div class="stat-grid mb-6">
          <div class="stat stat-accent">
            <div class="stat-label">Verified providers</div>
            <div class="stat-value">${s.providers.verified}</div>
            <div class="stat-note">${s.providers.pending} awaiting review</div>
          </div>
          <div class="stat">
            <div class="stat-label">Registered users</div>
            <div class="stat-value">${s.users.total}</div>
            <div class="stat-note">${s.users.seekers} seekers · ${s.users.providers} providers</div>
          </div>
          <div class="stat">
            <div class="stat-label">Completed jobs</div>
            <div class="stat-value">${s.activity.completedJobs}</div>
            <div class="stat-note">${s.activity.bookings} bookings total</div>
          </div>
          <div class="stat">
            <div class="stat-label">Platform commission</div>
            <div class="stat-value">${money(s.financial.platformCommission)}</div>
            <div class="stat-note">${Math.round(s.financial.commissionRate * 100)}% of ${money(s.financial.grossBookingValue)}</div>
          </div>
          <div class="stat">
            <div class="stat-label">Average trust score</div>
            <div class="stat-value">${s.providers.avgTrustScore}</div>
            <div class="stat-note">Across verified providers</div>
          </div>
          <div class="stat">
            <div class="stat-label">Open disputes</div>
            <div class="stat-value">${s.activity.openDisputes}</div>
            <div class="stat-note">${s.activity.reviews} reviews submitted</div>
          </div>
        </div>

        <div class="chart-grid mb-6">
          <div class="chart-box">
            <h3>Verified providers by sector</h3>
            <div class="bars">
              ${s.bySector
                .slice()
                .sort((a, b) => b.providers - a.providers)
                .map(
                  (x) => `
                <div class="bar-row">
                  <div>
                    <div class="bar-label">${x.icon} ${esc(x.label)}</div>
                    <div class="bar-track"><div class="bar-fill" style="width:${(x.providers / maxSector) * 100}%"></div></div>
                  </div>
                  <div class="bar-num">${x.providers}</div>
                </div>`
                )
                .join('')}
            </div>
          </div>

          <div class="chart-box">
            <h3>Review ratings</h3>
            <div class="bars">
              ${s.ratingSpread
                .slice()
                .reverse()
                .map(
                  (r) => `
                <div class="bar-row">
                  <div>
                    <div class="bar-label">${stars(r.star)}</div>
                    <div class="bar-track"><div class="bar-fill" style="width:${(r.count / maxRating) * 100}%"></div></div>
                  </div>
                  <div class="bar-num">${r.count}</div>
                </div>`
                )
                .join('')}
            </div>
            <div class="notice notice-blue mt-6">
              <span>ⓘ</span>
              <div>Every rating here feeds directly into a provider's trust score.</div>
            </div>
          </div>
        </div>

        <div class="panel">
          <h3 style="font-size:16px" class="mb-4">Requests by lifecycle state</h3>
          <div class="row gap-2" style="flex-wrap:wrap">
            ${Object.entries(s.byStatus)
              .sort((a, b) => b[1] - a[1])
              .map(([k, v]) => `<span class="badge">${esc(STATUS_LABELS[k] || k)} · ${v}</span>`)
              .join('')}
          </div>
        </div>`;
    } catch (e) {
      host.innerHTML = `<div class="empty"><h3>Couldn't load platform stats</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  /* ---------------- VERIFICATION QUEUE ---------------- */
  async verify(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div>
          <h2>Verification queue</h2>
          <p>Providers stay invisible to seekers until you approve them.</p>
        </div>
      </div>
      <div id="verify-list"><div class="empty"><span class="spinner"></span></div></div>`;

    const load = async () => {
      try {
        const pending = await API.adminProviders('pending');
        el('#verify-list').innerHTML = pending.length
          ? `<div class="stack gap-3">${pending
              .map(
                (p) => `
            <div class="rq-card">
              <div class="rq-head">
                <div class="grow">
                  <div class="row gap-2" style="flex-wrap:wrap">
                    <span style="font-family:var(--font-head);font-weight:600;font-size:16px">${esc(p.businessName)}</span>
                    ${p.isDemoData ? '<span class="demo-flag">Demo data</span>' : ''}
                  </div>
                  <div class="rq-meta">
                    <span>${esc(p.ownerName)}</span>
                    <span>${esc(p.city || 'No city given')}</span>
                    ${p.contact ? `<span>${esc(p.contact.email)}</span>` : ''}
                    ${p.contact && p.contact.phone ? `<span>${esc(p.contact.phone)}</span>` : ''}
                    <span>Applied ${timeAgo(p.createdAt)}</span>
                  </div>
                  ${p.bio ? `<div class="provider-bio">${esc(p.bio)}</div>` : ''}
                  <div class="provider-tags">
                    ${p.subcategoryKeys.map((k) => `<span class="sector-sub">${esc(this.labelFor(k))}</span>`).join('')}
                    <span class="badge">${p.yearsActive || 0} years active</span>
                    <span class="badge">${p.documents && p.documents.length ? p.documents.length + ' document(s)' : 'No documents uploaded'}</span>
                  </div>
                </div>
                ${statusBadge(p.status)}
              </div>
              <div class="row gap-2 mt-4">
                <button class="btn btn-primary btn-sm" data-approve="${p.id}">Approve and publish</button>
                <button class="btn btn-danger btn-sm" data-reject="${p.id}">Reject</button>
              </div>
            </div>`
              )
              .join('')}</div>`
          : `<div class="empty"><h3>Queue is clear</h3><p>No provider applications are waiting for review.</p></div>`;

        els('[data-approve]').forEach((btn) => {
          btn.onclick = async () => {
            btn.disabled = true;
            try {
              await API.adminVerify(btn.dataset.approve, 'verified', 'Documents reviewed.');
              toast('Provider verified and now visible in search.', 'ok');
              load();
            } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
          };
        });

        els('[data-reject]').forEach((btn) => {
          btn.onclick = () => {
            openModal(
              'Reject this application',
              `
              <div class="field">
                <label for="rj-note">Reason (sent to the provider)</label>
                <textarea class="textarea" id="rj-note" placeholder="e.g. Business licence was unreadable — please upload a clearer copy."></textarea>
              </div>
              <button class="btn btn-danger btn-block" id="rj-go">Reject application</button>`,
              (body) => {
                el('#rj-go', body).onclick = async (ev) => {
                  ev.target.disabled = true;
                  try {
                    await API.adminVerify(btn.dataset.reject, 'rejected', el('#rj-note', body).value.trim());
                    closeModal();
                    toast('Application rejected and the provider notified.');
                    load();
                  } catch (e) { toast(e.message, 'err'); ev.target.disabled = false; }
                };
              }
            );
          };
        });
      } catch (e) {
        el('#verify-list').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
      }
    };
    load();
  },

  labelFor(subKey) {
    for (const c of this.categories) {
      const s = c.subcategories.find((x) => x.key === subKey);
      if (s) return s.label;
    }
    return subKey;
  },

  /* ---------------- PROVIDERS ---------------- */
  async providers(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div><h2>All providers</h2><p>Every listed business and its current standing.</p></div>
      </div>
      <div class="filters">
        <div class="field">
          <label for="pf-status">Status</label>
          <select class="select" id="pf-status">
            <option value="">All statuses</option>
            <option value="verified">Verified</option>
            <option value="pending">Pending review</option>
            <option value="rejected">Rejected</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
        <div class="field">
          <label for="pf-search">Search</label>
          <input class="input" id="pf-search" placeholder="Business or city">
        </div>
      </div>
      <div id="prov-table"><div class="empty"><span class="spinner"></span></div></div>`;

    let all = [];
    const paint = () => {
      const status = el('#pf-status').value;
      const q = el('#pf-search').value.trim().toLowerCase();
      const rows = all.filter(
        (p) =>
          (!status || p.status === status) &&
          (!q || p.businessName.toLowerCase().includes(q) || (p.city || '').toLowerCase().includes(q))
      );

      el('#prov-table').innerHTML = rows.length
        ? `<div class="table-wrap"><table>
            <thead><tr>
              <th>Business</th><th>City</th><th>Services</th>
              <th class="num">Trust</th><th class="num">Jobs</th><th class="num">Reviews</th>
              <th>Status</th><th></th>
            </tr></thead>
            <tbody>${rows
              .map(
                (p) => `
              <tr>
                <td>
                  <div style="font-weight:500">${esc(p.businessName)}</div>
                  <div class="small muted">${esc(p.ownerName)}${p.isDemoData ? ' · demo' : ''}</div>
                </td>
                <td class="small">${esc(p.city || '—')}</td>
                <td class="small">${esc(p.subcategoryKeys.map((k) => this.labelFor(k)).join(', '))}</td>
                <td class="num">${p.trustScore}</td>
                <td class="num">${p.completedJobs}</td>
                <td class="num">${p.reviewCount}</td>
                <td>${statusBadge(p.status)}</td>
                <td>
                  <select class="select" data-set="${p.id}" style="padding:5px 28px 5px 9px;font-size:12.5px">
                    <option value="">Change…</option>
                    <option value="verified">Verify</option>
                    <option value="suspended">Suspend</option>
                    <option value="rejected">Reject</option>
                    <option value="pending">Back to review</option>
                  </select>
                </td>
              </tr>`
              )
              .join('')}</tbody></table></div>`
        : `<div class="empty"><h3>Nothing matches those filters</h3><p>Try a different status or search term.</p></div>`;

      els('[data-set]').forEach((sel) => {
        sel.onchange = async () => {
          if (!sel.value) return;
          try {
            await API.adminVerify(sel.dataset.set, sel.value, 'Changed from the admin console.');
            toast('Provider status updated.', 'ok');
            all = await API.adminProviders();
            paint();
          } catch (e) { toast(e.message, 'err'); }
        };
      });
    };

    try {
      all = await API.adminProviders();
      el('#pf-status').onchange = paint;
      el('#pf-search').oninput = paint;
      paint();
    } catch (e) {
      el('#prov-table').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  },

  /* ---------------- USERS ---------------- */
  async users(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div><h2>Users</h2><p>Everyone registered on the platform.</p></div>
      </div>
      <div class="tabs" id="user-tabs">
        <button class="tab active" data-role="">All</button>
        <button class="tab" data-role="seeker">Seekers</button>
        <button class="tab" data-role="provider">Providers</button>
        <button class="tab" data-role="admin">Admins</button>
      </div>
      <div id="user-table"><div class="empty"><span class="spinner"></span></div></div>`;

    const load = async (role) => {
      el('#user-table').innerHTML = `<div class="empty"><span class="spinner"></span></div>`;
      try {
        const users = await API.adminUsers(role);
        el('#user-table').innerHTML = `<div class="table-wrap"><table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>City</th><th class="num">Requests</th><th>Joined</th></tr></thead>
          <tbody>${users
            .map(
              (u) => `
            <tr>
              <td style="font-weight:500">${esc(u.fullName)}${u.isDemoData ? ' <span class="demo-flag">demo</span>' : ''}</td>
              <td class="small">${esc(u.email)}</td>
              <td><span class="badge ${u.role === 'admin' ? 'badge-violet' : u.role === 'provider' ? 'badge-blue' : ''}">${u.role}</span></td>
              <td class="small">${esc(u.city || '—')}</td>
              <td class="num">${u.requestCount}</td>
              <td class="small muted">${timeAgo(u.createdAt)}</td>
            </tr>`
            )
            .join('')}</tbody></table></div>`;
      } catch (e) {
        el('#user-table').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
      }
    };

    els('#user-tabs .tab').forEach((tab) => {
      tab.onclick = () => {
        els('#user-tabs .tab').forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');
        load(tab.dataset.role);
      };
    });
    load('');
  },

  /* ---------------- REQUESTS MONITOR ---------------- */
  async requests(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div><h2>Request monitor</h2><p>Live view of every request moving through the platform.</p></div>
      </div>
      <div id="req-table"><div class="empty"><span class="spinner"></span></div></div>`;

    try {
      const rows = await API.adminRequests();
      el('#req-table').innerHTML = rows.length
        ? `<div class="table-wrap"><table>
            <thead><tr><th>Request</th><th>Seeker</th><th>City</th><th>Status</th><th class="num">Matched</th><th>Posted</th></tr></thead>
            <tbody>${rows
              .map(
                (r) => `
              <tr>
                <td style="max-width:360px">
                  <div style="font-size:13.5px">${esc(r.description.slice(0, 110))}${r.description.length > 110 ? '…' : ''}</div>
                  ${r.isDemoData ? '<span class="demo-flag mt-2">demo</span>' : ''}
                </td>
                <td class="small">${esc(r.seeker)}</td>
                <td class="small">${esc(r.city || '—')}</td>
                <td>${statusBadge(r.status)}</td>
                <td class="num">${(r.candidates || []).length}</td>
                <td class="small muted">${timeAgo(r.createdAt)}</td>
              </tr>`
              )
              .join('')}</tbody></table></div>`
        : `<div class="empty"><h3>No requests yet</h3><p>Requests appear here the moment a seeker posts one.</p></div>`;
    } catch (e) {
      el('#req-table').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  },

  /* ---------------- REPORTS ---------------- */
  async reports(host) {
    host.innerHTML = `
      <div class="panel-head">
        <div><h2>Reports</h2><p>Performance across companies and users. Export any table as CSV.</p></div>
      </div>
      <div class="tabs" id="rep-tabs">
        <button class="tab active" data-rep="companies">Companies and organizations</button>
        <button class="tab" data-rep="users">Users</button>
      </div>
      <div id="rep-body"><div class="empty"><span class="spinner"></span></div></div>`;

    const loadCompanies = async () => {
      const rows = await API.reportCompanies();
      el('#rep-body').innerHTML = `
        <div class="row gap-2 mb-4" style="justify-content:flex-end">
          <button class="btn btn-ghost btn-sm" id="csv">Export CSV</button>
        </div>
        <div class="table-wrap"><table>
          <thead><tr>
            <th>Business</th><th>City</th><th class="num">Trust</th><th class="num">Jobs</th>
            <th class="num">Completion</th><th class="num">Rating</th><th class="num">Revenue</th><th class="num">Commission</th>
          </tr></thead>
          <tbody>${rows
            .map(
              (r) => `
            <tr>
              <td style="font-weight:500">${esc(r.businessName)}${r.isDemoData ? ' <span class="demo-flag">demo</span>' : ''}</td>
              <td class="small">${esc(r.city)}</td>
              <td class="num">${r.trustScore}</td>
              <td class="num">${r.completedJobs}/${r.totalJobs}</td>
              <td class="num">${r.completionRate}%</td>
              <td class="num">${r.avgRating ?? '—'}</td>
              <td class="num">${money(r.revenue)}</td>
              <td class="num">${money(r.commission)}</td>
            </tr>`
            )
            .join('')}</tbody></table></div>`;
      el('#csv').onclick = () =>
        this.downloadCSV(
          'omniservice-company-report.csv',
          ['Business', 'City', 'Trust score', 'Completed jobs', 'Total jobs', 'Completion %', 'Avg rating', 'Revenue ETB', 'Commission ETB'],
          rows.map((r) => [r.businessName, r.city, r.trustScore, r.completedJobs, r.totalJobs, r.completionRate, r.avgRating ?? '', r.revenue, r.commission])
        );
    };

    const loadUsers = async () => {
      const rows = await API.reportUsers();
      el('#rep-body').innerHTML = `
        <div class="row gap-2 mb-4" style="justify-content:flex-end">
          <button class="btn btn-ghost btn-sm" id="csv">Export CSV</button>
        </div>
        <div class="table-wrap"><table>
          <thead><tr>
            <th>Name</th><th>Email</th><th>City</th><th class="num">Requests</th>
            <th class="num">Bookings</th><th class="num">Reviews left</th><th class="num">Total spend</th><th>Joined</th>
          </tr></thead>
          <tbody>${rows
            .map(
              (r) => `
            <tr>
              <td style="font-weight:500">${esc(r.fullName)}${r.isDemoData ? ' <span class="demo-flag">demo</span>' : ''}</td>
              <td class="small">${esc(r.email)}</td>
              <td class="small">${esc(r.city)}</td>
              <td class="num">${r.requests}</td>
              <td class="num">${r.bookings}</td>
              <td class="num">${r.reviewsLeft}</td>
              <td class="num">${money(r.totalSpend)}</td>
              <td class="small muted">${timeAgo(r.joinedAt)}</td>
            </tr>`
            )
            .join('')}</tbody></table></div>`;
      el('#csv').onclick = () =>
        this.downloadCSV(
          'omniservice-user-report.csv',
          ['Name', 'Email', 'City', 'Requests', 'Bookings', 'Reviews left', 'Total spend ETB', 'Joined'],
          rows.map((r) => [r.fullName, r.email, r.city, r.requests, r.bookings, r.reviewsLeft, r.totalSpend, r.joinedAt])
        );
    };

    els('#rep-tabs .tab').forEach((tab) => {
      tab.onclick = () => {
        els('#rep-tabs .tab').forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');
        el('#rep-body').innerHTML = `<div class="empty"><span class="spinner"></span></div>`;
        tab.dataset.rep === 'companies' ? loadCompanies() : loadUsers();
      };
    });

    loadCompanies();
  },

  downloadCSV(filename, headers, rows) {
    const escape = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = [headers.map(escape).join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
    toast('Report downloaded.', 'ok');
  },

  /* ---------------- START APPS ---------------- */
  apps(host) {
    const tools = [
      {
        icon: '✦',
        name: 'OMNI matching console',
        desc: 'Run the matching engine against any phrasing and inspect exactly what it extracted and how it ranked.',
        action: () => router.go('/admin/omni')
      },
      {
        icon: '🗺️',
        name: 'Coverage map',
        desc: 'See where providers are concentrated and which areas have no coverage for a given service.',
        action: () => router.go('/admin/map')
      },
      {
        icon: '✓',
        name: 'Verification queue',
        desc: 'Work through pending provider applications.',
        action: () => router.go('/admin/verify')
      },
      {
        icon: '📑',
        name: 'Report builder',
        desc: 'Company and user performance tables, exportable as CSV.',
        action: () => router.go('/admin/reports')
      },
      {
        icon: '🔄',
        name: 'Recalculate all trust scores',
        desc: 'Force a fresh trust-score calculation across every provider from current job and review history.',
        action: async () => {
          toast('Recalculating…');
          try {
            const providers = await API.adminProviders('verified');
            let done = 0;
            for (const p of providers.slice(0, 40)) {
              await fetch(`/api/providers/${p.id}/recompute-trust`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${Session.token}`, 'Content-Type': 'application/json' }
              });
              done++;
            }
            toast(`Recalculated ${done} provider scores.`, 'ok');
          } catch (e) { toast(e.message, 'err'); }
        }
      },
      {
        icon: '🩺',
        name: 'API health check',
        desc: 'Confirm the backend is reachable and see current record counts.',
        action: async () => {
          try {
            const r = await fetch('/api/health').then((x) => x.json());
            openModal(
              'API health',
              `<div class="stack gap-3">
                <div class="row gap-3" style="justify-content:space-between"><span class="muted">Status</span><span class="badge badge-green">${esc(r.status)}</span></div>
                <div class="row gap-3" style="justify-content:space-between"><span class="muted">Providers</span><span>${r.providers}</span></div>
                <div class="row gap-3" style="justify-content:space-between"><span class="muted">Users</span><span>${r.users}</span></div>
                <div class="row gap-3" style="justify-content:space-between"><span class="muted">Server time</span><span class="small">${new Date(r.time).toLocaleString()}</span></div>
              </div>`
            );
          } catch (e) { toast('API unreachable.', 'err'); }
        }
      }
    ];

    host.innerHTML = `
      <div class="panel-head">
        <div><h2>Start apps</h2><p>Operational tools for running the platform.</p></div>
      </div>
      <div class="sector-grid">
        ${tools
          .map(
            (t, i) => `
          <button class="sector-card" data-tool="${i}">
            <div class="sector-icon">${t.icon}</div>
            <h3>${esc(t.name)}</h3>
            <div class="sector-meta" style="margin-top:6px;line-height:1.5">${esc(t.desc)}</div>
          </button>`
          )
          .join('')}
      </div>`;

    els('[data-tool]').forEach((btn) => {
      btn.onclick = () => tools[Number(btn.dataset.tool)].action();
    });
  },

  /* ---------------- CONTACT ---------------- */
  contact(host) {
    host.innerHTML = `
      <div class="chart-grid">
        <div class="panel">
          <h2 style="font-size:19px" class="mb-4">Platform contacts</h2>
          <div class="stack gap-4">
            <div><div class="small muted">General support</div><div>support@omniservice.center</div></div>
            <div><div class="small muted">Provider verification</div><div>verify@omniservice.center</div></div>
            <div><div class="small muted">Disputes</div><div>disputes@omniservice.center</div></div>
            <div><div class="small muted">Launch city</div><div>Gondar, Amhara Region, Ethiopia</div></div>
          </div>
          <div class="notice notice-blue mt-6">
            <span>ⓘ</span>
            <div>Contact details above are placeholders for this build, not live support channels.</div>
          </div>
        </div>
        <div class="panel">
          <h2 style="font-size:19px" class="mb-4">About this build</h2>
          <div class="stack gap-3 small" style="color:var(--ink-soft)">
            <div>OMNISERVICE CENTER runs on a Node and Express backend with a JSON-backed data store, and a
            vanilla JavaScript frontend with no build step.</div>
            <div>The OMNI matching engine is real code — keyword and synonym scoring with city and timing
            extraction, then provider ranking on trust score, distance, availability and price.</div>
            <div>Provider records, reviews and job history in this build are generated demo data and are
            flagged as such everywhere they appear.</div>
          </div>
        </div>
      </div>`;
  }
};
