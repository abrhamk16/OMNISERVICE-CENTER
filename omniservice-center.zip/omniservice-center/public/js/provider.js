/* ============================================================
   provider.js — the Service Provider stream.
   Sidebar per spec: Home, About, Service Deal, Advertisement,
   Promotion, Contact.
   ============================================================ */

const Provider = {
  nav: [
    { key: 'home', label: 'Home', icon: '🏠' },
    { key: 'about', label: 'About', icon: 'ℹ️' },
    { key: 'deals', label: 'Service Deal', icon: '🤝' },
    { key: 'ads', label: 'Advertisement', icon: '📣' },
    { key: 'promotion', label: 'Promotion', icon: '🚀' },
    { key: 'contact', label: 'Contact', icon: '✉️' }
  ],

  categories: [],
  profile: null,

  async mount(root, page = 'home') {
    if (!this.categories.length) this.categories = await API.categories().catch(() => []);
    try {
      this.profile = await API.myProviderProfile();
      Session.provider = this.profile;
    } catch {
      this.profile = Session.provider;
    }

    Shell.render(root, {
      role: 'provider',
      nav: this.nav,
      active: page,
      onNav: (key) => router.go('/provider/' + key),
      title: (this.nav.find((n) => n.key === page) || this.nav[0]).label
    });
    this.renderPage(el('#page'), page);
  },

  renderPage(host, page) {
    const fn = {
      home: () => this.home(host),
      about: () => this.about(host),
      deals: () => this.deals(host),
      ads: () => this.ads(host),
      promotion: () => this.promotion(host),
      contact: () => this.contact(host)
    }[page];
    (fn || (() => this.home(host)))();
  },

  statusNotice() {
    const p = this.profile;
    if (!p) return '';
    if (p.status === 'verified') {
      return `<div class="notice notice-green mb-6"><span>✓</span>
        <div><b>Your listing is live.</b> You appear in search and OMNI can match requests to you.</div></div>`;
    }
    if (p.status === 'pending') {
      return `<div class="notice notice-amber mb-6"><span>ⓘ</span>
        <div><b>Your application is under review.</b> You won't appear in search or receive matched requests
        until an admin verifies your business. You can still complete your profile below.</div></div>`;
    }
    if (p.status === 'rejected') {
      return `<div class="notice notice-amber mb-6"><span>ⓘ</span>
        <div><b>Your application wasn't approved.</b>${p.reviewNote ? ` Reason given: ${esc(p.reviewNote)}` : ''}
        Update your details and contact support to reapply.</div></div>`;
    }
    if (p.status === 'suspended') {
      return `<div class="notice notice-amber mb-6"><span>ⓘ</span>
        <div><b>Your account is suspended.</b> Contact platform support to resolve this.</div></div>`;
    }
    return '';
  },

  /* ---------------- HOME ---------------- */
  async home(host) {
    const p = this.profile;
    host.innerHTML = `
      ${this.statusNotice()}
      <div class="panel mb-6">
        <div class="panel-head">
          <div>
            <h2>${esc(p ? p.businessName : 'Your business')}</h2>
            <p>${esc(p ? p.city : '')} ${p && p.yearsActive ? `· ${p.yearsActive} years active` : ''}</p>
          </div>
          <div class="row gap-3">
            ${p ? trustRing(p.trustScore) : ''}
            <button class="btn btn-ghost btn-sm" id="edit-profile">Edit profile</button>
          </div>
        </div>
        <div class="stat-grid" id="p-stats">
          ${['Incoming requests', 'Quotations sent', 'Active jobs', 'Completed jobs']
            .map(
              (l) => `<div class="stat"><div class="stat-label">${l}</div>
              <div class="stat-value"><span class="skeleton" style="display:inline-block;width:36px;height:26px"></span></div></div>`
            )
            .join('')}
        </div>
      </div>

      <div class="panel mb-6">
        <div class="panel-head">
          <div>
            <h2>Incoming requests</h2>
            <p>Requests OMNI matched to your services. Respond fast — response time feeds your trust score.</p>
          </div>
        </div>
        <div id="queue"><div class="empty"><span class="spinner"></span></div></div>
      </div>

      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>Your jobs</h2>
            <p>Everything you've been booked for, and where each job stands.</p>
          </div>
        </div>
        <div id="jobs"><div class="empty"><span class="spinner"></span></div></div>
      </div>`;

    el('#edit-profile').onclick = () => this.openProfileEditor();
    await this.loadQueue();
    await this.loadJobs();
  },

  async loadQueue() {
    const host = el('#queue');
    if (!host) return;
    try {
      const queue = await API.providerQueue();
      const open = queue.filter((r) => !r.myQuotation);

      host.innerHTML = queue.length
        ? `<div class="stack gap-3">${queue
            .map(
              (r) => `
          <div class="rq-card">
            <div class="rq-head">
              <div class="grow">
                <div class="rq-desc">${esc(r.description)}</div>
                <div class="rq-meta">
                  <span>${esc(r.seeker ? r.seeker.fullName : 'Seeker')}</span>
                  <span>${esc(r.city || 'Location not set')}</span>
                  <span>Posted ${timeAgo(r.createdAt)}</span>
                  ${r.budget ? `<span>Budget ${money(r.budget)}</span>` : ''}
                  ${r.timing && r.timing.label !== 'flexible' ? `<span>Needs it ${esc(r.timing.label)}</span>` : ''}
                </div>
              </div>
              ${statusBadge(r.status)}
            </div>
            <div class="row gap-2 mt-4">
              ${
                r.myQuotation
                  ? `<span class="badge badge-blue">You quoted ${money(r.myQuotation.price)}</span>
                     <span class="badge">${STATUS_LABELS[r.myQuotation.status] || r.myQuotation.status}</span>`
                  : `<button class="btn btn-primary btn-sm" data-quote="${r.id}">Send quotation</button>`
              }
            </div>
          </div>`
            )
            .join('')}</div>`
        : `<div class="empty">
            <h3>No matched requests right now</h3>
            <p>${
              this.profile && this.profile.status === 'verified'
                ? 'When a seeker posts a job in your service area, it will appear here.'
                : 'Once an admin verifies your business, matched requests will appear here.'
            }</p>
          </div>`;

      els('[data-quote]', host).forEach((btn) => {
        btn.onclick = () => this.openQuoteModal(btn.dataset.quote);
      });

      const stats = el('#p-stats');
      if (stats) {
        const bookings = await API.myBookings().catch(() => []);
        const quoted = queue.filter((r) => r.myQuotation).length;
        const active = bookings.filter((b) => ['accepted', 'scheduled', 'in_progress'].includes(b.status)).length;
        const done = bookings.filter((b) => b.status === 'completed').length;
        stats.innerHTML = `
          <div class="stat ${open.length ? 'stat-accent' : ''}">
            <div class="stat-label">Incoming requests</div><div class="stat-value">${open.length}</div>
            <div class="stat-note">${open.length ? 'Awaiting your quotation' : 'Nothing waiting'}</div>
          </div>
          <div class="stat"><div class="stat-label">Quotations sent</div><div class="stat-value">${quoted}</div></div>
          <div class="stat"><div class="stat-label">Active jobs</div><div class="stat-value">${active}</div></div>
          <div class="stat"><div class="stat-label">Completed jobs</div><div class="stat-value">${done}</div></div>`;
      }
    } catch (e) {
      host.innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  },

  async loadJobs() {
    const host = el('#jobs');
    if (!host) return;
    try {
      const bookings = (await API.myBookings()).filter((b) => !b.isDemoData);
      host.innerHTML = bookings.length
        ? `<div class="stack gap-3">${bookings
            .map(
              (b) => `
          <div class="rq-card">
            <div class="rq-head">
              <div class="grow">
                <div class="rq-desc">${esc(b.request ? b.request.description : 'Job')}</div>
                <div class="rq-meta">
                  <span>${money(b.price)}</span>
                  <span>Booked ${timeAgo(b.createdAt)}</span>
                  ${b.scheduledFor ? `<span>Scheduled ${new Date(b.scheduledFor).toLocaleDateString()}</span>` : ''}
                </div>
              </div>
              ${statusBadge(b.status)}
            </div>
            ${
              b.review
                ? `<div class="card mt-4" style="padding:12px 14px">
                     <div class="row gap-2">${stars(b.review.rating)} <span class="small muted">${timeAgo(b.review.createdAt)}</span></div>
                     ${b.review.comment ? `<div class="small mt-2" style="color:var(--ink-soft)">${esc(b.review.comment)}</div>` : ''}
                   </div>`
                : ''
            }
            <div class="row gap-2 mt-4">
              ${
                b.status === 'accepted'
                  ? `<button class="btn btn-ghost btn-sm" data-advance="${b.id}" data-to="scheduled">Confirm schedule</button>`
                  : ''
              }
              ${
                b.status === 'scheduled'
                  ? `<button class="btn btn-ghost btn-sm" data-advance="${b.id}" data-to="in_progress">Start job</button>`
                  : ''
              }
              ${
                b.status === 'in_progress'
                  ? `<button class="btn btn-primary btn-sm" data-advance="${b.id}" data-to="completed">Mark complete</button>`
                  : ''
              }
              ${
                ['accepted', 'scheduled'].includes(b.status)
                  ? `<button class="btn btn-quiet btn-sm" data-advance="${b.id}" data-to="cancelled">Cancel</button>`
                  : ''
              }
            </div>
          </div>`
            )
            .join('')}</div>`
        : `<div class="empty"><h3>No jobs yet</h3><p>Accepted quotations turn into jobs and appear here.</p></div>`;

      els('[data-advance]', host).forEach((btn) => {
        btn.onclick = async () => {
          btn.disabled = true;
          try {
            await API.setBookingStatus(btn.dataset.advance, btn.dataset.to);
            toast(`Job marked ${STATUS_LABELS[btn.dataset.to].toLowerCase()}.`, 'ok');
            this.loadJobs();
            this.loadQueue();
          } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
        };
      });
    } catch (e) {
      host.innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  },

  openQuoteModal(requestId) {
    openModal(
      'Send a quotation',
      `
      <div class="field">
        <label for="q-price">Your price in ETB</label>
        <input class="input" id="q-price" type="number" min="1" placeholder="e.g. 1500">
      </div>
      <div class="field">
        <label for="q-days">Estimated days to finish</label>
        <input class="input" id="q-days" type="number" min="1" placeholder="e.g. 1">
      </div>
      <div class="field">
        <label for="q-msg">Message to the seeker</label>
        <textarea class="textarea" id="q-msg" placeholder="What's included, when you can start, anything they should prepare."></textarea>
      </div>
      <div class="notice notice-blue mb-4">
        <span>ⓘ</span>
        <div>How fast you respond is recorded and feeds into your trust score.</div>
      </div>
      <button class="btn btn-primary btn-block" id="q-send">Send quotation</button>`,
      (body) => {
        el('#q-price', body).focus();
        el('#q-send', body).onclick = async (ev) => {
          const price = Number(el('#q-price', body).value);
          if (!price || price <= 0) { toast('Enter a price greater than zero.', 'err'); return; }
          ev.target.disabled = true;
          try {
            await API.sendQuotation({
              requestId,
              price,
              estimatedDays: Number(el('#q-days', body).value) || null,
              message: el('#q-msg', body).value.trim()
            });
            closeModal();
            toast('Quotation sent.', 'ok');
            this.loadQueue();
          } catch (e) { toast(e.message, 'err'); ev.target.disabled = false; }
        };
      }
    );
  },

  openProfileEditor() {
    const p = this.profile;
    if (!p) return;
    const cat = this.categories.find((c) => c.key === p.categoryKey);
    openModal(
      'Edit your profile',
      `
      <div class="field">
        <label for="ep-name">Business name</label>
        <input class="input" id="ep-name" value="${esc(p.businessName)}">
      </div>
      <div class="field">
        <label for="ep-city">City or area</label>
        <input class="input" id="ep-city" value="${esc(p.city)}">
      </div>
      <div class="field">
        <label for="ep-bio">Description</label>
        <textarea class="textarea" id="ep-bio">${esc(p.bio || '')}</textarea>
      </div>
      <div class="field-row">
        <div class="field">
          <label for="ep-avail">Availability</label>
          <select class="select" id="ep-avail">
            <option value="available_now" ${p.availability === 'available_now' ? 'selected' : ''}>Available now</option>
            <option value="by_appointment" ${p.availability === 'by_appointment' ? 'selected' : ''}>By appointment</option>
            <option value="unavailable" ${p.availability === 'unavailable' ? 'selected' : ''}>Not taking work</option>
          </select>
        </div>
        <div class="field">
          <label for="ep-price">Price level</label>
          <select class="select" id="ep-price">
            ${[1, 2, 3, 4, 5]
              .map(
                (i) =>
                  `<option value="${i}" ${p.priceIndex === i ? 'selected' : ''}>${
                    ['Budget', 'Below average', 'Mid-range', 'Above average', 'Premium'][i - 1]
                  }</option>`
              )
              .join('')}
          </select>
        </div>
      </div>
      ${
        cat
          ? `<div class="field">
              <label>Services you offer</label>
              <div class="checkgrid" id="ep-subs">
                ${cat.subcategories
                  .map(
                    (s) => `<label class="checkitem ${p.subcategoryKeys.includes(s.key) ? 'on' : ''}">
                      <input type="checkbox" value="${s.key}" ${p.subcategoryKeys.includes(s.key) ? 'checked' : ''}> ${esc(s.label)}
                    </label>`
                  )
                  .join('')}
              </div>
            </div>`
          : ''
      }
      <div class="field-row">
        <div class="field">
          <label for="ep-lat">Latitude <span class="muted">(for the map)</span></label>
          <input class="input" id="ep-lat" type="number" step="any" value="${p.lat ?? ''}" placeholder="12.603">
        </div>
        <div class="field">
          <label for="ep-lng">Longitude</label>
          <input class="input" id="ep-lng" type="number" step="any" value="${p.lng ?? ''}" placeholder="37.4521">
        </div>
      </div>
      <div class="row gap-2 mb-4">
        <button class="btn btn-ghost btn-sm" id="ep-locate">Use my current location</button>
      </div>
      <button class="btn btn-primary btn-block" id="ep-save">Save changes</button>`,
      (body) => {
        els('.checkitem input', body).forEach((cb) => {
          cb.onchange = () => cb.closest('.checkitem').classList.toggle('on', cb.checked);
        });

        el('#ep-locate', body).onclick = async (ev) => {
          ev.target.textContent = 'Locating…';
          const coords = await Geo.request();
          if (coords) {
            el('#ep-lat', body).value = coords.lat.toFixed(5);
            el('#ep-lng', body).value = coords.lng.toFixed(5);
            ev.target.textContent = 'Location captured';
          } else {
            ev.target.textContent = 'Location unavailable';
          }
        };

        el('#ep-save', body).onclick = async (ev) => {
          ev.target.disabled = true;
          const subs = els('#ep-subs input:checked', body).map((i) => i.value);
          try {
            this.profile = await API.updateProviderProfile({
              businessName: el('#ep-name', body).value.trim(),
              city: el('#ep-city', body).value.trim(),
              bio: el('#ep-bio', body).value.trim(),
              availability: el('#ep-avail', body).value,
              priceIndex: Number(el('#ep-price', body).value),
              ...(subs.length ? { subcategoryKeys: subs } : {}),
              lat: Number(el('#ep-lat', body).value) || null,
              lng: Number(el('#ep-lng', body).value) || null
            });
            Session.provider = this.profile;
            closeModal();
            toast('Profile updated.', 'ok');
            this.home(el('#page'));
          } catch (e) { toast(e.message, 'err'); ev.target.disabled = false; }
        };
      }
    );
  },

  /* ---------------- ABOUT ---------------- */
  about(host) {
    const p = this.profile;
    host.innerHTML = `
      <div class="chart-grid">
        <div class="panel">
          <h2 style="font-size:20px" class="mb-4">How providers get found here</h2>
          <p style="color:var(--ink-soft);max-width:62ch">
            Seekers don't browse a directory. They describe a problem, and OMNI ranks providers against it.
            That means your visibility isn't bought — it's earned from the signals below.
          </p>
          <div class="stack gap-3 mt-6">
            ${[
              ['Trust score', 'The single biggest factor. Built from your ratings, completion rate and response speed.'],
              ['Distance', 'Providers closer to the seeker rank higher, tapering off past about 20 km.'],
              ['Availability', 'Marking yourself available now lifts you on urgent requests.'],
              ['Price level', 'Lower relative pricing gives a small lift on otherwise-equal matches.'],
              ['Review volume', 'A deeper track record adds a modest bonus, capped so newcomers can compete.']
            ]
              .map(
                ([t, d]) => `
              <div class="card" style="padding:14px 16px">
                <div style="font-weight:500;font-size:14.5px">${t}</div>
                <div class="small muted mt-2">${d}</div>
              </div>`
              )
              .join('')}
          </div>
        </div>

        <div class="panel">
          <h2 style="font-size:20px" class="mb-4">Your standing</h2>
          ${
            p
              ? `
            <div class="row gap-4 mb-6">${trustRing(p.trustScore)}</div>
            <div class="stack gap-3">
              <div class="row gap-3" style="justify-content:space-between">
                <span class="small muted">Listing status</span>${statusBadge(p.status)}
              </div>
              <div class="row gap-3" style="justify-content:space-between">
                <span class="small muted">Availability</span>
                <span class="badge ${(AVAILABILITY_LABELS[p.availability] || {}).cls || ''}">${
                  (AVAILABILITY_LABELS[p.availability] || {}).text || p.availability
                }</span>
              </div>
              <div class="row gap-3" style="justify-content:space-between">
                <span class="small muted">Price level</span>${priceDots(p.priceIndex || 3)}
              </div>
              <div class="row gap-3" style="justify-content:space-between">
                <span class="small muted">Services listed</span><span>${p.subcategoryKeys.length}</span>
              </div>
            </div>
            <div class="notice notice-blue mt-6">
              <span>ⓘ</span>
              <div>Every completed job and every new review recalculates your score right away.</div>
            </div>`
              : '<div class="empty"><p>Profile not loaded.</p></div>'
          }
        </div>
      </div>`;
  },

  /* ---------------- SERVICE DEAL ---------------- */
  async deals(host) {
    host.innerHTML = `
      ${this.statusNotice()}
      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>Service deals</h2>
            <p>Set a discounted rate on a service to win more bookings. Deals show on your listing and in match results.</p>
          </div>
          <button class="btn btn-primary btn-sm" id="new-deal">Create a deal</button>
        </div>
        <div id="deal-list"></div>
      </div>`;

    const KEY = 'omni_deals_' + (this.profile ? this.profile.id : 'anon');
    const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } };
    const write = (v) => localStorage.setItem(KEY, JSON.stringify(v));

    const paint = () => {
      const deals = read();
      el('#deal-list').innerHTML = deals.length
        ? `<div class="stack gap-3">${deals
            .map(
              (d, i) => `
          <div class="rq-card">
            <div class="rq-head">
              <div class="grow">
                <div style="font-family:var(--font-head);font-weight:600;font-size:16px">${esc(d.title)}</div>
                <div class="rq-meta">
                  <span>${esc(d.service)}</span>
                  <span>${d.discount}% off</span>
                  <span>Valid until ${esc(d.until || 'no end date')}</span>
                </div>
                ${d.terms ? `<div class="provider-bio">${esc(d.terms)}</div>` : ''}
              </div>
              <span class="badge badge-green">Active</span>
            </div>
            <div class="row gap-2 mt-4">
              <button class="btn btn-quiet btn-sm" data-del="${i}">Remove deal</button>
            </div>
          </div>`
            )
            .join('')}</div>`
        : `<div class="empty">
             <h3>No deals running</h3>
             <p>A short-term discount is the fastest way to build early reviews when your trust score is still forming.</p>
           </div>`;

      els('[data-del]').forEach((btn) => {
        btn.onclick = () => {
          const deals = read();
          deals.splice(Number(btn.dataset.del), 1);
          write(deals);
          paint();
          toast('Deal removed.');
        };
      });
    };

    const services = this.profile
      ? this.profile.subcategoryKeys.map((k) => {
          for (const c of this.categories) {
            const s = c.subcategories.find((x) => x.key === k);
            if (s) return s.label;
          }
          return k;
        })
      : [];

    el('#new-deal').onclick = () => {
      openModal(
        'Create a service deal',
        `
        <div class="field">
          <label for="d-title">Deal name</label>
          <input class="input" id="d-title" placeholder="e.g. First-time customer discount">
        </div>
        <div class="field">
          <label for="d-service">Which service</label>
          <select class="select" id="d-service">
            ${services.map((s) => `<option>${esc(s)}</option>`).join('') || '<option>General service</option>'}
          </select>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="d-discount">Discount %</label>
            <input class="input" id="d-discount" type="number" min="1" max="90" value="15">
          </div>
          <div class="field">
            <label for="d-until">Valid until</label>
            <input class="input" id="d-until" type="date">
          </div>
        </div>
        <div class="field">
          <label for="d-terms">Conditions</label>
          <textarea class="textarea" id="d-terms" placeholder="e.g. Applies to jobs booked within Gondar city, minimum 500 ETB."></textarea>
        </div>
        <button class="btn btn-primary btn-block" id="d-save">Create deal</button>`,
        (body) => {
          el('#d-save', body).onclick = () => {
            const title = el('#d-title', body).value.trim();
            if (!title) { toast('Give the deal a name.', 'err'); return; }
            const deals = read();
            deals.unshift({
              title,
              service: el('#d-service', body).value,
              discount: Number(el('#d-discount', body).value) || 10,
              until: el('#d-until', body).value,
              terms: el('#d-terms', body).value.trim()
            });
            write(deals);
            closeModal();
            paint();
            toast('Deal created.', 'ok');
          };
        }
      );
    };

    paint();
  },

  /* ---------------- ADVERTISEMENT ---------------- */
  ads(host) {
    const KEY = 'omni_ads_' + (this.profile ? this.profile.id : 'anon');
    const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch { return []; } };
    const write = (v) => localStorage.setItem(KEY, JSON.stringify(v));

    host.innerHTML = `
      ${this.statusNotice()}
      <div class="panel">
        <div class="panel-head">
          <div>
            <h2>Advertisements</h2>
            <p>Write the short pitch that appears beside your listing when a seeker is comparing providers.</p>
          </div>
          <button class="btn btn-primary btn-sm" id="new-ad">Write an advert</button>
        </div>
        <div id="ad-list"></div>
      </div>`;

    const paint = () => {
      const ads = read();
      el('#ad-list').innerHTML = ads.length
        ? `<div class="stack gap-3">${ads
            .map(
              (a, i) => `
          <div class="rq-card">
            <div class="rq-head">
              <div class="grow">
                <div style="font-family:var(--font-head);font-weight:600;font-size:16px">${esc(a.headline)}</div>
                <div class="provider-bio">${esc(a.body)}</div>
                <div class="rq-meta"><span>Audience: ${esc(a.audience)}</span></div>
              </div>
              <span class="badge badge-blue">Running</span>
            </div>
            <div class="row gap-2 mt-4">
              <button class="btn btn-quiet btn-sm" data-del-ad="${i}">Remove</button>
            </div>
          </div>`
            )
            .join('')}</div>`
        : `<div class="empty">
             <h3>No adverts yet</h3>
             <p>One clear sentence about what you do better than the next provider is usually enough.</p>
           </div>`;

      els('[data-del-ad]').forEach((btn) => {
        btn.onclick = () => {
          const ads = read();
          ads.splice(Number(btn.dataset.delAd), 1);
          write(ads);
          paint();
          toast('Advert removed.');
        };
      });
    };

    el('#new-ad').onclick = () => {
      openModal(
        'Write an advertisement',
        `
        <div class="field">
          <label for="a-head">Headline</label>
          <input class="input" id="a-head" maxlength="60" placeholder="e.g. Same-day plumbing across Gondar">
          <span class="hint">Keep it under 60 characters so it doesn't get cut off.</span>
        </div>
        <div class="field">
          <label for="a-body">Body</label>
          <textarea class="textarea" id="a-body" maxlength="220" placeholder="What you do, how fast, and what's included."></textarea>
        </div>
        <div class="field">
          <label for="a-aud">Who should see it</label>
          <select class="select" id="a-aud">
            <option>Seekers in my city</option>
            <option>Seekers searching my services</option>
            <option>All seekers on the platform</option>
          </select>
        </div>
        <button class="btn btn-primary btn-block" id="a-save">Publish advert</button>`,
        (body) => {
          el('#a-save', body).onclick = () => {
            const headline = el('#a-head', body).value.trim();
            if (!headline) { toast('Write a headline first.', 'err'); return; }
            const ads = read();
            ads.unshift({
              headline,
              body: el('#a-body', body).value.trim(),
              audience: el('#a-aud', body).value
            });
            write(ads);
            closeModal();
            paint();
            toast('Advert published.', 'ok');
          };
        }
      );
    };

    paint();
  },

  /* ---------------- PROMOTION ---------------- */
  promotion(host) {
    const p = this.profile;
    const tiers = [
      {
        key: 'boosted',
        name: 'Boosted listing',
        price: '450 ETB / month',
        desc: 'Lifts you above equally-ranked providers in match results for your services.',
        points: ['Priority over same-score providers', 'Boosted badge on your listing', 'Cancel any time']
      },
      {
        key: 'featured',
        name: 'Featured provider',
        price: '1,200 ETB / month',
        desc: 'Everything in Boosted, plus placement on the sector page for your main service.',
        points: ['Top slot on your sector page', 'Featured badge in match results', 'Monthly performance summary']
      }
    ];

    host.innerHTML = `
      ${this.statusNotice()}
      <div class="panel mb-6">
        <h2 style="font-size:20px">Promotion</h2>
        <p class="muted mt-2" style="max-width:66ch">
          Promotion changes where you sit among providers who already match a request. It never puts you
          in front of a seeker looking for a service you don't offer, and it doesn't change your trust score.
        </p>
      </div>

      <div class="chart-grid">
        ${tiers
          .map(
            (t) => `
          <div class="panel">
            <div class="row gap-3 mb-4" style="justify-content:space-between;align-items:flex-start">
              <div>
                <h3 style="font-size:18px">${t.name}</h3>
                <div class="small muted mt-2">${t.desc}</div>
              </div>
              <span class="badge badge-violet">${t.price}</span>
            </div>
            <div class="stack gap-2 mb-6">
              ${t.points.map((pt) => `<div class="row gap-2 small"><span style="color:var(--green)">✓</span>${esc(pt)}</div>`).join('')}
            </div>
            <button class="btn btn-ghost btn-block" data-tier="${t.key}"
              ${p && p.status !== 'verified' ? 'disabled' : ''}>
              ${p && p.status !== 'verified' ? 'Verify your business first' : 'Start ' + t.name}
            </button>
          </div>`
          )
          .join('')}
      </div>

      <div class="notice notice-amber mt-6">
        <span>ⓘ</span>
        <div>Payments are not connected in this build. Selecting a tier records the intent only — no charge is made
        and no card details are collected.</div>
      </div>`;

    els('[data-tier]').forEach((btn) => {
      btn.onclick = () => {
        toast('Promotion recorded. Payment is not connected in this build.', 'ok');
        btn.textContent = 'Selected';
        btn.disabled = true;
      };
    });
  },

  /* ---------------- CONTACT ---------------- */
  async contact(host) {
    host.innerHTML = `
      <div class="chart-grid">
        <div class="panel">
          <div class="panel-head">
            <div><h2>Notifications</h2><p>Requests matched to you, quotation outcomes and account updates.</p></div>
            <button class="btn btn-ghost btn-sm" id="read-all">Mark all read</button>
          </div>
          <div class="stack gap-2" id="notif-list"><div class="empty"><span class="spinner"></span></div></div>
        </div>
        <div class="panel">
          <h2 style="font-size:19px" class="mb-4">Provider support</h2>
          <div class="stack gap-4">
            <div><div class="small muted">Verification questions</div><div>verify@omniservice.center</div></div>
            <div><div class="small muted">Payments and payouts</div><div>payouts@omniservice.center</div></div>
            <div><div class="small muted">Report a problem with a job</div><div>disputes@omniservice.center</div></div>
          </div>
          <div class="notice notice-blue mt-6">
            <span>ⓘ</span>
            <div>Contact details above are placeholders for this build, not live support channels.</div>
          </div>
        </div>
      </div>`;

    el('#read-all').onclick = async () => {
      await API.markAllRead().catch(() => {});
      this.contact(host);
    };

    try {
      const notifs = await API.notifications();
      el('#notif-list').innerHTML = notifs.length
        ? notifs
            .slice(0, 25)
            .map(
              (n) => `
          <div class="notif ${n.read ? '' : 'unread'}">
            ${n.read ? '' : '<span class="notif-dot"></span>'}
            <div class="grow">
              <div class="notif-title">${esc(n.title)}</div>
              <div class="notif-body">${esc(n.body)}</div>
              <div class="notif-time">${timeAgo(n.createdAt)}</div>
            </div>
          </div>`
            )
            .join('')
        : '<div class="empty"><h3>Nothing yet</h3><p>Matched requests and account updates will show up here.</p></div>';
    } catch (e) {
      el('#notif-list').innerHTML = `<div class="empty"><p>${esc(e.message)}</p></div>`;
    }
  }
};
