/* ============================================================
   app.js — the shell (sidebar + topbar) and the router.
   ============================================================ */

const Shell = {
  render(root, { role, nav, active, onNav, title }) {
    const user = Session.user || {};
    const roleLabel = { seeker: 'Service Seeker', provider: 'Service Provider', admin: 'Administrator' }[role] || role;

    root.innerHTML = `
      <div class="shell">
        <aside class="sidebar" id="sidebar">
          <div class="sidebar-top">
            <button class="brand" id="shell-brand" style="border:none;background:none;cursor:pointer;padding:0">
              <div class="brand-mark">O</div>
              <div class="brand-text" style="font-size:14.5px">OMNISERVICE <span>CENTER</span></div>
            </button>
          </div>

          <nav class="sidebar-nav">
            <div class="nav-group-label">${esc(roleLabel)}</div>
            ${nav
              .map(
                (n) => `
              <button class="nav-item ${n.key === active ? 'active' : ''}" data-nav="${n.key}">
                <span class="ico">${n.icon}</span>
                <span>${esc(n.label)}</span>
                ${n.count ? `<span class="count">${n.count}</span>` : ''}
              </button>`
              )
              .join('')}
          </nav>

          <div class="sidebar-foot">
            <div class="user-chip">
              <div class="avatar">${esc(initials(user.fullName))}</div>
              <div class="grow" style="min-width:0">
                <div class="user-chip-name">${esc(user.fullName || 'Guest')}</div>
                <div class="user-chip-role">${esc(roleLabel)}</div>
              </div>
            </div>
            <button class="nav-item mt-2" id="sign-out">
              <span class="ico">↩</span><span>Sign out</span>
            </button>
          </div>
        </aside>

        <div class="main">
          <header class="topbar">
            <button class="mobile-toggle" id="menu-toggle" aria-label="Open menu">☰</button>
            <h1 class="grow">${esc(title)}</h1>
            <span class="badge badge-blue">${esc(roleLabel)}</span>
          </header>
          <div class="content" id="page"></div>
        </div>
      </div>`;

    els('[data-nav]', root).forEach((btn) => {
      btn.onclick = () => {
        el('#sidebar').classList.remove('open');
        const scrim = el('.sidebar-scrim');
        if (scrim) scrim.remove();
        onNav(btn.dataset.nav);
      };
    });

    el('#sign-out').onclick = () => Auth.signOut();
    el('#shell-brand').onclick = () => router.go('/');

    el('#menu-toggle').onclick = () => {
      const sidebar = el('#sidebar');
      sidebar.classList.add('open');
      const scrim = document.createElement('div');
      scrim.className = 'sidebar-scrim';
      scrim.onclick = () => { sidebar.classList.remove('open'); scrim.remove(); };
      document.body.appendChild(scrim);
    };
  }
};

/* ============================================================
   Router — hash-free, history-based, with role guards.
   ============================================================ */

const router = {
  root: null,

  init() {
    this.root = el('#app');
    window.addEventListener('popstate', () => this.resolve());
    window.addEventListener('omni:signed-out', () => {
      toast('Your session expired. Please sign in again.', 'err');
      this.go('/');
    });
    this.resolve();
  },

  go(path) {
    if (location.pathname !== path) history.pushState({}, '', path);
    this.resolve();
  },

  async resolve() {
    const path = location.pathname.replace(/\/+$/, '') || '/';
    const [, section, page] = path.split('/');
    const user = Session.user;

    closeModal();
    window.scrollTo(0, 0);

    // Public routes
    if (!section) {
      if (user) return this.go(this.homeFor(user.role));
      return Landing.render(this.root);
    }
    if (section === 'onboarding') {
      if (user) return this.go(this.homeFor(user.role));
      return Onboarding.render(this.root);
    }

    // Everything below needs a session
    if (!user) {
      this.root.innerHTML = `
        <div class="onboard"><div class="onboard-inner center" style="padding-top:80px">
          <h1 style="font-size:26px">Sign in to continue</h1>
          <p class="muted mt-2">This area needs an account.</p>
          <div class="row gap-3 mt-6" style="justify-content:center">
            <button class="btn btn-primary" id="gate-signin">Sign in</button>
            <button class="btn btn-ghost" id="gate-home">Back to home</button>
          </div>
        </div></div>`;
      el('#gate-signin').onclick = () => Auth.openLogin();
      el('#gate-home').onclick = () => this.go('/');
      return;
    }

    // Role guard — a signed-in user can only enter their own stream
    if (section !== user.role) return this.go(this.homeFor(user.role));

    if (section === 'seeker') return Seeker.mount(this.root, page || 'home');
    if (section === 'provider') return Provider.mount(this.root, page || 'home');
    if (section === 'admin') return Admin.mount(this.root, page || 'overview');

    return this.go(this.homeFor(user.role));
  },

  homeFor(role) {
    return role === 'admin' ? '/admin' : role === 'provider' ? '/provider' : '/seeker';
  }
};

/* ============================================================
   Boot
   ============================================================ */

window.addEventListener('DOMContentLoaded', async () => {
  // If a token is stored, confirm it's still valid before trusting it.
  if (Session.token) {
    try {
      const me = await API.me();
      Session.user = me.user;
      Session.provider = me.provider || null;
    } catch {
      Session.clear();
    }
  }

  router.init();

  // Ask for location quietly in the background — it improves distance ranking
  // but nothing depends on it.
  Geo.request();

  // If the seeker arrived at the AI agent from the home search box, run it.
  const pending = sessionStorage.getItem('omni_pending_q');
  if (pending && location.pathname.includes('/omni')) {
    sessionStorage.removeItem('omni_pending_q');
    setTimeout(() => {
      const input = el('#omni-input');
      if (input) { input.value = pending; el('#omni-send').click(); }
    }, 320);
  }
});
