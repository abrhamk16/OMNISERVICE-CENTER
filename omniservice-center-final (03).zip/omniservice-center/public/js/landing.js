/* ============================================================
   landing.js — the compact landing page and the onboarding flow.
   Per spec: one screen, no long scroll, no dropdown menus.
   The hero runs the real OMNI engine, not a scripted animation.
   ============================================================ */

const Landing = {
  async render(root) {
    const stats = await API.mapFeed().catch(() => []);
    const categories = await API.categories().catch(() => []);
    const verified = stats.length;
    const sectors = categories.length;

    root.innerHTML = `
      <div class="landing">
        <div class="wrap">
          <nav class="landing-nav">
            <div class="brand">
              <div class="brand-mark">O</div>
              <div class="brand-text">OMNISERVICE <span>CENTER</span></div>
            </div>
            <div class="row gap-2">
              <button class="btn btn-quiet" id="nav-lang">${I18N.lang === 'am' ? 'English' : 'አማርኛ'}</button>
              <button class="btn btn-quiet" id="nav-signin">${tr('Sign in')}</button>
              <button class="btn btn-primary" id="nav-start">${tr('Get started')}</button>
            </div>
          </nav>
        </div>

        <div class="wrap landing-main">
          <div class="hero">
            <div class="hero-eyebrow">
              <span class="hero-dot"></span>
              <span><b>OMNI</b> is live — try it below</span>
            </div>
            <h1>${tr('Every service.')}<br>${tr('One smart center.')}</h1>
            <p class="hero-lede">
              Describe what you need in your own words. OMNI reads the request,
              works out which service it is, where you are and how soon you need it,
              then ranks verified providers by trust score, distance and availability.
            </p>

            <div class="hero-cta">
              <button class="btn btn-primary btn-lg btn-hero" id="hero-start">${tr('Get started')}</button>
              <button class="btn btn-ghost btn-lg" id="hero-signin">${tr('I already have an account')}</button>
            </div>

            <div class="hero-facts">
              <div>
                <div class="fact-n">${verified}</div>
                <div class="fact-l">Verified providers listed</div>
              </div>
              <div>
                <div class="fact-n">${sectors}</div>
                <div class="fact-l">Service sectors covered</div>
              </div>
              <div>
                <div class="fact-n">Gondar</div>
                <div class="fact-l">Launch city, built to expand</div>
              </div>
            </div>
          </div>

          <div class="flow-strip">
            <div class="flow-step"><span class="flow-icon">🔎</span><span class="flow-label">Discover</span></div>
            <span class="flow-arrow">→</span>
            <div class="flow-step"><span class="flow-icon">🎯</span><span class="flow-label">Find</span></div>
            <span class="flow-arrow">→</span>
            <div class="flow-step"><span class="flow-icon">🤝</span><span class="flow-label">Connect</span></div>
            <span class="flow-arrow">→</span>
            <div class="flow-step"><span class="flow-icon">✅</span><span class="flow-label">Get Service</span></div>
          </div>

          <div class="hero-demo hero-demo-wide">
            <div class="hero-demo-top">
              <div class="omni-avatar">AI</div>
              <div>
                <strong>Ask OMNI</strong>
                <div class="small muted">Live matching — type anything</div>
              </div>
            </div>
            <div class="hero-demo-body">
              <div class="demo-chips" id="demo-chips">
                ${[
                  'My kitchen pipe is leaking in Gondar, I need help today',
                  'I need a maths tutor before my exams',
                  'Looking for a photographer for a wedding',
                  'My laptop screen stopped working'
                ]
                  .map((q) => `<button class="demo-chip" data-q="${esc(q)}">${esc(q.length > 38 ? q.slice(0, 36) + '…' : q)}</button>`)
                  .join('')}
              </div>
              <div class="demo-input-row">
                <input class="input" id="demo-input" placeholder="Describe what you need…"
                       aria-label="Describe what you need">
                <button class="btn btn-solid" id="demo-go">Ask</button>
              </div>
              <div class="demo-out" id="demo-out"></div>
            </div>
          </div>
        </div>

        <div class="wrap">
          <div class="landing-foot">
            <div>Built for Ethiopia — English and Amharic, designed to expand across regions.</div>
            <div class="landing-credit">Built by <b>Abrham</b> &amp; <b>Solomon</b></div>
          </div>
        </div>
      </div>`;

    el('#nav-start').onclick = () => router.go('/onboarding');
    el('#hero-start').onclick = () => router.go('/onboarding');
    el('#nav-signin').onclick = () => Auth.openLogin();
    el('#nav-lang').onclick = () => I18N.toggle();
    el('#hero-signin').onclick = () => Auth.openLogin();

    const input = el('#demo-input');
    const out = el('#demo-out');

    els('#demo-chips .demo-chip').forEach((chip) => {
      chip.onclick = () => {
        input.value = chip.dataset.q;
        runDemo();
      };
    });
    el('#demo-go').onclick = runDemo;
    input.onkeydown = (e) => { if (e.key === 'Enter') runDemo(); };

    async function runDemo() {
      const q = input.value.trim();
      if (!q) { input.focus(); return; }
      out.innerHTML = `<div class="demo-reply row gap-2"><span class="spinner"></span> OMNI is reading your request…</div>`;
      try {
        const origin = Geo.coords || DEFAULT_ORIGIN;
        const r = await API.ask(q, origin);
        out.innerHTML = `
          <div class="demo-reply">${esc(r.reply)}</div>
          ${
            r.matches && r.matches.length
              ? r.matches
                  .slice(0, 3)
                  .map(
                    (m, i) => `
              <div class="demo-match">
                <span class="rank-pill ${i === 0 ? 'top' : ''}">${i + 1}</span>
                <div class="grow">
                  <div class="demo-match-name">${esc(m.businessName)}</div>
                  <div class="demo-match-meta">${esc(m.city)}${
                      m.distanceKm !== null ? ` · ${m.distanceKm} km` : ''
                    } · trust ${m.trustScore}</div>
                </div>
              </div>`
                  )
                  .join('')
              : ''
          }
          <div class="demo-reasoning">
            <b>How OMNI got there</b>
            <ul>${r.reasoning.map((line) => `<li>${esc(line)}</li>`).join('')}</ul>
          </div>`;
      } catch (e) {
        out.innerHTML = `<div class="demo-reply">${esc(e.message)}</div>`;
      }
    }
  }
};

/* ============================================================
   Onboarding — role choice, then the role's own detail form.
   ============================================================ */

const Onboarding = {
  state: { role: null, categories: [] },

  async render(root) {
    this.state.categories = await API.categories().catch(() => []);
    this.state.role = null;
    this.renderRoleStep(root);
  },

  shell(inner) {
    return `
      <div class="onboard">
        <div class="onboard-inner">
          <div class="row gap-3 mb-6" style="justify-content:space-between">
            <button class="brand" id="ob-home" style="border:none;background:none;cursor:pointer">
              <div class="brand-mark">O</div>
              <div class="brand-text">OMNISERVICE <span>CENTER</span></div>
            </button>
            <button class="btn btn-quiet" id="ob-signin">Sign in instead</button>
          </div>
          ${inner}
        </div>
      </div>`;
  },

  bindShell() {
    el('#ob-home').onclick = () => router.go('/');
    el('#ob-signin').onclick = () => Auth.openLogin();
  },

  renderRoleStep(root) {
    root.innerHTML = this.shell(`
      <div class="steps">
        <div class="step-dot done">1</div><div class="step-line"></div>
        <div class="step-dot">2</div>
        <span class="small muted" style="margin-left:8px">Choose how you'll use OMNISERVICE</span>
      </div>
      <h1 style="font-size:30px">How will you use the platform?</h1>
      <p class="muted mt-2">You can create a second account later if you need both.</p>
      <div class="role-pick">
        <button class="role-card" data-role="seeker">
          <div class="role-icon">🔎</div>
          <h3>I need a service</h3>
          <p>Post what you need, let OMNI find and rank verified providers, compare quotations and book.</p>
          <ul>
            <li>Describe the job in plain language</li>
            <li>Compare providers by trust score</li>
            <li>Track the job to completion</li>
          </ul>
        </button>
        <button class="role-card" data-role="provider">
          <div class="role-icon">🛠️</div>
          <h3>I provide a service</h3>
          <p>List your business, get matched to nearby requests, send quotations and build a trust score.</p>
          <ul>
            <li>Receive requests that fit your skills</li>
            <li>Quote directly, no middleman calls</li>
            <li>Grow visibility as your score rises</li>
          </ul>
        </button>
      </div>`);
    this.bindShell();
    els('.role-card').forEach((card) => {
      card.onclick = () => {
        this.state.role = card.dataset.role;
        this.state.role === 'seeker' ? this.renderSeekerForm(root) : this.renderProviderForm(root);
      };
    });
  },

  renderSeekerForm(root) {
    root.innerHTML = this.shell(`
      <div class="steps">
        <div class="step-dot done">1</div><div class="step-line"></div>
        <div class="step-dot done">2</div>
        <span class="small muted" style="margin-left:8px">Service Seeker details</span>
      </div>
      <h1 style="font-size:28px">Tell us about you</h1>
      <p class="muted mt-2">This is what providers see when they respond to your requests.</p>
      <div class="panel mt-6">
        <div class="field-row">
          <div class="field">
            <label for="s-name">Full name</label>
            <input class="input" id="s-name" autocomplete="name" placeholder="e.g. Abrham Kefyalew">
          </div>
          <div class="field">
            <label for="s-phone">Phone number</label>
            <input class="input" id="s-phone" autocomplete="tel" placeholder="+251 9…">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="s-email">Email</label>
            <input class="input" id="s-email" type="email" autocomplete="email" placeholder="you@example.com">
          </div>
          <div class="field">
            <label for="s-city">City or area</label>
            <input class="input" id="s-city" placeholder="e.g. Piassa, Gondar">
          </div>
        </div>
        <div class="field">
          <label for="s-pass">Password</label>
          <input class="input" id="s-pass" type="password" autocomplete="new-password" placeholder="At least 6 characters">
          <span class="hint">Used to sign in and to keep your request history.</span>
        </div>
        <div class="row gap-3 mt-4">
          <button class="btn btn-primary" id="s-submit">Create account</button>
          <button class="btn btn-quiet" id="s-back">Back</button>
        </div>
      </div>`);
    this.bindShell();
    el('#s-back').onclick = () => this.renderRoleStep(root);
    el('#s-submit').onclick = async (ev) => {
      const payload = {
        fullName: el('#s-name').value.trim(),
        email: el('#s-email').value.trim(),
        phone: el('#s-phone').value.trim(),
        city: el('#s-city').value.trim(),
        password: el('#s-pass').value
      };
      if (!payload.fullName || !payload.email || !payload.password) {
        toast('Fill in your name, email and password to continue.', 'err');
        return;
      }
      if (payload.password.length < 6) {
        toast('Use a password of at least 6 characters.', 'err');
        return;
      }
      ev.target.disabled = true;
      try {
        const res = await API.registerSeeker(payload);
        Session.token = res.token;
        Session.user = res.user;
        toast(`Welcome, ${res.user.fullName.split(' ')[0]}.`, 'ok');
        router.go('/seeker');
      } catch (e) {
        toast(e.message, 'err');
        ev.target.disabled = false;
      }
    };
  },

  renderProviderForm(root) {
    const cats = this.state.categories;
    root.innerHTML = this.shell(`
      <div class="steps">
        <div class="step-dot done">1</div><div class="step-line"></div>
        <div class="step-dot done">2</div>
        <span class="small muted" style="margin-left:8px">Service Provider details</span>
      </div>
      <h1 style="font-size:28px">Tell us about your business</h1>
      <p class="muted mt-2">An admin reviews every application before you appear in search results.</p>

      <div class="panel mt-6">
        <div class="field-row">
          <div class="field">
            <label for="p-name">Your full name</label>
            <input class="input" id="p-name" autocomplete="name" placeholder="e.g. Tigist Alemu">
          </div>
          <div class="field">
            <label for="p-business">Business name</label>
            <input class="input" id="p-business" placeholder="e.g. Tigist Plumbing Works">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="p-email">Email</label>
            <input class="input" id="p-email" type="email" autocomplete="email" placeholder="you@example.com">
          </div>
          <div class="field">
            <label for="p-phone">Phone number</label>
            <input class="input" id="p-phone" autocomplete="tel" placeholder="+251 9…">
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="p-city">City or area you serve</label>
            <input class="input" id="p-city" placeholder="e.g. Azezo, Gondar">
          </div>
          <div class="field">
            <label for="p-years">Years in operation</label>
            <input class="input" id="p-years" type="number" min="0" max="60" placeholder="e.g. 4">
          </div>
        </div>

        <div class="field">
          <label for="p-sector">Main sector</label>
          <select class="select" id="p-sector">
            <option value="">Choose a sector…</option>
            ${cats.map((c) => `<option value="${c.key}">${c.icon} ${esc(c.label)}</option>`).join('')}
          </select>
        </div>

        <div class="field">
          <label>Services you offer</label>
          <div class="checkgrid" id="p-subs">
            <span class="small muted">Choose a sector first.</span>
          </div>
          <span class="hint">Pick everything you actually do — this is what OMNI matches requests against.</span>
        </div>

        <div class="field">
          <label for="p-price">Your price level</label>
          <select class="select" id="p-price">
            <option value="1">Budget</option>
            <option value="2">Below average</option>
            <option value="3" selected>Mid-range</option>
            <option value="4">Above average</option>
            <option value="5">Premium</option>
          </select>
        </div>

        <div class="field">
          <label for="p-bio">Short description</label>
          <textarea class="textarea" id="p-bio" placeholder="What you do, the areas you cover, and anything that sets your work apart."></textarea>
        </div>

        <div class="field">
          <label for="p-pass">Password</label>
          <input class="input" id="p-pass" type="password" autocomplete="new-password" placeholder="At least 6 characters">
        </div>

        <div class="notice notice-amber mb-4">
          <span>ⓘ</span>
          <div>Your listing stays hidden from seekers until an admin verifies it. You'll get a notification either way.</div>
        </div>

        <div class="row gap-3">
          <button class="btn btn-primary" id="p-submit">Submit application</button>
          <button class="btn btn-quiet" id="p-back">Back</button>
        </div>
      </div>`);

    this.bindShell();
    el('#p-back').onclick = () => this.renderRoleStep(root);

    el('#p-sector').onchange = (e) => {
      const cat = cats.find((c) => c.key === e.target.value);
      const host = el('#p-subs');
      if (!cat) { host.innerHTML = '<span class="small muted">Choose a sector first.</span>'; return; }
      host.innerHTML = cat.subcategories
        .map(
          (s) => `
        <label class="checkitem">
          <input type="checkbox" value="${s.key}"> ${esc(s.label)}
        </label>`
        )
        .join('');
      els('.checkitem input', host).forEach((cb) => {
        cb.onchange = () => cb.closest('.checkitem').classList.toggle('on', cb.checked);
      });
    };

    el('#p-submit').onclick = async (ev) => {
      const subcategoryKeys = els('#p-subs input:checked').map((i) => i.value);
      const payload = {
        fullName: el('#p-name').value.trim(),
        businessName: el('#p-business').value.trim(),
        email: el('#p-email').value.trim(),
        phone: el('#p-phone').value.trim(),
        city: el('#p-city').value.trim(),
        yearsActive: Number(el('#p-years').value) || 0,
        categoryKey: el('#p-sector').value,
        subcategoryKeys,
        priceIndex: Number(el('#p-price').value),
        bio: el('#p-bio').value.trim(),
        password: el('#p-pass').value
      };
      if (!payload.fullName || !payload.email || !payload.password || !payload.businessName) {
        toast('Name, business name, email and password are required.', 'err');
        return;
      }
      if (!subcategoryKeys.length) {
        toast('Choose at least one service you offer.', 'err');
        return;
      }
      if (payload.password.length < 6) {
        toast('Use a password of at least 6 characters.', 'err');
        return;
      }
      ev.target.disabled = true;
      try {
        const res = await API.registerProvider(payload);
        Session.token = res.token;
        Session.user = res.user;
        Session.provider = res.provider;
        toast('Application submitted — an admin will review it.', 'ok');
        router.go('/provider');
      } catch (e) {
        toast(e.message, 'err');
        ev.target.disabled = false;
      }
    };
  }
};

/* ============================================================
   Sign-in modal
   ============================================================ */

const Auth = {
  openLogin() {
    openModal(
      'Sign in',
      `
      <div class="field">
        <label for="li-email">Email</label>
        <input class="input" id="li-email" type="email" autocomplete="email" placeholder="you@example.com">
      </div>
      <div class="field">
        <label for="li-pass">Password</label>
        <input class="input" id="li-pass" type="password" autocomplete="current-password">
      </div>
      <button class="btn btn-primary btn-block" id="li-go">Sign in</button>

      <div class="row gap-2 mt-4" style="justify-content:center">
        <span class="small muted">New to OMNISERVICE CENTER?</span>
        <button class="btn btn-quiet btn-sm" id="li-start" style="padding:0 4px">Get started</button>
      </div>`,
      (body) => {
        const emailInput = el('#li-email', body);
        const passInput = el('#li-pass', body);
        emailInput.focus();

        el('#li-start', body).onclick = () => {
          closeModal();
          router.go('/onboarding');
        };

        el('#li-go', body).onclick = submit;
        [emailInput, passInput].forEach((i) => {
          i.onkeydown = (e) => { if (e.key === 'Enter') submit(); };
        });

        async function submit() {
          const email = emailInput.value.trim();
          const password = passInput.value;
          if (!email || !password) { toast('Enter your email and password.', 'err'); return; }
          const btn = el('#li-go', body);
          btn.disabled = true;
          btn.textContent = 'Signing in…';
          try {
            const res = await API.login(email, password);
            Session.token = res.token;
            Session.user = res.user;
            Session.provider = res.provider || null;
            closeModal();
            toast(`Signed in as ${res.user.fullName}.`, 'ok');
            router.go(
              res.user.role === 'admin' ? '/admin' : res.user.role === 'provider' ? '/provider' : '/seeker'
            );
          } catch (e) {
            toast(e.message, 'err');
            btn.disabled = false;
            btn.textContent = 'Sign in';
          }
        }
      }
    );
  },

  signOut() {
    Session.clear();
    toast('Signed out.');
    router.go('/');
  }
};
