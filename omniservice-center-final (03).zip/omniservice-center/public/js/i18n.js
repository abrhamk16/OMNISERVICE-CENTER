/* i18n.js — English / አማርኛ for navigation, roles and the landing hero.
   Anything not in the dictionary falls back to English. */
const I18N = {
  lang: (() => { try { return localStorage.getItem('omni_lang') || 'en'; } catch { return 'en'; } })(),
  am: {
    'Home': 'መነሻ', 'About': 'ስለ እኛ', 'Services': 'አገልግሎቶች', 'Map': 'ካርታ', 'AI Agent': 'AI ረዳት',
    'Contact': 'አግኙን', 'Service Deal': 'የአገልግሎት ቅናሽ', 'Advertisement': 'ማስታወቂያ', 'Promotion': 'ማስተዋወቂያ',
    'Overview': 'አጠቃላይ እይታ', 'Verification': 'ማረጋገጫ', 'Providers': 'አገልግሎት ሰጪዎች', 'Users': 'ተጠቃሚዎች',
    'Requests': 'ጥያቄዎች', 'Reports': 'ሪፖርቶች', 'Start Apps': 'መተግበሪያዎችን አስጀምር',
    'Service Seeker': 'አገልግሎት ፈላጊ', 'Service Provider': 'አገልግሎት ሰጪ', 'Administrator': 'አስተዳዳሪ',
    'Sign in': 'ግባ', 'Sign out': 'ውጣ', 'Get started': 'ጀምር', 'I already have an account': 'አካውንት አለኝ',
    'Every service.': 'ሁሉም አገልግሎት።', 'One smart center.': 'በአንድ ብልህ ማዕከል።'
  },
  t(s) { return this.lang === 'am' && this.am[s] ? this.am[s] : s; },
  toggle() {
    this.lang = this.lang === 'am' ? 'en' : 'am';
    try { localStorage.setItem('omni_lang', this.lang); } catch {}
    document.documentElement.lang = this.lang;
    router.resolve();
  }
};
const tr = (s) => I18N.t(s);
document.documentElement.lang = I18N.lang;
