/* ============================================================
   payment.js — shared "pay now" modal. Used by the seeker stream
   (paying for a booking) and the provider stream (buying
   promotion). One method picker, one initiate/confirm flow, one
   receipt view — every payment on the platform looks the same.
   ============================================================ */

const Payment = {
  _cache: null,
  async _methods() {
    if (!this._cache) this._cache = await API.paymentMethods();
    return this._cache;
  },

  // opts: { purpose: 'booking'|'promotion', bookingId, tier, amount, purposeLabel, onSuccess }
  async open(opts) {
    let data;
    try {
      data = await this._methods();
    } catch (e) {
      return toast('Could not load payment methods — try again in a moment.', 'err');
    }
    const { methods } = data;
    let selected = null;

    const back = openModal('Complete payment', '<div class="center" style="padding:30px"><span class="spinner"></span></div>');
    const body = el('.modal-body', back);

    const renderPicker = () => {
      body.innerHTML = `
        <div class="notice notice-blue mb-4">
          <span>🧪</span>
          <div><b>Sandbox mode.</b> This walks through a real payment flow but never moves real money — no card, wallet or bank account is actually charged.</div>
        </div>
        <div class="row gap-3 mb-4" style="justify-content:space-between;align-items:baseline">
          <div class="muted small">${esc(opts.purposeLabel || 'You are paying')}</div>
          <div style="font-family:var(--font-head);font-size:22px;font-weight:600">${money(opts.amount)}</div>
        </div>
        <div class="pm-groups"></div>
        <div id="pm-fields"></div>
      `;
      const groupsHost = el('.pm-groups', body);
      [
        ['ethiopian', 'Ethiopian payment methods'],
        ['global', 'International']
      ].forEach(([group, heading]) => {
        const inGroup = methods.filter((m) => m.group === group);
        if (!inGroup.length) return;
        groupsHost.insertAdjacentHTML(
          'beforeend',
          `<div class="pm-group-label">${heading}</div>
           <div class="pm-grid">
             ${inGroup
               .map(
                 (m) => `
               <button type="button" class="pm-card" data-method="${m.key}">
                 <span class="pm-icon">${m.icon}</span>
                 <span class="pm-name">${esc(m.label)}</span>
                 <span class="pm-blurb">${esc(m.blurb)}</span>
               </button>`
               )
               .join('')}
           </div>`
        );
      });
      els('.pm-card', groupsHost).forEach((btn) => {
        btn.addEventListener('click', () => {
          els('.pm-card', groupsHost).forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
          selected = methods.find((m) => m.key === btn.dataset.method);
          renderFields();
        });
      });
    };

    const fieldHTML = (f) => {
      if (f.type === 'select') {
        const options = selected.banks || [];
        return `<div class="field"><label>${esc(f.label)}</label>
          <select class="select" data-field="${f.name}">
            <option value="">Choose your bank</option>
            ${options.map((o) => `<option value="${esc(o)}">${esc(o)}</option>`).join('')}
          </select></div>`;
      }
      return `<div class="field"><label>${esc(f.label)}</label>
        <input class="input" data-field="${f.name}" type="${f.type}" placeholder="${esc(f.placeholder || '')}"
          ${f.maxlength ? `maxlength="${f.maxlength}"` : ''}></div>`;
    };

    const renderFields = () => {
      const host = el('#pm-fields', body);
      const fxNote =
        selected.group === 'global'
          ? `<div class="small muted mb-4">Charged in your card or account's currency at your bank's exchange rate — the amount above is what you're paying for.</div>`
          : '';
      host.innerHTML = `
        <div class="mt-4">
          ${fxNote}
          ${selected.fields.map(fieldHTML).join('')}
          <button class="btn btn-primary btn-block" id="pm-pay-btn">Pay ${money(opts.amount)}</button>
        </div>`;
      el('#pm-pay-btn', host).addEventListener('click', submit);
    };

    const submit = async () => {
      const details = {};
      let missing = false;
      els('[data-field]', body).forEach((input) => {
        details[input.dataset.field] = input.value.trim();
        if (!input.value.trim()) missing = true;
      });
      if (missing) return toast('Fill in every field to continue.', 'err');

      const btn = el('#pm-pay-btn', body);
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Processing...';
      try {
        const payment = await API.initiatePayment({
          purpose: opts.purpose,
          bookingId: opts.bookingId,
          tier: opts.tier,
          method: selected.key,
          details
        });
        renderProcessing(payment);
        await new Promise((r) => setTimeout(r, 1100));
        const confirmed = await API.confirmPayment(payment.id);
        renderReceipt(confirmed);
      } catch (e) {
        toast(e.message, 'err');
        btn.disabled = false;
        btn.innerHTML = `Pay ${money(opts.amount)}`;
      }
    };

    const renderProcessing = (payment) => {
      body.innerHTML = `
        <div class="center" style="padding:34px 10px">
          <span class="spinner" style="width:30px;height:30px;border-width:3px"></span>
          <div style="font-weight:500;margin-top:16px">${esc(payment.instructions)}</div>
          <div class="small muted mt-2">Reference ${esc(payment.reference)}</div>
        </div>`;
    };

    const renderReceipt = (payment) => {
      const ok = payment.status === 'succeeded';
      body.innerHTML = `
        <div class="center" style="padding:4px 0 18px">
          <div style="font-size:38px">${ok ? '✅' : '⚠️'}</div>
          <h3 style="margin-top:10px">${ok ? 'Payment successful' : 'Payment failed'}</h3>
          <div class="muted small mt-2">${
            ok ? 'A receipt has been saved to your payment history.' : 'Nothing was charged — you can try again.'
          }</div>
        </div>
        <div class="receipt">
          <div class="receipt-row"><span>Reference</span><b>${esc(payment.reference)}</b></div>
          <div class="receipt-row"><span>For</span><b>${esc(payment.purposeLabel || '')}</b></div>
          <div class="receipt-row"><span>Method</span><b>${esc(payment.methodLabel)}${payment.methodDetail ? ' &middot; ' + esc(payment.methodDetail) : ''}</b></div>
          <div class="receipt-row"><span>Amount</span><b>${money(payment.amount)}</b></div>
          <div class="receipt-row"><span>Date</span><b>${new Date(payment.confirmedAt || payment.createdAt).toLocaleString()}</b></div>
          <div class="receipt-row"><span>Status</span>${statusBadge(payment.status)}</div>
        </div>
        <div class="row gap-3 mt-4">
          <button class="btn btn-ghost grow" id="pm-print">Print receipt</button>
          <button class="btn btn-primary grow" id="pm-done">Done</button>
        </div>`;
      el('#pm-print', body).addEventListener('click', () => window.print());
      el('#pm-done', body).addEventListener('click', () => {
        closeModal();
        if (ok && opts.onSuccess) opts.onSuccess(payment);
      });
    };

    renderPicker();
  },

  // Shows a read-only receipt for an already-completed payment (e.g. from
  // booking/payment history) — no method picker, just the paid record.
  showReceipt(payment) {
    const back = openModal('Receipt', '');
    const body = el('.modal-body', back);
    const ok = payment.status === 'succeeded';
    body.innerHTML = `
      <div class="center" style="padding:4px 0 18px">
        <div style="font-size:38px">${ok ? '✅' : '⚠️'}</div>
        <h3 style="margin-top:10px">${ok ? 'Payment successful' : esc(payment.status)}</h3>
      </div>
      <div class="receipt">
        <div class="receipt-row"><span>Reference</span><b>${esc(payment.reference)}</b></div>
        <div class="receipt-row"><span>For</span><b>${esc(payment.purposeLabel || '')}</b></div>
        <div class="receipt-row"><span>Method</span><b>${esc(payment.methodLabel)}${payment.methodDetail ? ' &middot; ' + esc(payment.methodDetail) : ''}</b></div>
        <div class="receipt-row"><span>Amount</span><b>${money(payment.amount)}</b></div>
        <div class="receipt-row"><span>Date</span><b>${new Date(payment.confirmedAt || payment.createdAt).toLocaleString()}</b></div>
        <div class="receipt-row"><span>Status</span>${statusBadge(payment.status)}</div>
      </div>
      <button class="btn btn-ghost btn-block mt-4" id="pm-print2">Print receipt</button>`;
    el('#pm-print2', body).addEventListener('click', () => window.print());
  }
};
