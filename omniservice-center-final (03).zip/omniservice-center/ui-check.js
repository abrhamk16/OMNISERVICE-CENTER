// ui-check.js — drives the real UI in a headless browser and screenshots it.
const puppeteer = require('puppeteer');
const fs = require('fs');

const OUT = '/tmp/shots';
fs.mkdirSync(OUT, { recursive: true });

(async () => {
  const browser = await puppeteer.launch({
    // Only needed if Puppeteer can't find its own Chromium. Set CHROME_PATH
    // to your Chrome/Chromium binary if the launch fails.
    ...(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {}),
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
    defaultViewport: { width: 1440, height: 940 }
  });
  const page = await browser.newPage();

  const errors = [];
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));

  const shot = async (name) => {
    await new Promise((r) => setTimeout(r, 700));
    await page.screenshot({ path: `${OUT}/${name}.png` });
    console.log(`  shot: ${name}`);
  };

  // --- landing ---
  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle0' });
  await page.waitForSelector('.hero h1');
  await shot('01-landing');

  // run the live OMNI demo in the hero
  await page.click('#demo-chips .demo-chip');
  await page.waitForSelector('.demo-match', { timeout: 8000 });
  await shot('02-landing-omni');

  // --- onboarding ---
  await page.click('#hero-start');
  await page.waitForSelector('.role-pick');
  await shot('03-onboarding-role');

  await page.click('[data-role="provider"]');
  await page.waitForSelector('#p-business');
  await shot('04-onboarding-provider');

  // --- sign in as seeker ---
  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle0' });
  await page.click('#nav-signin');
  await page.waitForSelector('#li-email');
  await page.type('#li-email', 'seeker1@omniservice.center');
  await page.type('#li-pass', 'demo1234');
  await page.click('#li-go');
  await page.waitForSelector('.sidebar', { timeout: 8000 });
  await page.waitForSelector('#request-list .rq-card, #request-list .empty', { timeout: 8000 });
  await shot('05-seeker-home');

  // seeker: AI agent
  await page.click('[data-nav="omni"]');
  await page.waitForSelector('#omni-input');
  await page.type('#omni-input', 'my pipe is leaking in Gondar and I need someone today');
  await page.click('#omni-send');
  await page.waitForSelector('.omni-analysis', { timeout: 10000 });
  await shot('06-seeker-omni');

  // seeker: services
  await page.click('[data-nav="services"]');
  await page.waitForSelector('.sector-card');
  await shot('07-seeker-services');

  await page.click('.sector-card');
  await page.waitForSelector('.provider-card', { timeout: 8000 });
  await shot('08-seeker-sector-detail');

  // seeker: map
  await page.click('[data-nav="map"]');
  await page.waitForSelector('#map .leaflet-tile, .map-result', { timeout: 12000 });
  await new Promise((r) => setTimeout(r, 2200));
  await shot('09-seeker-map');

  // seeker: about
  await page.click('[data-nav="about"]');
  await page.waitForSelector('.lifecycle');
  await shot('10-seeker-about');

  // --- provider stream ---
  await page.click('#sign-out');
  await page.waitForSelector('.hero h1', { timeout: 8000 });
  await page.click('#nav-signin');
  await page.waitForSelector('#li-email');
  await page.type('#li-email', 'provider1@omniservice.center');
  await page.type('#li-pass', 'demo1234');
  await page.click('#li-go');
  await page.waitForSelector('#queue', { timeout: 8000 });
  await new Promise((r) => setTimeout(r, 900));
  await shot('11-provider-home');

  await page.click('[data-nav="promotion"]');
  await page.waitForSelector('[data-tier]');
  await shot('12-provider-promotion');

  await page.click('[data-nav="deals"]');
  await page.waitForSelector('#deal-list');
  await shot('13-provider-deals');

  // --- admin ---
  await page.click('#sign-out');
  await page.waitForSelector('.hero h1', { timeout: 8000 });
  await page.click('#nav-signin');
  await page.waitForSelector('#li-email');
  await page.type('#li-email', 'admin@omniservice.center');
  await page.type('#li-pass', 'demo1234');
  await page.click('#li-go');
  await page.waitForSelector('.stat-value', { timeout: 8000 });
  await new Promise((r) => setTimeout(r, 900));
  await shot('14-admin-overview');

  await page.click('[data-nav="verify"]');
  await page.waitForSelector('#verify-list .rq-card, #verify-list .empty', { timeout: 8000 });
  await shot('15-admin-verify');

  await page.click('[data-nav="providers"]');
  await page.waitForSelector('#prov-table table', { timeout: 8000 });
  await shot('16-admin-providers');

  await page.click('[data-nav="reports"]');
  await page.waitForSelector('#rep-body table', { timeout: 8000 });
  await shot('17-admin-reports');

  await page.click('[data-nav="apps"]');
  await page.waitForSelector('[data-tool]');
  await shot('18-admin-apps');

  // --- mobile viewport ---
  await page.setViewport({ width: 390, height: 844 });
  await page.goto('http://localhost:3000/', { waitUntil: 'networkidle0' });
  await shot('19-mobile-landing');

  await browser.close();

  if (errors.length) {
    console.log('\n  JS ERRORS FOUND:');
    errors.forEach((e) => console.log('   ' + e));
    process.exit(1);
  }
  console.log('\n  No JavaScript errors. All screens rendered.\n');
})().catch((e) => {
  console.error('\n  UI CHECK FAILED: ' + e.message + '\n');
  process.exit(1);
});
