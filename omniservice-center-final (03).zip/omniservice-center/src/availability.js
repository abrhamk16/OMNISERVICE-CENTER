// src/availability.js
// Real provider scheduling: working days/hours, a break window, and a slot
// length, used to (a) generate the open slots a seeker or provider can pick
// from and (b) validate a chosen time server-side so two bookings can never
// land on the same slot — regardless of what the client sends.
//
// All times are handled with the JS Date object's *local* getters/setters
// (getHours, getDay, the (y,m,d,h,mi) constructor, etc.), never the UTC
// variants. That means "local" here means whatever timezone the Node
// process itself runs in — on Abrham's own machine that's Ethiopia (EAT),
// which is exactly the behaviour a single-country app wants without
// pulling in a timezone library. Generation and validation both go through
// this same module, so the two can never drift apart even if the server's
// timezone changes.

const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const DAY_LABELS = {
  sun: 'Sunday', mon: 'Monday', tue: 'Tuesday', wed: 'Wednesday',
  thu: 'Thursday', fri: 'Friday', sat: 'Saturday'
};

const DEFAULT_SCHEDULE = {
  workingDays: ['mon', 'tue', 'wed', 'thu', 'fri', 'sat'],
  startTime: '08:00',
  endTime: '18:00',
  breakStart: '12:00',
  breakEnd: '13:00',
  slotMinutes: 60
};

const VALID_SLOT_LENGTHS = [15, 30, 45, 60, 90, 120];
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
const MAX_DAYS_AHEAD = 60;

// Bookings in any of these states hold their slot. Completed/cancelled/
// rejected/etc. bookings free it back up for reuse.
const ACTIVE_BOOKING_STATUSES = ['accepted', 'scheduled', 'in_progress'];

function getSchedule(provider) {
  const s = (provider && provider.schedule) || {};
  return { ...DEFAULT_SCHEDULE, ...s };
}

function timeToMinutes(t) {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

// Validates one field at a time and returns a normalized patch — used when a
// provider PATCHes only some of their schedule fields.
function sanitizeScheduleFields(input = {}) {
  const errors = [];
  const patch = {};

  if (input.workingDays !== undefined) {
    const days = input.workingDays;
    if (!Array.isArray(days) || !days.length || days.some((d) => !DAY_KEYS.includes(d))) {
      errors.push('Working days must be a non-empty list of valid days.');
    } else {
      patch.workingDays = DAY_KEYS.filter((d) => days.includes(d));
    }
  }

  for (const key of ['startTime', 'endTime', 'breakStart', 'breakEnd']) {
    if (input[key] === undefined) continue;
    if (input[key] === null || input[key] === '') {
      patch[key] = null;
    } else if (typeof input[key] !== 'string' || !TIME_RE.test(input[key])) {
      errors.push(`${key === 'startTime' ? 'Opening time' : key === 'endTime' ? 'Closing time' : 'Break time'} must be in HH:MM 24-hour format.`);
    } else {
      patch[key] = input[key];
    }
  }

  if (input.slotMinutes !== undefined) {
    const n = Number(input.slotMinutes);
    if (!VALID_SLOT_LENGTHS.includes(n)) {
      errors.push(`Appointment length must be one of: ${VALID_SLOT_LENGTHS.join(', ')} minutes.`);
    } else {
      patch.slotMinutes = n;
    }
  }

  return { errors, patch };
}

// Validates a FULL merged schedule (existing + patch) for internal consistency.
function validateFullSchedule(schedule) {
  const errors = [];
  if (!schedule.startTime || !schedule.endTime) {
    errors.push('Set both an opening and a closing time.');
  } else if (timeToMinutes(schedule.startTime) >= timeToMinutes(schedule.endTime)) {
    errors.push('Opening time must be before closing time.');
  }
  const hasBreakStart = !!schedule.breakStart;
  const hasBreakEnd = !!schedule.breakEnd;
  if (hasBreakStart !== hasBreakEnd) {
    errors.push('Set both a break start and a break end, or leave both blank.');
  } else if (hasBreakStart && hasBreakEnd) {
    if (timeToMinutes(schedule.breakStart) >= timeToMinutes(schedule.breakEnd)) {
      errors.push('Break start must be before break end.');
    } else if (schedule.startTime && schedule.endTime) {
      const s = timeToMinutes(schedule.startTime), e = timeToMinutes(schedule.endTime);
      const bs = timeToMinutes(schedule.breakStart), be = timeToMinutes(schedule.breakEnd);
      if (bs < s || be > e) errors.push('The break must fall inside working hours.');
    }
  }
  return errors;
}

function pad2(n) {
  return String(n).padStart(2, '0');
}

function isoDate(d) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function parseDateOnly(dateStr) {
  const m = DATE_RE.exec(dateStr || '');
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return isNaN(d.getTime()) ? null : d;
}

function overlaps(aStart, aEnd, bStart, bEnd) {
  return aStart < bEnd && bStart < aEnd;
}

// existingBookings: raw booking records for this provider (any status) —
// filtered down to the active ones and to this calendar date internally.
function getAvailableSlots(schedule, dateStr, existingBookings, { now = new Date() } = {}) {
  const day = parseDateOnly(dateStr);
  if (!day) return { error: 'Give a date in YYYY-MM-DD format.' };

  const maxDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + MAX_DAYS_AHEAD);
  if (day > maxDate) return { error: `Pick a date within the next ${MAX_DAYS_AHEAD} days.` };

  const slotMinutes = schedule.slotMinutes || DEFAULT_SCHEDULE.slotMinutes;
  const dayKey = DAY_KEYS[day.getDay()];

  if (!schedule.workingDays.includes(dayKey)) {
    return { slots: [], slotMinutes, reason: `Not a working day — closed on ${DAY_LABELS[dayKey]}s.` };
  }
  if (!schedule.startTime || !schedule.endTime) {
    return { slots: [], slotMinutes, reason: 'This provider hasn\u2019t set working hours yet.' };
  }

  const startMin = timeToMinutes(schedule.startTime);
  const endMin = timeToMinutes(schedule.endTime);
  const breakStartMin = schedule.breakStart ? timeToMinutes(schedule.breakStart) : null;
  const breakEndMin = schedule.breakEnd ? timeToMinutes(schedule.breakEnd) : null;

  const dayBookings = (existingBookings || [])
    .filter((b) => b.scheduledFor && ACTIVE_BOOKING_STATUSES.includes(b.status))
    .map((b) => {
      const start = new Date(b.scheduledFor);
      return { start, minutes: b.slotMinutes || slotMinutes };
    })
    .filter((b) => !isNaN(b.start.getTime()) && isoDate(b.start) === dateStr);

  const slots = [];
  for (let m = startMin; m + slotMinutes <= endMin; m += slotMinutes) {
    if (breakStartMin !== null && breakEndMin !== null && m < breakEndMin && breakStartMin < m + slotMinutes) {
      continue; // this slot overlaps the break window
    }
    const slotStart = new Date(day.getFullYear(), day.getMonth(), day.getDate(), Math.floor(m / 60), m % 60);
    if (slotStart.getTime() <= now.getTime()) continue; // already past

    const slotEnd = new Date(slotStart.getTime() + slotMinutes * 60000);
    const conflict = dayBookings.some((b) => overlaps(slotStart, slotEnd, b.start, new Date(b.start.getTime() + b.minutes * 60000)));
    if (conflict) continue;

    slots.push(slotStart.toISOString());
  }

  return { slots, slotMinutes, reason: slots.length ? null : 'Fully booked that day — try another date.' };
}

// Validates a specific requested ISO datetime against a provider's real,
// currently-open slots (regenerated fresh, so it can't be stale). Returns
// either { scheduledFor, slotMinutes } or { error }.
function resolveRequestedSlot(db, provider, requestedIso, excludeBookingId) {
  if (!requestedIso) return { error: 'Pick a date and time.' };
  const requested = new Date(requestedIso);
  if (isNaN(requested.getTime())) return { error: 'That date/time isn\u2019t valid.' };

  const dateStr = isoDate(requested);
  const schedule = getSchedule(provider);
  const existing = db.filter(
    'bookings',
    (b) => b.providerId === provider.id && b.id !== excludeBookingId
  );

  const result = getAvailableSlots(schedule, dateStr, existing);
  if (result.error) return { error: result.error };
  if (!result.slots.includes(requested.toISOString())) {
    return { error: result.reason || 'That time is no longer available — please pick an open slot.' };
  }
  return { scheduledFor: requested.toISOString(), slotMinutes: result.slotMinutes };
}

module.exports = {
  DAY_KEYS,
  DAY_LABELS,
  DEFAULT_SCHEDULE,
  VALID_SLOT_LENGTHS,
  ACTIVE_BOOKING_STATUSES,
  getSchedule,
  sanitizeScheduleFields,
  validateFullSchedule,
  getAvailableSlots,
  resolveRequestedSlot,
  isoDate
};
