const express = require('express');
const omni = require('../omni');
const db = require('../db');
const { optionalAuth } = require('../middleware');

const router = express.Router();

// The live AI agent endpoint. Every call re-parses the input — nothing is
// cached or scripted, so judges can type any request and see real extraction.
router.post('/ask', optionalAuth, (req, res) => {
  const { message, lat, lng } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Type what you need and OMNI will find providers for it.' });
  }

  const origin = typeof lat === 'number' && typeof lng === 'number' ? { lat, lng } : null;
  const result = omni.match(message, origin);

  // Build a natural-language reply from the structured analysis.
  let reply;
  if (!result.understood) {
    reply = `I couldn't match that to a service category yet. Try naming the problem directly — for example "leaking pipe in Gondar" or "I need a tutor for maths this week".`;
  } else if (result.matches.length === 0) {
    reply = `I understood you need ${result.subcategory.label.toLowerCase()}${
      result.city ? ` in ${result.city}` : ''
    }, but no verified provider is listed for that yet. Post it as an open request and providers will be notified as they join.`;
  } else {
    const top = result.matches[0];
    reply = `You need ${result.subcategory.label.toLowerCase()}${
      result.city ? ` around ${result.city}` : ''
    }${result.timing.label !== 'flexible' ? `, ${result.timing.label}` : ''}. I found ${
      result.matches.length
    } verified provider${result.matches.length > 1 ? 's' : ''}. Top match: ${top.businessName} — trust score ${
      top.trustScore
    }${top.distanceKm !== null ? `, ${top.distanceKm} km from you` : ''}.`;
  }

  res.json({ ...result, reply });
});

// Lightweight search used by the search bar (same engine, no chat wrapper).
router.get('/search', (req, res) => {
  const { q, lat, lng } = req.query;
  if (!q) return res.status(400).json({ error: 'Add a search term.' });
  const origin = lat && lng ? { lat: Number(lat), lng: Number(lng) } : null;
  res.json(omni.match(q, origin));
});

// Map feed — every verified provider with coordinates, optionally filtered.
router.get('/map', (req, res) => {
  const { subcategoryKey, city } = req.query;
  let providers = db.filter('providerProfiles', (p) => p.status === 'verified' && p.lat && p.lng);
  if (subcategoryKey) providers = providers.filter((p) => p.subcategoryKeys.includes(subcategoryKey));
  if (city) providers = providers.filter((p) => p.city.toLowerCase().includes(city.toLowerCase()));

  res.json(
    providers.map((p) => ({
      id: p.id,
      businessName: p.businessName,
      city: p.city,
      lat: p.lat,
      lng: p.lng,
      trustScore: p.trustScore,
      availability: p.availability,
      categoryKey: p.categoryKey,
      subcategoryKeys: p.subcategoryKeys,
      isDemoData: p.isDemoData
    }))
  );
});

module.exports = router;
