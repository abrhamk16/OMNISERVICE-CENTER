const express = require('express');
const db = require('../db');
const omni = require('../omni');
const { requireAuth, requireRole } = require('../middleware');

const router = express.Router();

// The lifecycle defined in the product spec. Transitions are validated so the
// UI can never push a request into an impossible state.
const LIFECYCLE = {
  draft: ['submitted', 'cancelled'],
  submitted: ['matching', 'cancelled', 'expired'],
  matching: ['responses', 'cancelled', 'expired'],
  responses: ['provider_selected', 'cancelled', 'expired'],
  provider_selected: ['accepted', 'rejected', 'cancelled'],
  accepted: ['scheduled', 'cancelled'],
  scheduled: ['in_progress', 'cancelled'],
  in_progress: ['completed', 'failed', 'disputed'],
  completed: ['confirmed', 'disputed'],
  confirmed: ['reviewed'],
  reviewed: [],
  cancelled: [],
  rejected: [],
  expired: [],
  disputed: ['completed', 'cancelled'],
  failed: []
};

function notify(userId, title, body) {
  db.insert('notifications', {
    id: db.id('notif'),
    userId,
    title,
    body,
    read: false,
    createdAt: db.now()
  });
}

// Create a request. If `autoMatch` is set, OMNI runs immediately and the
// request jumps to `matching` with its ranked candidate list attached.
router.post('/', requireAuth, requireRole('seeker'), (req, res) => {
  const { description, subcategoryKey, city, lat, lng, budget, preferredDate, autoMatch } = req.body;
  if (!description || !description.trim()) {
    return res.status(400).json({ error: 'Describe what you need so providers can respond accurately.' });
  }

  const origin = typeof lat === 'number' && typeof lng === 'number' ? { lat, lng } : null;
  const analysis = omni.match(description, origin);

  const request = {
    id: db.id('req'),
    seekerId: req.user.id,
    description: description.trim(),
    subcategoryKey: subcategoryKey || (analysis.subcategory ? analysis.subcategory.key : null),
    categoryKey: analysis.category ? analysis.category.key : null,
    city: city || analysis.city || '',
    lat: origin ? lat : null,
    lng: origin ? lng : null,
    budget: budget || null,
    preferredDate: preferredDate || null,
    timing: analysis.timing,
    status: autoMatch ? 'matching' : 'submitted',
    candidates: autoMatch ? analysis.matches.map((m) => m.providerId) : [],
    omniReasoning: analysis.reasoning,
    createdAt: db.now()
  };
  db.insert('requests', request);

  if (autoMatch) {
    for (const m of analysis.matches.slice(0, 5)) {
      const provider = db.find('providerProfiles', (p) => p.id === m.providerId);
      if (provider) {
        notify(
          provider.userId,
          'New request matched to you',
          `A seeker in ${request.city || 'your area'} needs: ${request.description.slice(0, 80)}`
        );
      }
    }
  }

  res.status(201).json({ request, analysis });
});

// Seeker's own requests
router.get('/mine', requireAuth, requireRole('seeker'), (req, res) => {
  const requests = db.filter('requests', (r) => r.seekerId === req.user.id && !r.isDemoData).slice().reverse();
  const enriched = requests.map((r) => ({
    ...r,
    quotations: db.filter('quotations', (q) => q.requestId === r.id),
    booking: db.find('bookings', (b) => b.requestId === r.id)
  }));
  res.json(enriched);
});

// Requests visible to a provider — ones they were matched to or quoted on
router.get('/for-provider', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });

  const requests = db
    .filter(
      'requests',
      (r) =>
        !r.isDemoData &&
        (r.candidates || []).includes(provider.id) &&
        ['matching', 'responses', 'provider_selected', 'accepted', 'scheduled', 'in_progress'].includes(r.status)
    )
    .slice()
    .reverse();

  const enriched = requests.map((r) => ({
    ...r,
    myQuotation: db.find('quotations', (q) => q.requestId === r.id && q.providerId === provider.id),
    seeker: (() => {
      const u = db.find('users', (x) => x.id === r.seekerId);
      return u ? { id: u.id, fullName: u.fullName, city: u.city } : null;
    })()
  }));
  res.json(enriched);
});

router.get('/:id', requireAuth, (req, res) => {
  const request = db.find('requests', (r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: 'Request not found.' });
  res.json({
    ...request,
    quotations: db.filter('quotations', (q) => q.requestId === request.id),
    booking: db.find('bookings', (b) => b.requestId === request.id)
  });
});

// Re-run OMNI matching on an existing request
router.post('/:id/match', requireAuth, requireRole('seeker'), (req, res) => {
  const request = db.find('requests', (r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: 'Request not found.' });
  if (request.seekerId !== req.user.id) return res.status(403).json({ error: 'This is not your request.' });

  const origin = request.lat && request.lng ? { lat: request.lat, lng: request.lng } : null;
  const analysis = omni.match(request.description, origin);
  const updated = db.update('requests', request.id, {
    status: 'matching',
    candidates: analysis.matches.map((m) => m.providerId),
    omniReasoning: analysis.reasoning
  });
  res.json({ request: updated, analysis });
});

// Generic, validated status transition
router.patch('/:id/status', requireAuth, (req, res) => {
  const { status } = req.body;
  const request = db.find('requests', (r) => r.id === req.params.id);
  if (!request) return res.status(404).json({ error: 'Request not found.' });

  const allowed = LIFECYCLE[request.status] || [];
  if (!allowed.includes(status)) {
    return res.status(400).json({
      error: `A request in "${request.status}" can only move to: ${allowed.join(', ') || 'no further states'}.`
    });
  }

  const updated = db.update('requests', request.id, { status });

  const booking = db.find('bookings', (b) => b.requestId === request.id);
  if (booking) db.update('bookings', booking.id, { status: status === 'confirmed' ? 'completed' : status });

  res.json(updated);
});

module.exports = router;
