const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');

const router = express.Router();
const own = (req) => db.find('providerProfiles', (p) => p.userId === req.user.id);
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

// Deals past their end date stop showing publicly without being deleted.
const live = (x) => x.type !== 'deal' || !x.until || x.until >= new Date().toISOString().slice(0, 10);

router.get('/mine', requireAuth, requireRole('provider'), (req, res) => {
  const me = own(req);
  if (!me) return res.status(404).json({ error: 'Provider profile not found.' });
  const type = req.query.type;
  res.json(db.filter('promos', (x) => x.providerId === me.id && (!type || x.type === type)).slice().reverse());
});

// Public: what a seeker sees on a provider's profile. Ads are only shown for verified providers.
router.get('/provider/:providerId', (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.providerId);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  const items = db.filter('promos', (x) => x.providerId === provider.id && live(x));
  res.json({
    deals: items.filter((x) => x.type === 'deal'),
    ads: provider.status === 'verified' ? items.filter((x) => x.type === 'ad') : []
  });
});

router.post('/', requireAuth, requireRole('provider'), (req, res) => {
  const me = own(req);
  if (!me) return res.status(404).json({ error: 'Provider profile not found.' });
  const b = req.body || {};
  let promo;
  if (b.type === 'deal') {
    const title = str(b.title, 80);
    const discount = Math.round(Number(b.discount));
    if (!title) return res.status(400).json({ error: 'Give the deal a name.' });
    if (!(discount >= 1 && discount <= 90)) return res.status(400).json({ error: 'Discount must be between 1% and 90%.' });
    const until = str(b.until, 10);
    if (until && !/^\d{4}-\d{2}-\d{2}$/.test(until)) return res.status(400).json({ error: 'Invalid end date.' });
    promo = { title, service: str(b.service, 80), discount, until, terms: str(b.terms, 300) };
  } else if (b.type === 'ad') {
    const headline = str(b.headline, 60);
    if (!headline) return res.status(400).json({ error: 'Write a headline first.' });
    promo = { headline, body: str(b.body, 220), audience: str(b.audience, 60) };
  } else {
    return res.status(400).json({ error: 'type must be "deal" or "ad".' });
  }
  const record = { id: db.id('promo'), providerId: me.id, type: b.type, ...promo, createdAt: db.now() };
  db.insert('promos', record);
  res.status(201).json(record);
});

router.delete('/:id', requireAuth, requireRole('provider'), (req, res) => {
  const me = own(req);
  const promo = me && db.find('promos', (x) => x.id === req.params.id && x.providerId === me.id);
  if (!promo) return res.status(404).json({ error: 'Not found.' });
  db.remove('promos', promo.id);
  res.json({ ok: true });
});

module.exports = router;
