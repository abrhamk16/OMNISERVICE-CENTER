const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware');

const router = express.Router();

// --- Messaging: threads are keyed by requestId so conversation stays tied to a job ---

router.post('/messages', requireAuth, (req, res) => {
  const { requestId, toUserId, body } = req.body;
  if (!body || !body.trim()) return res.status(400).json({ error: 'Write a message before sending.' });

  const message = {
    id: db.id('msg'),
    requestId: requestId || null,
    fromUserId: req.user.id,
    fromName: req.user.fullName,
    toUserId,
    body: body.trim(),
    read: false,
    createdAt: db.now()
  };
  db.insert('messages', message);

  db.insert('notifications', {
    id: db.id('notif'),
    userId: toUserId,
    title: `Message from ${req.user.fullName}`,
    body: body.trim().slice(0, 90),
    read: false,
    createdAt: db.now()
  });

  res.status(201).json(message);
});

router.get('/messages', requireAuth, (req, res) => {
  const { requestId, withUserId } = req.query;
  let messages = db.filter(
    'messages',
    (m) => m.fromUserId === req.user.id || m.toUserId === req.user.id
  );
  if (requestId) messages = messages.filter((m) => m.requestId === requestId);
  if (withUserId) {
    messages = messages.filter((m) => m.fromUserId === withUserId || m.toUserId === withUserId);
  }
  res.json(messages);
});

// --- Notifications ---

router.get('/notifications', requireAuth, (req, res) => {
  const notifications = db.filter('notifications', (n) => n.userId === req.user.id).slice().reverse();
  res.json(notifications);
});

router.patch('/notifications/:id/read', requireAuth, (req, res) => {
  const notification = db.find('notifications', (n) => n.id === req.params.id);
  if (!notification) return res.status(404).json({ error: 'Notification not found.' });
  if (notification.userId !== req.user.id) return res.status(403).json({ error: 'Not your notification.' });
  res.json(db.update('notifications', notification.id, { read: true }));
});

router.post('/notifications/read-all', requireAuth, (req, res) => {
  const mine = db.filter('notifications', (n) => n.userId === req.user.id && !n.read);
  mine.forEach((n) => db.update('notifications', n.id, { read: true }));
  res.json({ marked: mine.length });
});

module.exports = router;
