const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');

const router = express.Router();

router.use(requireAuth, requireRole('admin'));

// --- Platform overview: real counts computed from the store, never hardcoded ---
router.get('/stats', (req, res) => {
  const users = db.all('users');
  const providers = db.all('providerProfiles');
  const requests = db.all('requests');
  const bookings = db.all('bookings');
  const reviews = db.all('reviews');
  const categories = db.all('categories');

  const verified = providers.filter((p) => p.status === 'verified');
  const completed = bookings.filter((b) => b.status === 'completed');
  const revenue = completed.reduce((sum, b) => sum + (b.price || 0), 0);
  const COMMISSION_RATE = 0.08;

  const payments = db.all('payments');
  const succeededPayments = payments.filter((p) => p.status === 'succeeded');

  const avgTrust = verified.length
    ? Math.round(verified.reduce((s, p) => s + p.trustScore, 0) / verified.length)
    : 0;

  // Providers per sector — drives the admin dashboard chart.
  const bySector = categories.map((c) => ({
    key: c.key,
    label: c.label,
    icon: c.icon,
    providers: verified.filter((p) => p.categoryKey === c.key).length
  }));

  // Requests by lifecycle state
  const byStatus = {};
  for (const r of requests) byStatus[r.status] = (byStatus[r.status] || 0) + 1;

  const ratingSpread = [1, 2, 3, 4, 5].map((star) => ({
    star,
    count: reviews.filter((r) => r.rating === star).length
  }));

  res.json({
    users: {
      total: users.length,
      seekers: users.filter((u) => u.role === 'seeker').length,
      providers: users.filter((u) => u.role === 'provider').length,
      admins: users.filter((u) => u.role === 'admin').length
    },
    providers: {
      total: providers.length,
      verified: verified.length,
      pending: providers.filter((p) => p.status === 'pending').length,
      rejected: providers.filter((p) => p.status === 'rejected').length,
      avgTrustScore: avgTrust
    },
    activity: {
      requests: requests.length,
      bookings: bookings.length,
      completedJobs: completed.length,
      reviews: reviews.length,
      openDisputes: db.filter('disputes', (d) => d.status === 'open').length
    },
    financial: {
      grossBookingValue: revenue,
      platformCommission: Math.round(revenue * COMMISSION_RATE),
      commissionRate: COMMISSION_RATE,
      currency: 'ETB'
    },
    payments: {
      mode: require('../payments').PAYMENT_MODE,
      total: payments.length,
      succeeded: succeededPayments.length,
      pending: payments.filter((p) => p.status === 'pending').length,
      failed: payments.filter((p) => p.status === 'failed').length,
      totalCollected: succeededPayments.reduce((s, p) => s + (p.amount || 0), 0),
      byMethod: require('../payments').PAYMENT_METHODS.map((m) => ({
        key: m.key,
        label: m.label,
        count: succeededPayments.filter((p) => p.method === m.key).length,
        total: succeededPayments.filter((p) => p.method === m.key).reduce((s, p) => s + (p.amount || 0), 0)
      }))
    },
    bySector,
    byStatus,
    ratingSpread
  });
});

// --- Provider verification queue ---
router.get('/providers', (req, res) => {
  const { status } = req.query;
  let providers = db.all('providerProfiles');
  if (status) providers = providers.filter((p) => p.status === status);

  const enriched = providers.slice().reverse().map((p) => {
    const user = db.find('users', (u) => u.id === p.userId);
    return {
      ...p,
      contact: user ? { fullName: user.fullName, email: user.email, phone: user.phone } : null,
      completedJobs: db.filter('bookings', (b) => b.providerId === p.id && b.status === 'completed').length,
      reviewCount: db.filter('reviews', (r) => r.providerId === p.id).length
    };
  });
  res.json(enriched);
});

router.patch('/providers/:id/verify', (req, res) => {
  const { decision, note } = req.body; // 'verified' | 'rejected' | 'suspended'
  const valid = ['verified', 'rejected', 'suspended', 'pending'];
  if (!valid.includes(decision)) {
    return res.status(400).json({ error: `Decision must be one of: ${valid.join(', ')}.` });
  }
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });

  const updated = db.update('providerProfiles', provider.id, {
    status: decision,
    reviewNote: note || '',
    reviewedAt: db.now()
  });

  const messages = {
    verified: 'Your account is verified. You now appear in search and can receive requests.',
    rejected: 'Your application was not approved. Review your documents and reapply.',
    suspended: 'Your account has been suspended. Contact platform support.',
    pending: 'Your account is back under review.'
  };
  db.insert('notifications', {
    id: db.id('notif'),
    userId: provider.userId,
    title: 'Account status updated',
    body: messages[decision] + (note ? ` Note: ${note}` : ''),
    read: false,
    createdAt: db.now()
  });

  res.json(updated);
});

// --- User directory ---
router.get('/users', (req, res) => {
  const { role } = req.query;
  let users = db.all('users');
  if (role) users = users.filter((u) => u.role === role);
  res.json(
    users.map(({ passwordHash, ...u }) => ({
      ...u,
      requestCount: db.filter('requests', (r) => r.seekerId === u.id).length
    }))
  );
});

// --- Reports: users and companies/organizations ---
router.get('/reports/companies', (req, res) => {
  const providers = db.filter('providerProfiles', (p) => p.status === 'verified');
  const rows = providers
    .map((p) => {
      const bookings = db.filter('bookings', (b) => b.providerId === p.id);
      const completed = bookings.filter((b) => b.status === 'completed');
      const reviews = db.filter('reviews', (r) => r.providerId === p.id);
      const revenue = completed.reduce((s, b) => s + (b.price || 0), 0);
      return {
        providerId: p.id,
        businessName: p.businessName,
        city: p.city,
        categoryKey: p.categoryKey,
        trustScore: p.trustScore,
        totalJobs: bookings.length,
        completedJobs: completed.length,
        completionRate: bookings.length ? Math.round((completed.length / bookings.length) * 100) : 0,
        reviewCount: reviews.length,
        avgRating: reviews.length
          ? Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 10) / 10
          : null,
        revenue,
        commission: Math.round(revenue * 0.08),
        isDemoData: p.isDemoData
      };
    })
    .sort((a, b) => b.revenue - a.revenue);
  res.json(rows);
});

router.get('/reports/users', (req, res) => {
  const seekers = db.filter('users', (u) => u.role === 'seeker');
  const rows = seekers
    .map((u) => {
      const requests = db.filter('requests', (r) => r.seekerId === u.id);
      const bookings = db.filter('bookings', (b) => b.seekerId === u.id);
      const spend = bookings
        .filter((b) => b.status === 'completed')
        .reduce((s, b) => s + (b.price || 0), 0);
      return {
        userId: u.id,
        fullName: u.fullName,
        email: u.email,
        city: u.city || '—',
        joinedAt: u.createdAt,
        requests: requests.length,
        bookings: bookings.length,
        reviewsLeft: db.filter('reviews', (r) => r.seekerId === u.id).length,
        totalSpend: spend,
        isDemoData: !!u.isDemoData
      };
    })
    .sort((a, b) => b.requests - a.requests);
  res.json(rows);
});

router.get('/reports/payments', (req, res) => {
  const rows = db
    .all('payments')
    .slice()
    .reverse()
    .map((p) => {
      const provider = p.providerId ? db.find('providerProfiles', (pr) => pr.id === p.providerId) : null;
      return {
        id: p.id,
        reference: p.reference,
        purpose: p.purposeLabel || p.type,
        type: p.type,
        payerName: p.payerName,
        businessName: provider ? provider.businessName : '—',
        method: p.methodLabel || p.method,
        amount: p.amount,
        currency: p.currency,
        status: p.status,
        mode: p.mode,
        createdAt: p.createdAt,
        confirmedAt: p.confirmedAt || null
      };
    });
  res.json(rows);
});

// --- Requests monitor ---
router.get('/requests', (req, res) => {
  const requests = db.all('requests').slice().reverse().slice(0, 200);
  res.json(
    requests.map((r) => ({
      ...r,
      seeker: (() => {
        const u = db.find('users', (x) => x.id === r.seekerId);
        return u ? u.fullName : 'Unknown';
      })()
    }))
  );
});

// --- Disputes ---
router.get('/disputes', (req, res) => {
  res.json(db.all('disputes').slice().reverse());
});

router.patch('/disputes/:id', (req, res) => {
  const { status, resolution } = req.body;
  const dispute = db.find('disputes', (d) => d.id === req.params.id);
  if (!dispute) return res.status(404).json({ error: 'Dispute not found.' });
  res.json(db.update('disputes', dispute.id, { status, resolution: resolution || '' }));
});

module.exports = router;
