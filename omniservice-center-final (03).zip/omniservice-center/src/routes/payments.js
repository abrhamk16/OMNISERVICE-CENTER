const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');
const payments = require('../payments');

const router = express.Router();

const PROMOTION_TIERS = {
  boosted: { name: 'Boosted listing', price: 450 },
  featured: { name: 'Featured provider', price: 1200 }
};

function notify(userId, title, body) {
  db.insert('notifications', {
    id: db.id('notif'),
    userId,
    title,
    body,
    read: false,
    createdAt: db.now()
  });
}

function publicPayment(p) {
  return p;
}

// Every method available on the platform, and whether we're running in
// sandbox mode. The frontend uses this to render the method picker and to
// show the "sandbox — no real money moves" notice honestly.
router.get('/methods', (req, res) => {
  res.json({
    mode: payments.PAYMENT_MODE,
    methods: payments.PAYMENT_METHODS
  });
});

// Step 1 — validate details and create a pending payment record.
router.post('/initiate', requireAuth, (req, res) => {
  const { purpose, bookingId, tier, method, details } = req.body;
  const methodDef = payments.methodByKey(method);
  if (!methodDef) return res.status(400).json({ error: 'Choose a payment method.' });

  let amount, currency = 'ETB', payload;

  if (purpose === 'booking') {
    const booking = db.find('bookings', (b) => b.id === bookingId);
    if (!booking) return res.status(404).json({ error: 'Booking not found.' });
    if (booking.seekerId !== req.user.id) return res.status(403).json({ error: 'This is not your booking.' });
    if (db.find('payments', (p) => p.bookingId === booking.id && p.status === 'succeeded')) {
      return res.status(409).json({ error: 'This booking has already been paid.' });
    }
    amount = booking.price;
    const provider = db.find('providerProfiles', (pr) => pr.id === booking.providerId);
    payload = {
      type: 'booking',
      bookingId: booking.id,
      requestId: booking.requestId,
      providerId: booking.providerId,
      purposeLabel: `Payment for booking with ${provider ? provider.businessName : 'provider'}`
    };
  } else if (purpose === 'promotion') {
    if (req.user.role !== 'provider') return res.status(403).json({ error: 'Only providers can purchase promotion.' });
    const tierDef = PROMOTION_TIERS[tier];
    if (!tierDef) return res.status(400).json({ error: 'Choose a valid promotion tier.' });
    const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
    if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
    if (provider.status !== 'verified') {
      return res.status(403).json({ error: 'Verify your business before purchasing promotion.' });
    }
    amount = tierDef.price;
    payload = {
      type: 'promotion',
      tier,
      providerId: provider.id,
      purposeLabel: `${tierDef.name} — 1 month`
    };
  } else {
    return res.status(400).json({ error: 'Unknown payment purpose.' });
  }

  const result = payments.initiate(method, details || {}, amount);
  if (!result.ok) return res.status(400).json({ error: result.error });

  const payment = {
    id: db.id('pay'),
    ...payload,
    payerUserId: req.user.id,
    payerName: req.user.fullName,
    method,
    methodLabel: result.methodLabel,
    methodDetail: result.maskedDetail,
    amount,
    currency,
    status: 'pending',
    reference: result.reference,
    instructions: result.instructions,
    mode: result.mode,
    isDemoData: false,
    createdAt: db.now()
  };
  db.insert('payments', payment);

  res.status(201).json(publicPayment(payment));
});

// Step 2 — confirm the pending payment (simulates the gateway webhook / return leg).
router.post('/:id/confirm', requireAuth, (req, res) => {
  const payment = db.find('payments', (p) => p.id === req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found.' });
  if (payment.payerUserId !== req.user.id) return res.status(403).json({ error: 'This is not your payment.' });
  if (payment.status !== 'pending') {
    return res.status(400).json({ error: `This payment is already ${payment.status}.` });
  }

  const result = payments.confirm();
  const updated = db.update('payments', payment.id, {
    status: result.ok ? 'succeeded' : 'failed',
    confirmedAt: result.confirmedAt
  });

  if (result.ok && payment.type === 'booking') {
    db.update('bookings', payment.bookingId, { paymentStatus: 'paid', paymentId: payment.id });
    const provider = db.find('providerProfiles', (p) => p.id === payment.providerId);
    if (provider) {
      notify(
        provider.userId,
        'Payment received',
        `${req.user.fullName} paid ${payment.amount} ${payment.currency} via ${payment.methodLabel}. Reference ${payment.reference}.`
      );
    }
    notify(req.user.id, 'Payment successful', `Your payment of ${payment.amount} ${payment.currency} was confirmed. Reference ${payment.reference}.`);
  }

  if (result.ok && payment.type === 'promotion') {
    db.insert('promotions', {
      id: db.id('promo'),
      providerId: payment.providerId,
      tier: payment.tier,
      active: true,
      paymentId: payment.id,
      startedAt: db.now(),
      isDemoData: false
    });
    notify(req.user.id, 'Promotion active', `${payment.purposeLabel} is now active. Reference ${payment.reference}.`);
  }

  res.json(publicPayment(updated));
});

// Payments I made (as a seeker paying for bookings, or a provider buying promotion).
router.get('/mine', requireAuth, (req, res) => {
  const mine = db
    .filter('payments', (p) => p.payerUserId === req.user.id)
    .slice()
    .reverse();
  res.json(mine.map(publicPayment));
});

router.get('/for-booking/:bookingId', requireAuth, (req, res) => {
  const booking = db.find('bookings', (b) => b.id === req.params.bookingId);
  if (!booking) return res.status(404).json({ error: 'Booking not found.' });
  const provider = db.find('providerProfiles', (p) => p.id === booking.providerId);
  const isSeeker = booking.seekerId === req.user.id;
  const isProvider = provider && provider.userId === req.user.id;
  if (!isSeeker && !isProvider) return res.status(403).json({ error: 'Not your booking.' });

  const list = db
    .filter('payments', (p) => p.bookingId === booking.id)
    .slice()
    .reverse();
  res.json(list.map(publicPayment));
});

router.get('/:id', requireAuth, (req, res) => {
  const payment = db.find('payments', (p) => p.id === req.params.id);
  if (!payment) return res.status(404).json({ error: 'Payment not found.' });

  let allowed = payment.payerUserId === req.user.id;
  if (!allowed && payment.providerId) {
    const provider = db.find('providerProfiles', (p) => p.id === payment.providerId);
    allowed = provider && provider.userId === req.user.id;
  }
  if (!allowed && req.user.role === 'admin') allowed = true;
  if (!allowed) return res.status(403).json({ error: 'Not your payment.' });

  res.json(publicPayment(payment));
});

// --- Admin: every transaction on the platform ---
router.get('/', requireAuth, requireRole('admin'), (req, res) => {
  const all = db.all('payments').slice().reverse();
  res.json(all.map(publicPayment));
});

module.exports = router;
