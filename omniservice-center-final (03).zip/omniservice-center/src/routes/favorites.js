const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');

const router = express.Router();

// A seeker's saved providers, enriched with the current provider record so
// the frontend can render a card straight from this one call.
router.get('/mine', requireAuth, requireRole('seeker'), (req, res) => {
  const favorites = db.filter('favorites', (f) => f.seekerId === req.user.id).slice().reverse();
  const enriched = favorites
    .map((f) => ({ ...f, provider: db.find('providerProfiles', (p) => p.id === f.providerId) }))
    .filter((f) => f.provider); // a favorited provider that no longer exists just drops silently
  res.json(enriched);
});

router.post('/:providerId', requireAuth, requireRole('seeker'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.providerId);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  if (db.find('favorites', (f) => f.seekerId === req.user.id && f.providerId === provider.id)) {
    return res.status(409).json({ error: 'Already in your favorites.' });
  }
  const favorite = {
    id: db.id('fav'),
    seekerId: req.user.id,
    providerId: provider.id,
    createdAt: db.now()
  };
  db.insert('favorites', favorite);
  res.status(201).json(favorite);
});

router.delete('/:providerId', requireAuth, requireRole('seeker'), (req, res) => {
  const favorite = db.find(
    'favorites',
    (f) => f.seekerId === req.user.id && f.providerId === req.params.providerId
  );
  if (!favorite) return res.status(404).json({ error: 'Not in your favorites.' });
  db.remove('favorites', favorite.id);
  res.json({ ok: true });
});

module.exports = router;
