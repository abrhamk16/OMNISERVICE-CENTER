const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');
const { computeTrustScore } = require('../trustScore');

const router = express.Router();

router.post('/', requireAuth, requireRole('seeker'), (req, res) => {
  const { bookingId, rating, comment } = req.body;
  const booking = db.find('bookings', (b) => b.id === bookingId);
  if (!booking) return res.status(404).json({ error: 'Booking not found.' });
  if (booking.seekerId !== req.user.id) return res.status(403).json({ error: 'This is not your booking.' });
  if (booking.status !== 'completed') {
    return res.status(400).json({ error: 'You can review a job once it is marked complete.' });
  }
  if (db.find('reviews', (r) => r.bookingId === bookingId)) {
    return res.status(409).json({ error: 'You already reviewed this job.' });
  }
  const numericRating = Number(rating);
  if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
    return res.status(400).json({ error: 'Rating must be a whole number from 1 to 5.' });
  }

  const review = {
    id: db.id('rev'),
    bookingId,
    providerId: booking.providerId,
    seekerId: req.user.id,
    reviewerName: req.user.fullName,
    rating: numericRating,
    comment: (comment || '').trim(),
    createdAt: db.now()
  };
  db.insert('reviews', review);
  db.update('requests', booking.requestId, { status: 'reviewed' });

  // A new review immediately moves the provider's trust score — this is what
  // makes the score dynamic rather than a static number on a profile.
  const reviews = db.filter('reviews', (r) => r.providerId === booking.providerId);
  const bookings = db.filter('bookings', (b) => b.providerId === booking.providerId);
  const { score, breakdown } = computeTrustScore({ reviews, bookings });
  db.update('providerProfiles', booking.providerId, { trustScore: score });

  res.status(201).json({ review, newTrustScore: score, breakdown });
});

router.get('/for-provider/:providerId', (req, res) => {
  const reviews = db.filter('reviews', (r) => r.providerId === req.params.providerId).slice().reverse();
  res.json(reviews);
});

module.exports = router;
