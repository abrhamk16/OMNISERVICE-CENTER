const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware');
const { computeTrustScore } = require('../trustScore');
const {
  getSchedule,
  sanitizeScheduleFields,
  validateFullSchedule,
  getAvailableSlots,
  ACTIVE_BOOKING_STATUSES
} = require('../availability');

const router = express.Router();

// Compressed client-side to a small JPEG/PNG data URI before it ever reaches
// here — this is just a sane server-side ceiling so nobody can bloat the
// JSON datastore with a full-resolution photo.
const MAX_IMAGE_DATA_URI_LENGTH = 400000;

function validImageDataUri(value) {
  if (value === null) return true; // explicit clear
  if (typeof value !== 'string') return false;
  if (!/^data:image\/(png|jpe?g|webp);base64,/.test(value)) return false;
  return value.length <= MAX_IMAGE_DATA_URI_LENGTH;
}

// Public search/browse — filter by category, subcategory, city, min trust score.
router.get('/', (req, res) => {
  const { categoryKey, subcategoryKey, city, minTrust, availability } = req.query;
  let providers = db.filter('providerProfiles', (p) => p.status === 'verified');

  if (categoryKey) providers = providers.filter((p) => p.categoryKey === categoryKey);
  if (subcategoryKey) providers = providers.filter((p) => p.subcategoryKeys.includes(subcategoryKey));
  if (city) providers = providers.filter((p) => p.city.toLowerCase().includes(city.toLowerCase()));
  if (minTrust) providers = providers.filter((p) => p.trustScore >= Number(minTrust));
  if (availability) providers = providers.filter((p) => p.availability === availability);

  providers = providers.slice().sort((a, b) => b.trustScore - a.trustScore);
  res.json(providers);
});

router.get('/:id', (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  res.json(provider);
});

router.get('/:id/reviews', (req, res) => {
  const reviews = db.filter('reviews', (r) => r.providerId === req.params.id).slice().reverse();
  res.json(reviews);
});

// Provider viewing/editing their own profile
router.get('/me/profile', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
  const activePromotions = db.filter('promotions', (pr) => pr.providerId === provider.id && pr.active);
  res.json({ ...provider, activePromotions });
});

router.patch('/me/profile', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });

  const allowed = ['businessName', 'bio', 'city', 'lat', 'lng', 'priceIndex', 'availability', 'subcategoryKeys', 'categoryKey', 'avatarUrl'];
  const patch = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  if (patch.avatarUrl !== undefined && !validImageDataUri(patch.avatarUrl)) {
    return res.status(400).json({ error: 'That image is an unsupported format or too large.' });
  }
  const updated = db.update('providerProfiles', provider.id, patch);
  res.json(updated);
});

// ---- Availability: real working days/hours/break/slot-length, used to
// generate the open slots seekers see and providers pick a booking into. ----

router.patch('/me/schedule', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });

  const { errors, patch } = sanitizeScheduleFields(req.body);
  if (errors.length) return res.status(400).json({ error: errors[0] });

  const merged = { ...getSchedule(provider), ...patch };
  const fullErrors = validateFullSchedule(merged);
  if (fullErrors.length) return res.status(400).json({ error: fullErrors[0] });

  const updated = db.update('providerProfiles', provider.id, { schedule: merged });
  res.json(updated);
});

// Real open slots for a given date — the SAME computation used to validate a
// booking server-side, so what's shown here is never stale or fake.
router.get('/:id/slots', (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  if (!req.query.date) return res.status(400).json({ error: 'A date (YYYY-MM-DD) is required.' });

  const schedule = getSchedule(provider);
  const existing = db.filter(
    'bookings',
    (b) => b.providerId === provider.id && ACTIVE_BOOKING_STATUSES.includes(b.status)
  );
  const result = getAvailableSlots(schedule, req.query.date, existing);
  if (result.error) return res.status(400).json({ error: result.error });
  res.json({ date: req.query.date, schedule, ...result });
});

// ---- Offerings: the products/services a provider showcases on their profile ----

router.get('/:id/offerings', (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  res.json(provider.offerings || []);
});

router.post('/me/offerings', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });

  const { type, name, description, price, unit, photoUrl } = req.body;
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'Give it a name.' });
  if (price !== undefined && price !== null && price !== '' && Number(price) < 0) {
    return res.status(400).json({ error: 'Price can\u2019t be negative.' });
  }
  if (photoUrl && !validImageDataUri(photoUrl)) {
    return res.status(400).json({ error: 'That photo is an unsupported format or too large.' });
  }

  const offering = {
    id: db.id('off'),
    type: type === 'product' ? 'product' : 'service',
    name: String(name).trim().slice(0, 80),
    description: (description || '').toString().slice(0, 400),
    price: price === undefined || price === null || price === '' ? null : Number(price),
    unit: (unit || '').toString().slice(0, 24),
    photoUrl: photoUrl || null,
    createdAt: db.now()
  };
  const offerings = [...(provider.offerings || []), offering];
  db.update('providerProfiles', provider.id, { offerings });
  res.status(201).json(offering);
});

router.patch('/me/offerings/:offeringId', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
  const offerings = provider.offerings || [];
  const idx = offerings.findIndex((o) => o.id === req.params.offeringId);
  if (idx === -1) return res.status(404).json({ error: 'Offering not found.' });

  const patchable = ['type', 'name', 'description', 'price', 'unit', 'photoUrl'];
  const patch = {};
  for (const key of patchable) {
    if (req.body[key] !== undefined) patch[key] = req.body[key];
  }
  if (patch.photoUrl && !validImageDataUri(patch.photoUrl)) {
    return res.status(400).json({ error: 'That photo is an unsupported format or too large.' });
  }
  if (patch.price !== undefined && patch.price !== null && patch.price !== '' && Number(patch.price) < 0) {
    return res.status(400).json({ error: 'Price can\u2019t be negative.' });
  }
  if (patch.price !== undefined) patch.price = patch.price === null || patch.price === '' ? null : Number(patch.price);
  if (patch.name !== undefined) patch.name = String(patch.name).trim().slice(0, 80);
  if (patch.description !== undefined) patch.description = String(patch.description).slice(0, 400);

  const updatedOffering = { ...offerings[idx], ...patch };
  const next = offerings.slice();
  next[idx] = updatedOffering;
  db.update('providerProfiles', provider.id, { offerings: next });
  res.json(updatedOffering);
});

router.delete('/me/offerings/:offeringId', requireAuth, requireRole('provider'), (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.userId === req.user.id);
  if (!provider) return res.status(404).json({ error: 'Provider profile not found.' });
  const offerings = (provider.offerings || []).filter((o) => o.id !== req.params.offeringId);
  db.update('providerProfiles', provider.id, { offerings });
  res.json({ ok: true });
});

// Recompute a provider's trust score from current bookings/reviews (used after each completed job).
router.post('/:id/recompute-trust', requireAuth, (req, res) => {
  const provider = db.find('providerProfiles', (p) => p.id === req.params.id);
  if (!provider) return res.status(404).json({ error: 'Provider not found.' });
  const reviews = db.filter('reviews', (r) => r.providerId === provider.id);
  const bookings = db.filter('bookings', (b) => b.providerId === provider.id);
  const { score, breakdown } = computeTrustScore({ reviews, bookings });
  const updated = db.update('providerProfiles', provider.id, { trustScore: score });
  res.json({ trustScore: updated.trustScore, breakdown });
});

module.exports = router;
