// src/payments.js
// Payment method catalogue + a sandboxed processor.
//
// This is a real, extensible payment architecture — a method registry, real
// input validation per method, a two-step initiate/confirm flow that mirrors
// how Telebirr, CBE Birr, and card/PayPal integrations actually work
// (push a prompt or redirect, then confirm on a webhook or return leg) — but
// it never talks to a live gateway. No API keys for Telebirr, CBE, PayPal or
// a card network are configured anywhere in this project, so every
// transaction runs in PAYMENT_MODE=sandbox and is clearly labelled as such
// end to end. Per the project rule: never claim a payment provider is live
// until its real API is configured and tested. Swapping any one method to a
// real gateway later means implementing that method's `process()` function
// against the real API — the route layer, the receipt model and the UI never
// need to change.

const crypto = require('crypto');

// Only ever 'sandbox' unless a real gateway is wired in. There is
// intentionally no code path that flips this to 'live' on its own.
const PAYMENT_MODE = 'sandbox';

const PAYMENT_METHODS = [
  {
    key: 'telebirr',
    label: 'Telebirr',
    group: 'ethiopian',
    icon: '📱',
    blurb: 'Pay with your Telebirr mobile wallet.',
    fields: [{ name: 'phone', label: 'Telebirr phone number', type: 'tel', placeholder: '09xx xxx xxx' }]
  },
  {
    key: 'cbe_birr',
    label: 'CBE Birr',
    group: 'ethiopian',
    icon: '🏦',
    blurb: 'Pay with the Commercial Bank of Ethiopia mobile wallet.',
    fields: [{ name: 'phone', label: 'CBE Birr phone number', type: 'tel', placeholder: '09xx xxx xxx' }]
  },
  {
    key: 'bank_transfer',
    label: 'Ethiopian bank transfer',
    group: 'ethiopian',
    icon: '🏛️',
    blurb: 'Transfer directly from an Ethiopian bank account.',
    banks: [
      'Commercial Bank of Ethiopia (CBE)',
      'Bank of Abyssinia',
      'Dashen Bank',
      'Awash Bank',
      'Hibret Bank',
      'Wegagen Bank',
      'Nib International Bank'
    ],
    fields: [
      { name: 'bank', label: 'Your bank', type: 'select', options: 'banks' },
      { name: 'accountLast4', label: 'Account number (last 4 digits)', type: 'text', placeholder: '1234', maxlength: 4 }
    ]
  },
  {
    key: 'paypal',
    label: 'PayPal',
    group: 'global',
    icon: '🌐',
    blurb: 'Pay with your PayPal account — for providers and seekers paying from abroad.',
    fields: [{ name: 'email', label: 'PayPal email address', type: 'email', placeholder: 'you@example.com' }]
  },
  {
    key: 'card',
    label: 'Debit / Credit card',
    group: 'global',
    icon: '💳',
    blurb: 'Visa and Mastercard, issued in Ethiopia or abroad.',
    fields: [
      { name: 'cardNumber', label: 'Card number', type: 'text', placeholder: '4242 4242 4242 4242' },
      { name: 'expiry', label: 'Expiry (MM/YY)', type: 'text', placeholder: '09/28' },
      { name: 'cvv', label: 'CVV', type: 'text', placeholder: '123', maxlength: 4 },
      { name: 'name', label: 'Name on card', type: 'text', placeholder: 'As shown on the card' }
    ]
  }
];

function methodByKey(key) {
  return PAYMENT_METHODS.find((m) => m.key === key) || null;
}

function reference() {
  return 'OSC-' + crypto.randomBytes(5).toString('hex').toUpperCase();
}

// ---- validation -------------------------------------------------------

function isEthiopianPhone(v) {
  const digits = String(v || '').replace(/[^\d]/g, '');
  // 09XXXXXXXX (10) or 2519XXXXXXXX (12) or 9XXXXXXXX (9, no leading 0)
  return /^09\d{8}$/.test(digits) || /^2519\d{8}$/.test(digits) || /^9\d{8}$/.test(digits);
}

function luhnValid(num) {
  const digits = String(num || '').replace(/\D/g, '');
  if (digits.length < 12 || digits.length > 19) return false;
  let sum = 0;
  let alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (alt) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

function cardBrand(num) {
  const digits = String(num || '').replace(/\D/g, '');
  if (/^4/.test(digits)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(digits)) return 'Mastercard';
  return 'Card';
}

function expiryValid(mmYY) {
  const m = String(mmYY || '').match(/^(\d{2})\s*\/\s*(\d{2})$/);
  if (!m) return false;
  const month = Number(m[1]);
  const year = 2000 + Number(m[2]);
  if (month < 1 || month > 12) return false;
  const expiryEnd = new Date(year, month, 1); // first day of the month AFTER expiry
  return expiryEnd.getTime() > Date.now();
}

// Validate the submitted details for a method. Returns { ok, error, maskedDetail }.
function validate(methodKey, details = {}) {
  const method = methodByKey(methodKey);
  if (!method) return { ok: false, error: 'Unknown payment method.' };

  if (methodKey === 'telebirr' || methodKey === 'cbe_birr') {
    if (!isEthiopianPhone(details.phone)) {
      return { ok: false, error: 'Enter a valid Ethiopian mobile number (e.g. 09xx xxx xxx).' };
    }
    const digits = String(details.phone).replace(/[^\d]/g, '');
    const last4 = digits.slice(-4);
    return { ok: true, maskedDetail: `•••• ${last4}` };
  }

  if (methodKey === 'bank_transfer') {
    if (!details.bank || !method.banks.includes(details.bank)) {
      return { ok: false, error: 'Choose which bank you are transferring from.' };
    }
    if (!/^\d{4}$/.test(String(details.accountLast4 || ''))) {
      return { ok: false, error: 'Enter the last 4 digits of the account number.' };
    }
    return { ok: true, maskedDetail: `${details.bank} •••• ${details.accountLast4}` };
  }

  if (methodKey === 'paypal') {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(details.email || ''))) {
      return { ok: false, error: 'Enter a valid PayPal email address.' };
    }
    return { ok: true, maskedDetail: details.email };
  }

  if (methodKey === 'card') {
    if (!luhnValid(details.cardNumber)) {
      return { ok: false, error: 'That card number doesn\u2019t look valid. Double-check the digits.' };
    }
    if (!expiryValid(details.expiry)) {
      return { ok: false, error: 'That expiry date is invalid or has already passed.' };
    }
    if (!/^\d{3,4}$/.test(String(details.cvv || ''))) {
      return { ok: false, error: 'Enter the 3 or 4 digit CVV from the back of the card.' };
    }
    const digits = String(details.cardNumber).replace(/\D/g, '');
    return { ok: true, maskedDetail: `${cardBrand(details.cardNumber)} •••• ${digits.slice(-4)}` };
  }

  return { ok: false, error: 'Unsupported payment method.' };
}

// Initiate a payment — validates, then returns the instructions the UI
// shows while the (simulated) confirmation is in flight.
function initiate(methodKey, details, amount) {
  const method = methodByKey(methodKey);
  const check = validate(methodKey, details);
  if (!check.ok) return { ok: false, error: check.error };

  const instructions = {
    telebirr: 'A Telebirr payment prompt has been sent to your phone (sandbox). Approve it to complete this payment.',
    cbe_birr: 'A CBE Birr payment prompt has been sent to your phone (sandbox). Approve it to complete this payment.',
    bank_transfer: `You'll be shown transfer details for ${details.bank} (sandbox). Confirm once the transfer is sent.`,
    paypal: 'You would normally be redirected to PayPal to approve this payment (sandbox).',
    card: 'Authorizing your card with the issuing bank (sandbox).'
  }[methodKey];

  return {
    ok: true,
    reference: reference(),
    maskedDetail: check.maskedDetail,
    methodLabel: method.label,
    instructions,
    mode: PAYMENT_MODE
  };
}

// Confirm a pending payment. In sandbox mode this simulates the
// webhook/return-leg a real gateway would send — deterministic success,
// since `initiate` already rejected anything invalid.
function confirm() {
  return { ok: true, confirmedAt: new Date().toISOString() };
}

module.exports = {
  PAYMENT_MODE,
  PAYMENT_METHODS,
  methodByKey,
  validate,
  initiate,
  confirm,
  reference
};
