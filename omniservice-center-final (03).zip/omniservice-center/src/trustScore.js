// src/trustScore.js
// Computes a provider's dynamic Trust Score from real signals: reviews,
// completed jobs, response time, cancellations, and completion rate.
// Pure function of data already in the store — never hand-set or faked.

function computeTrustScore({ reviews, bookings }) {
  if (bookings.length === 0 && reviews.length === 0) {
    return { score: 0, breakdown: null };
  }

  const completed = bookings.filter((b) => b.status === 'completed');
  const cancelled = bookings.filter((b) => b.status === 'cancelled');
  const totalDecided = completed.length + cancelled.length;

  const avgRating = reviews.length
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : null;

  const completionRate = totalDecided > 0 ? completed.length / totalDecided : null;
  const cancellationRate = totalDecided > 0 ? cancelled.length / totalDecided : 0;

  const respondedQuotes = bookings.filter((b) => typeof b.responseMinutes === 'number');
  const avgResponseMinutes = respondedQuotes.length
    ? respondedQuotes.reduce((sum, b) => sum + b.responseMinutes, 0) / respondedQuotes.length
    : null;

  // Weighted components, each normalized to 0-100.
  const ratingComponent = avgRating !== null ? (avgRating / 5) * 100 : 60; // neutral start
  const completionComponent = completionRate !== null ? completionRate * 100 : 70;
  const cancellationPenalty = cancellationRate * 100;
  const responseComponent =
    avgResponseMinutes !== null
      ? Math.max(0, 100 - Math.min(avgResponseMinutes, 240) / 2.4)
      : 65;
  const volumeBonus = Math.min(completed.length * 1.5, 15);

  let score =
    ratingComponent * 0.4 +
    completionComponent * 0.25 +
    responseComponent * 0.2 +
    volumeBonus -
    cancellationPenalty * 0.15;

  score = Math.max(0, Math.min(100, Math.round(score)));

  return {
    score,
    breakdown: {
      avgRating: avgRating !== null ? Math.round(avgRating * 10) / 10 : null,
      completionRate: completionRate !== null ? Math.round(completionRate * 100) : null,
      cancellationRate: Math.round(cancellationRate * 100),
      avgResponseMinutes: avgResponseMinutes !== null ? Math.round(avgResponseMinutes) : null,
      completedJobs: completed.length,
      reviewCount: reviews.length
    }
  };
}

module.exports = { computeTrustScore };
