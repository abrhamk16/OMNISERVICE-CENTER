// test-flow.js — end-to-end check of the full service lifecycle.
// Run with the server already listening: node test-flow.js
const BASE = 'http://localhost:3000/api';

async function call(method, path, { token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`${method} ${path} -> ${res.status}: ${text.slice(0, 200)}`);
  }
  if (!res.ok) throw new Error(`${method} ${path} -> ${res.status}: ${JSON.stringify(json)}`);
  return json;
}

const db = require('./src/db');
const ok = (msg) => console.log(`  PASS  ${msg}`);

// Scans forward day by day and returns the first date (and its real open
// slots) this provider actually has availability on — used instead of
// picking an arbitrary timestamp, since schedules now vary provider to
// provider and slots can already be full.
async function findOpenSlot(providerId, { afterDays = 1, withinDays = 21 } = {}) {
  for (let i = afterDays; i <= withinDays; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dateStr = d.toISOString().slice(0, 10);
    const res = await call('GET', `/providers/${providerId}/slots?date=${dateStr}`);
    if (res.slots && res.slots.length) return { dateStr, slots: res.slots };
  }
  throw new Error(`No open slot found for provider ${providerId} within ${withinDays} days`);
}

(async () => {
  console.log('\nOMNISERVICE CENTER — end-to-end lifecycle test\n');

  const health = await call('GET', '/health');
  ok(`API healthy — ${health.providers} providers, ${health.users} users`);

  const cats = await call('GET', '/categories');
  if (cats.length !== 12) throw new Error(`expected 12 sectors, got ${cats.length}`);
  ok(`12 service sectors loaded`);

  // 1. Seeker logs in
  const seeker = await call('POST', '/auth/login', {
    body: { email: 'seeker1@omniservice.center', password: 'demo1234' }
  });
  ok(`Seeker logged in as ${seeker.user.fullName}`);

  // 2. OMNI understands free text
  const ask = await call('POST', '/omni/ask', {
    body: { message: 'my kitchen pipe is leaking badly, need a plumber in Gondar today', lat: 12.603, lng: 37.4521 }
  });
  if (!ask.understood || ask.subcategory.key !== 'plumbing') throw new Error('OMNI failed to detect plumbing');
  if (ask.city !== 'gondar') throw new Error('OMNI failed to detect Gondar');
  if (ask.timing.label !== 'today') throw new Error('OMNI failed to detect timing');
  ok(`OMNI parsed intent=${ask.subcategory.label}, city=${ask.city}, timing=${ask.timing.label}, ${ask.matches.length} matches`);
  ok(`  top match: ${ask.matches[0].businessName} (score ${ask.matches[0].matchScore}) — ${ask.matches[0].reasons.join('; ')}`);

  // OMNI handles something completely different
  const ask2 = await call('POST', '/omni/ask', {
    body: { message: 'I want a tutor to help me prepare for my exams next week' }
  });
  if (ask2.subcategory.key !== 'tutoring') throw new Error('OMNI failed on tutoring query');
  ok(`OMNI parsed a different query: ${ask2.subcategory.label}, timing=${ask2.timing.label}`);

  // OMNI honestly reports when it can't match
  const ask3 = await call('POST', '/omni/ask', { body: { message: 'asdkjh qwe zxcv' } });
  if (ask3.understood) throw new Error('OMNI should not have understood gibberish');
  ok('OMNI correctly reports when it cannot match a query');

  // 3. Seeker posts a request with auto-matching
  const created = await call('POST', '/requests', {
    token: seeker.token,
    body: {
      description: 'my kitchen pipe is leaking badly, need a plumber in Gondar today',
      lat: 12.603,
      lng: 37.4521,
      autoMatch: true
    }
  });
  const requestId = created.request.id;
  if (created.request.status !== 'matching') throw new Error('request should be in matching state');
  ok(`Request created and auto-matched to ${created.request.candidates.length} providers`);

  // 4. Top-matched provider logs in
  const topProviderId = created.analysis.matches[0].providerId;
  const providerProfile = db.find('providerProfiles', (p) => p.id === topProviderId);
  const providerUser = db.find('users', (u) => u.id === providerProfile.userId);
  const provider = await call('POST', '/auth/login', {
    body: { email: providerUser.email, password: 'demo1234' }
  });
  const trustBefore = providerProfile.trustScore;
  ok(`Provider logged in: ${provider.provider.businessName} (trust score ${trustBefore})`);

  // Provider sees the request in their queue
  const queue = await call('GET', '/requests/for-provider', { token: provider.token });
  if (!queue.find((r) => r.id === requestId)) throw new Error('request missing from provider queue');
  ok(`Request appears in provider's incoming queue`);

  // 5. Provider sends a quotation
  const quotation = await call('POST', '/quotations', {
    token: provider.token,
    body: { requestId, price: 1500, message: 'I can be there within 2 hours.', estimatedDays: 1 }
  });
  ok(`Quotation sent: ${quotation.price} ETB`);

  // 6. Seeker sees and accepts it
  const quotes = await call('GET', `/quotations/for-request/${requestId}`, { token: seeker.token });
  if (quotes.length !== 1) throw new Error('seeker should see exactly one quotation');
  const booking = await call('POST', `/quotations/${quotation.id}/accept`, { token: seeker.token, body: {} });
  ok(`Quotation accepted — booking ${booking.id} created`);

  // 7. Schedule -> in progress -> complete, using a REAL open slot
  const { slots: step7Slots } = await findOpenSlot(topProviderId);
  const scheduledSlot = step7Slots[0];
  const scheduledBooking = await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'scheduled', scheduledFor: scheduledSlot }
  });
  if (scheduledBooking.scheduledFor !== scheduledSlot) throw new Error('booking scheduledFor should match the chosen slot');
  await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'in_progress' }
  });
  await call('PATCH', `/quotations/bookings/${booking.id}/status`, {
    token: provider.token,
    body: { status: 'completed' }
  });
  ok(`Booking moved through scheduled (${scheduledSlot}) → in progress → completed`);

  // 7b. Provider sets a real weekly schedule
  const scheduleUpdate = await call('PATCH', '/providers/me/schedule', {
    token: provider.token,
    body: { workingDays: ['mon', 'tue', 'wed', 'thu', 'fri', 'sat'], startTime: '08:00', endTime: '18:00', breakStart: '12:00', breakEnd: '13:00', slotMinutes: 60 }
  });
  if (scheduleUpdate.schedule.slotMinutes !== 60) throw new Error('schedule update should persist');
  ok('Provider set real working days/hours/break/slot length');

  let badScheduleRejected = false;
  try {
    await call('PATCH', '/providers/me/schedule', { token: provider.token, body: { startTime: '18:00', endTime: '09:00' } });
  } catch {
    badScheduleRejected = true;
  }
  if (!badScheduleRejected) throw new Error('opening time after closing time should be rejected');
  ok('Invalid working hours (open after close) rejected');

  // 7c. Double-booking prevention: two different seekers can't land the same slot
  const { dateStr: conflictDate, slots: conflictSlots } = await findOpenSlot(topProviderId);
  if (!conflictSlots.length) throw new Error('provider should have open slots after resetting their schedule');
  ok(`Real open slots computed for ${conflictDate} (${conflictSlots.length} available)`);
  const targetSlot = conflictSlots[Math.min(2, conflictSlots.length - 1)];

  async function bookAgainstProvider(seekerToken, label) {
    const r = await call('POST', '/requests', {
      token: seekerToken,
      body: { description: label, subcategoryKey: created.request.subcategoryKey, city: providerProfile.city, autoMatch: true }
    });
    const q = await call('POST', '/quotations', {
      token: provider.token,
      body: { requestId: r.request.id, price: 400, estimatedDays: 1, message: 'Sure, I can help.' }
    });
    return call('POST', `/quotations/${q.id}/accept`, { token: seekerToken, body: {} });
  }

  const bookingX = await bookAgainstProvider(seeker.token, 'Conflict test booking X');
  await call('PATCH', `/quotations/bookings/${bookingX.id}/status`, {
    token: provider.token,
    body: { status: 'scheduled', scheduledFor: targetSlot }
  });
  ok(`First booking locked into slot ${targetSlot}`);

  const secondSeeker = await call('POST', '/auth/register/seeker', {
    body: { fullName: 'Conflict Tester', email: `conflict${Date.now()}@example.com`, password: 'test1234', city: providerProfile.city }
  });
  const bookingY = await bookAgainstProvider(secondSeeker.token, 'Conflict test booking Y');

  let conflictBlocked = false;
  try {
    await call('PATCH', `/quotations/bookings/${bookingY.id}/status`, {
      token: provider.token,
      body: { status: 'scheduled', scheduledFor: targetSlot }
    });
  } catch {
    conflictBlocked = true;
  }
  if (!conflictBlocked) throw new Error('booking the same slot twice should be rejected with a conflict');
  ok('A second booking cannot be scheduled into an already-taken slot (double-booking blocked)');

  const slotsAfterConflict = await call('GET', `/providers/${topProviderId}/slots?date=${conflictDate}`);
  if (slotsAfterConflict.slots.includes(targetSlot)) throw new Error('a taken slot should no longer appear as open');
  ok('Taken slot correctly disappears from the open-slots list');

  const reslot = slotsAfterConflict.slots[0];
  await call('PATCH', `/quotations/bookings/${bookingY.id}/status`, {
    token: provider.token,
    body: { status: 'scheduled', scheduledFor: reslot }
  });
  ok(`Second booking scheduled into a genuinely open slot instead (${reslot})`);

  // 8. Seeker reviews, trust score recalculates
  const review = await call('POST', '/reviews', {
    token: seeker.token,
    body: { bookingId: booking.id, rating: 5, comment: 'Fast, clean work and fair price.' }
  });
  ok(`Review saved — trust score recalculated ${trustBefore} → ${review.newTrustScore}`);
  ok(`  breakdown: ${review.breakdown.completedJobs} jobs, avg rating ${review.breakdown.avgRating}, ${review.breakdown.completionRate}% completion`);

  // 9. Notifications reached both sides
  const providerNotifs = await call('GET', '/notifications', { token: provider.token });
  const seekerNotifs = await call('GET', '/notifications', { token: seeker.token });
  if (!providerNotifs.length || !seekerNotifs.length) throw new Error('notifications missing');
  ok(`Notifications delivered — provider: ${providerNotifs.length}, seeker: ${seekerNotifs.length}`);

  // 10. Messaging between the two parties
  const msg = await call('POST', '/messages', {
    token: seeker.token,
    body: { requestId, toUserId: providerUser.id, body: 'Thanks, the leak is fully fixed.' }
  });
  const thread = await call('GET', `/messages?requestId=${requestId}`, { token: provider.token });
  if (!thread.find((m) => m.id === msg.id)) throw new Error('message not visible to provider');
  ok('Messaging works in both directions');

  // 11. Admin portal
  const admin = await call('POST', '/auth/login', {
    body: { email: 'admin@omniservice.center', password: 'demo1234' }
  });
  const stats = await call('GET', '/admin/stats', { token: admin.token });
  ok(`Admin stats — ${stats.providers.verified} verified providers, ${stats.activity.completedJobs} completed jobs, ${stats.financial.platformCommission} ETB commission`);

  const pending = await call('GET', '/admin/providers?status=pending', { token: admin.token });
  ok(`Verification queue: ${pending.length} pending applications`);

  if (pending.length) {
    const before = pending[0].status;
    await call('PATCH', `/admin/providers/${pending[0].id}/verify`, {
      token: admin.token,
      body: { decision: 'verified', note: 'Documents check out.' }
    });
    ok(`Admin verified a provider (${before} → verified)`);
  }

  const companyReport = await call('GET', '/admin/reports/companies', { token: admin.token });
  const userReport = await call('GET', '/admin/reports/users', { token: admin.token });
  ok(`Reports generated — ${companyReport.length} company rows, ${userReport.length} user rows`);

  // 12. Access control actually blocks
  let blocked = false;
  try {
    await call('GET', '/admin/stats', { token: seeker.token });
  } catch {
    blocked = true;
  }
  if (!blocked) throw new Error('seeker should NOT be able to read admin stats');
  ok('Role-based access control blocks seekers from the admin portal');

  // 13. New provider registration lands in pending, not verified
  const reg = await call('POST', '/auth/register/provider', {
    body: {
      fullName: 'Test Applicant',
      email: `test${Date.now()}@example.com`,
      password: 'test1234',
      businessName: 'Test Electrical Co.',
      subcategoryKeys: ['electrical'],
      categoryKey: 'home_construction',
      city: 'Gondar'
    }
  });
  if (reg.provider.status !== 'pending') throw new Error('new provider should start as pending');
  ok('New provider registration starts as pending, invisible in search until verified');

  // 14. Payment methods catalogue
  const methods = await call('GET', '/payments/methods');
  if (methods.mode !== 'sandbox') throw new Error('payments should run in sandbox mode');
  const methodKeys = methods.methods.map((m) => m.key);
  ['telebirr', 'cbe_birr', 'bank_transfer', 'paypal', 'card'].forEach((k) => {
    if (!methodKeys.includes(k)) throw new Error(`payment method ${k} missing from catalogue`);
  });
  ok(`Payment methods available: ${methodKeys.join(', ')} (mode: ${methods.mode})`);

  // 15. Seeker pays for their booking via Telebirr
  const payInit = await call('POST', '/payments/initiate', {
    token: seeker.token,
    body: { purpose: 'booking', bookingId: booking.id, method: 'telebirr', details: { phone: '0912345678' } }
  });
  if (payInit.status !== 'pending') throw new Error('payment should start pending');
  const payConfirm = await call('POST', `/payments/${payInit.id}/confirm`, { token: seeker.token });
  if (payConfirm.status !== 'succeeded') throw new Error('payment should confirm to succeeded');
  ok(`Booking paid via Telebirr — reference ${payConfirm.reference}, ${payConfirm.amount} ${payConfirm.currency}`);

  const bookingsAfterPay = await call('GET', '/quotations/bookings/mine', { token: seeker.token });
  const paidBooking = bookingsAfterPay.find((b) => b.id === booking.id);
  if (!paidBooking || paidBooking.paymentStatus !== 'paid') throw new Error('booking should show paymentStatus paid');
  ok('Booking record reflects paymentStatus = paid');

  let doublePayBlocked = false;
  try {
    await call('POST', '/payments/initiate', {
      token: seeker.token,
      body: { purpose: 'booking', bookingId: booking.id, method: 'card', details: { cardNumber: '4242424242424242', expiry: '09/29', cvv: '123', name: 'Test Seeker' } }
    });
  } catch {
    doublePayBlocked = true;
  }
  if (!doublePayBlocked) throw new Error('a second payment on an already-paid booking should be rejected');
  ok('Duplicate payment on an already-paid booking is rejected');

  let badCardBlocked = false;
  try {
    await call('POST', '/payments/initiate', {
      token: seeker.token,
      body: { purpose: 'promotion', tier: 'boosted', method: 'card', details: { cardNumber: '1234', expiry: '09/29', cvv: '123', name: 'x' } }
    });
  } catch {
    badCardBlocked = true;
  }
  if (!badCardBlocked) throw new Error('an invalid card number should fail Luhn validation');
  ok('Invalid card number is rejected by Luhn validation');

  const myPayments = await call('GET', '/payments/mine', { token: seeker.token });
  if (!myPayments.find((p) => p.id === payInit.id)) throw new Error('payment missing from seeker payment history');
  ok(`Seeker payment history contains ${myPayments.length} transaction(s)`);

  // 16. Provider buys promotion
  const promoInit = await call('POST', '/payments/initiate', {
    token: provider.token,
    body: { purpose: 'promotion', tier: 'boosted', method: 'cbe_birr', details: { phone: '0911223344' } }
  });
  const promoConfirm = await call('POST', `/payments/${promoInit.id}/confirm`, { token: provider.token });
  if (promoConfirm.status !== 'succeeded') throw new Error('promotion payment should succeed');
  const profileAfterPromo = await call('GET', '/providers/me/profile', { token: provider.token });
  if (!profileAfterPromo.activePromotions.some((a) => a.tier === 'boosted')) {
    throw new Error('boosted promotion should be active after payment');
  }
  ok('Provider purchased "Boosted listing" promotion via CBE Birr — now active');

  // 17. Admin sees every transaction
  const paymentsReport = await call('GET', '/admin/reports/payments', { token: admin.token });
  if (paymentsReport.length < 2) throw new Error('admin payments report should include both transactions');
  const adminStats2 = await call('GET', '/admin/stats', { token: admin.token });
  if (adminStats2.payments.succeeded < 2) throw new Error('admin stats should count succeeded payments');
  ok(`Admin payments report: ${paymentsReport.length} transactions, ${adminStats2.payments.totalCollected} ETB collected`);

  // 18. Provider offerings — products & services showcase
  const offering = await call('POST', '/providers/me/offerings', {
    token: provider.token,
    body: { type: 'service', name: 'Emergency pipe repair', description: 'Same-day callout.', price: 900, unit: 'visit' }
  });
  ok(`Provider added an offering: ${offering.name} (${offering.price} ETB/${offering.unit})`);

  const updatedOffering = await call('PATCH', `/providers/me/offerings/${offering.id}`, {
    token: provider.token,
    body: { price: 950 }
  });
  if (updatedOffering.price !== 950) throw new Error('offering price should update');
  ok('Offering price updated');

  const publicOfferings = await call('GET', `/providers/${topProviderId}/offerings`);
  if (!publicOfferings.find((o) => o.id === offering.id)) throw new Error('offering should be visible on public provider profile');
  ok(`Offering visible on public profile (${publicOfferings.length} listed)`);

  await call('DELETE', `/providers/me/offerings/${offering.id}`, { token: provider.token });
  const afterDelete = await call('GET', `/providers/${topProviderId}/offerings`);
  if (afterDelete.find((o) => o.id === offering.id)) throw new Error('offering should be removed after delete');
  ok('Offering removed');

  // 19. Profile pictures for both roles
  const tinyPng =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
  const seekerMe = await call('PATCH', '/auth/me', { token: seeker.token, body: { avatarUrl: tinyPng, bio: 'Homeowner in Gondar.' } });
  if (seekerMe.user.avatarUrl !== tinyPng) throw new Error('seeker avatar should be saved');
  ok('Seeker profile picture and bio saved');

  const providerMe = await call('PATCH', '/providers/me/profile', { token: provider.token, body: { avatarUrl: tinyPng } });
  if (providerMe.avatarUrl !== tinyPng) throw new Error('provider avatar should be saved');
  ok('Provider profile picture saved');

  // 20. Favorites — seekers can save and unsave providers
  const favAdd = await call('POST', `/favorites/${topProviderId}`, { token: seeker.token });
  if (favAdd.providerId !== topProviderId) throw new Error('favorite should reference the provider');
  ok('Seeker saved a provider to favorites');

  let dupFavBlocked = false;
  try {
    await call('POST', `/favorites/${topProviderId}`, { token: seeker.token });
  } catch {
    dupFavBlocked = true;
  }
  if (!dupFavBlocked) throw new Error('favoriting the same provider twice should be rejected');
  ok('Duplicate favorite is rejected');

  const favList = await call('GET', '/favorites/mine', { token: seeker.token });
  if (!favList.find((f) => f.providerId === topProviderId)) throw new Error('favorite should appear in the list');
  if (!favList[0].provider || !favList[0].provider.businessName) throw new Error('favorite should be enriched with live provider details');
  ok(`Favorites list returns ${favList.length} saved provider(s), enriched with live provider data`);

  await call('DELETE', `/favorites/${topProviderId}`, { token: seeker.token });
  const favListAfter = await call('GET', '/favorites/mine', { token: seeker.token });
  if (favListAfter.find((f) => f.providerId === topProviderId)) throw new Error('favorite should be removed');
  ok('Favorite removed');

  console.log('\nAll checks passed.\n');
})().catch((e) => {
  console.error('\n  FAIL  ' + e.message + '\n');
  process.exit(1);
});
