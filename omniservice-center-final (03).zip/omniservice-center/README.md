# OMNISERVICE CENTER

**Every Service. One Smart Center.**

An AI-powered service marketplace for Ethiopia. A seeker describes a job in plain
language; OMNI works out which service it is, where they are and how urgent it is,
then ranks verified providers by trust score, distance, availability and price.

Built by Abrham Kefyalew and Solomon for the Gondar University STEM Center Local
Science Fair, Digital Technology & Software Development category.

---

## Running it

You need [Node.js](https://nodejs.org) 18 or newer. Check with `node --version`.

```bash
npm install
npm start
```

Then open **http://localhost:3000**

That's it. The database seeds itself on first boot — no database server to install,
no build step, no configuration.

To reset the data back to a clean demo state at any time:

```bash
npm run seed
```

### Demo accounts

Password for all three is `demo1234`.

| Role | Email |
|---|---|
| Service Seeker | `seeker1@omniservice.center` |
| Service Provider | `provider1@omniservice.center` |
| Admin | `admin@omniservice.center` |

These aren't advertised in the app itself (a real product shouldn't put demo
credentials in front of real users), but they still work for local testing.

### Does it need internet?

Almost none of it. Fonts and the mapping library are bundled in the project, and the
backend runs locally. The **only** thing that needs a connection is the map's
background imagery, which streams from OpenStreetMap. If there's no connection, the
map says so plainly and still shows every provider's position and the ranked list
beside it.

---

## Demo script for judges

Roughly five minutes, and it shows every major piece.

**1. The landing page runs the real engine.** Type anything into the "Ask OMNI" box
on the right — or click one of the example questions. Then open "How OMNI got there"
underneath the answer. It shows the words it matched on, the city and timing it
detected, and how many providers it scored. Type something unusual to prove it isn't
scripted; type nonsense and it will say it couldn't match rather than inventing a result.

**2. Sign in as the Service Seeker** and go to **AI Agent**. Ask for something, then
press **Request** on one of the ranked providers. Fill in the request and post it.
The provider is notified immediately.

**3. Sign out, sign in as the Service Provider.** The request you just posted is
sitting in their incoming queue. Send a quotation with a price.

**4. Sign back in as the Seeker.** The quotation is on the request, showing the
provider's trust score. Accept it — the job is now booked, and the progress bar
moves along the lifecycle.

**5. Back as the Provider,** open **Confirm schedule** — this opens a real date
picker that calls the provider's own live availability, and only lets you pick a
slot that's actually open. Then move the job through *Start job → Mark complete*.

**6. As the Seeker,** leave a review. The toast tells you the provider's new trust
score. **This is the point worth making to judges:** the score is calculated, not
stored — that one review just changed where that provider ranks in every future search.

**7. Sign in as Admin.** The Overview totals are computed from real records. Go to
**Verification** and approve a pending provider — they were invisible in search until
that moment. **Reports → Payments** shows every sandbox transaction on the platform.
**Reports** exports real CSVs.

**8. Pay for the booking.** Back as the Seeker, the accepted booking now shows a
**Pay now** button. Choose Telebirr, CBE Birr, an Ethiopian bank, PayPal or a card —
each validates realistically (try an invalid card number) — and confirm to see a
receipt. It's sandboxed end to end, so nothing real is ever charged.

---

## How it's built

```
server.js              Express server — mounts the API and serves the frontend
src/
  db.js                JSON-persisted datastore with a collection API
  omni.js              The OMNI matching engine
  trustScore.js        Trust score calculation
  availability.js      Provider scheduling engine — open slots + conflict checks
  payments.js          Payment method catalogue + sandbox processor
  seed.js              Demo dataset generator
  middleware.js        JWT auth and role guards
  routes/              auth, categories, providers, requests,
                       quotations, reviews, omni, inbox, payments, favorites, admin
  data/db.json         The database file (created on first run)
public/
  index.html
  css/                 base, app, components, fonts
  js/                  api, payment, landing, seeker, provider, admin, app
  vendor/              Leaflet and the fonts, bundled for offline use
test-flow.js           End-to-end test of the whole service lifecycle
ui-check.js            Browser test — drives every screen, catches JS errors
```

**Backend:** Node and Express. Passwords hashed with bcrypt, sessions via JWT.
Data lives in a JSON file through `src/db.js`, which exposes `find`, `filter`,
`insert`, `update` and `remove`. Every route goes through those functions and never
touches the file directly, so swapping in PostgreSQL or MongoDB later means
rewriting one module rather than the whole API.

**Frontend:** plain JavaScript, no framework and no build step. `public/js/api.js` is
the only file that knows the server exists; every screen calls it. Views are plain
objects with a `render` method, and a small history-based router picks which one runs
and enforces that a signed-in user can only enter their own stream.

---

## How OMNI actually works

It is real code in `src/omni.js`, not a chatbot wrapper and not a set of canned
replies. Every request is parsed fresh:

1. **Intent.** Each of the 26 services has a synonym list covering how people
   actually describe the problem — "pipe", "leak", "faucet", "drain" all point at
   plumbing. Multi-word phrases score higher than single words, because "water heater"
   is a stronger signal than "water".
2. **Location.** City names and their common alternate spellings — Gondar/Gonder,
   Bahir Dar/Bahirdar — are matched out of the text.
3. **Timing.** "today", "urgent", "this week", "next week" become an urgency level.
4. **Ranking.** Every verified provider in the matched service is scored on trust
   score (weighted heaviest), city match, real distance by the haversine formula,
   availability against the detected urgency, price level, and review volume.

The interface then shows the reasoning behind the ranking, so the result can be
checked rather than taken on faith. When nothing matches confidently, it says so
instead of guessing.

## Profiles and offerings

Both seekers and providers can set a profile picture (compressed client-side before
upload, so the JSON datastore never has to hold a full-resolution photo). Providers
can additionally list the products or services they offer — name, description, price
and a photo each — which show up as a gallery on their public profile, alongside the
existing bio, trust score and reviews.

## How availability works

`src/availability.js` is the whole scheduling engine, and it's the single place both
the "what's open" view and the "is this actually still open" check go through — so
they can never drift apart. Each provider sets:

- **Working days** — any combination of the week
- **Opening and closing time**
- **An optional break window**
- **Appointment length** — 15 to 120 minutes

From that, `GET /api/providers/:id/slots?date=YYYY-MM-DD` generates the real open
slots for that day: it walks the working hours in appointment-length steps, drops
anything inside the break, drops anything already in the past, and — critically —
drops anything that overlaps a booking this provider already holds (any booking that
is accepted, scheduled, or in progress). A seeker sees this live on a provider's
profile before ever sending a request. A provider sees the same thing, scoped to
their own calendar, when confirming or rescheduling a job.

Because generation and validation are the same function, a booking can only be
confirmed into a slot this endpoint would currently return — `PATCH
/api/quotations/bookings/:id/status` re-derives the open slots for that date and
rejects (409) anything that isn't in that list, whether the conflict is a full
working day, a break, or another booking that landed there first. Two seekers can
never be confirmed into the same appointment, and a reschedule excludes the booking's
own existing slot from that check so it doesn't conflict with itself.

## Favorites

Seekers can save a provider from their profile or from any provider card
(`POST`/`DELETE /api/favorites/:providerId`), and see everything they've saved on
their Home dashboard (`GET /api/favorites/mine`, returned already joined with the
live provider record — no separate lookup needed on the frontend).

## How the trust score works

In `src/trustScore.js`, computed from records rather than set by hand:

| Signal | Weight |
|---|---|
| Average review rating | 40% |
| Completion rate (finished vs cancelled) | 25% |
| Response time to requests | 20% |
| Job volume, capped so newcomers can compete | 15% |
| Cancellations | subtracted |

It recalculates the moment a review is submitted or a job completes.

---

## How payments work

`src/payments.js` is a real, extensible payment architecture — a method registry,
real per-method validation, and a two-step initiate → confirm flow that mirrors how
Telebirr, CBE Birr, bank transfer, PayPal and card processing actually work (push a
prompt or redirect, then confirm on the return leg). It supports:

- **Telebirr** and **CBE Birr** — validated against real Ethiopian mobile number formats
- **Ethiopian bank transfer** — Commercial Bank of Ethiopia, Bank of Abyssinia, Dashen,
  Awash, Hibret, Wegagen, Nib International
- **PayPal** and **Debit/credit card (Visa & Mastercard)** — card numbers are checked
  with a real Luhn checksum, and expiry dates are validated

None of these are wired to a live gateway — there are no Telebirr, CBE, PayPal or
card-network API keys configured anywhere in this project — so every transaction runs
in `PAYMENT_MODE = 'sandbox'` and is labelled as such everywhere it appears in the UI.
Swapping one method to a real gateway later means implementing that method's
`process()` function against the real API; the routes, the receipt model and the UI
never need to change. Seekers pay for bookings, and providers buy promotion, through
the same shared modal (`public/js/payment.js`); every transaction is visible in the
payer's history and in the admin **Reports → Payments** tab.

---

## Testing

With the server running in one terminal:

```bash
node test-flow.js    # 48 checks across the whole lifecycle
node test-promos.js  # 10 checks for server-side deals and adverts
node ui-check.js     # drives all screens in a real browser
```

`test-flow.js` covers the full path — OMNI parsing, posting a request, matching,
quoting, accepting, scheduling into a real open slot, completing, reviewing,
trust-score recalculation, notifications, messaging, admin stats, verification,
reports, sandbox payments (including a duplicate-payment block and Luhn card
validation), provider offerings, profile pictures, provider scheduling (including
rejecting invalid working hours), double-booking prevention across two independent
seekers, and favorites (save, duplicate rejection, list, remove) — and confirms a
seeker is blocked from admin routes and that new providers start unverified.

`ui-check.js` needs Puppeteer (`npm install puppeteer`). It clicks through every
screen and fails if any JavaScript error appears.

---

## About the data

Providers, reviews and job history in this build are **generated demo data**, and are
labelled "Demo data" everywhere they appear. No real business, review, statistic,
government partnership or support channel is presented as real. The trust scores are
genuinely computed from the seeded job history rather than typed in, which is why they
move when you complete a job during the demo.

Provider coordinates are placed around real Ethiopian cities — Gondar, Bahir Dar,
Addis Ababa, Mekelle, Hawassa, Dire Dawa and Adama — with every service guaranteed at
least two verified providers in Gondar, so any search a judge tries in the home city
returns a real ranked comparison.

## Deals, adverts and language

**Deals and adverts** are stored on the server (`src/routes/promos.js`, collection `promos`).
A provider creates them under *Service Deal* / *Advertisement*. Active deals appear on the
provider's public profile; an expired deal is hidden automatically. An advert is shown
labelled **Sponsored**, and only once the provider is verified. Checks are in `node test-promos.js`.

**Amharic / English.** The **አማርኛ / English** button (landing page and every dashboard's top
bar) switches the navigation, role names, sign-in buttons and the landing headline. Everything
else is still English. The Amharic wording should be reviewed by a native speaker before the fair.

## Not built yet

Full-app Amharic translation (forms, dashboards, OMNI answers). Provider document upload is
stubbed at the data model; admins approve based on the submitted details. Payments run in
sandbox mode only — see **How payments work** above.
