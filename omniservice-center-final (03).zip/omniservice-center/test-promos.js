// test-promos.js — server-side deals & adverts. Run with the server up: node test-promos.js
const B = 'http://localhost:' + (process.env.PORT || 3000) + '/api';
let fails = 0;
const ok = (c, m) => { console.log((c ? '  PASS  ' : '  FAIL  ') + m); if (!c) fails++; };
const call = async (m, p, body, tok) => {
  const r = await fetch(B + p, { method: m, headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { s: r.status, j: await r.json().catch(() => ({})) };
};
(async () => {
  const login = async (e) => (await call('POST', '/auth/login', { email: e, password: 'demo1234' })).j.token;
  const prov = await login('provider1@omniservice.center'), seek = await login('seeker1@omniservice.center');
  const me = (await call('GET', '/providers/me/profile', null, prov)).j;
  const deal = await call('POST', '/promos', { type: 'deal', title: 'Test deal', service: 'Plumbing', discount: 20, until: '2099-01-01' }, prov);
  ok(deal.s === 201, 'Provider created a deal on the server');
  ok((await call('POST', '/promos', { type: 'deal', title: 'x', discount: 95 }, prov)).s === 400, 'Discount over 90% rejected');
  ok((await call('POST', '/promos', { type: 'deal', title: 'Old', discount: 10, until: '2020-01-01' }, prov)).s === 201, 'Expired deal accepted (stored)');
  ok((await call('POST', '/promos', { type: 'ad', headline: 'Same-day repairs', body: 'Call us' }, prov)).s === 201, 'Provider created an advert');
  ok((await call('POST', '/promos', { type: 'ad', headline: 'x' }, seek)).s === 403, 'Seeker cannot create promos');
  const pub = (await call('GET', '/promos/provider/' + me.id)).j;
  ok(pub.deals.some((d) => d.title === 'Test deal'), 'Public profile shows the live deal');
  ok(!pub.deals.some((d) => d.title === 'Old'), 'Expired deal is hidden publicly');
  ok(pub.ads.some((a) => a.headline === 'Same-day repairs'), 'Verified provider advert shown as sponsored');
  const mine = (await call('GET', '/promos/mine?type=deal', null, prov)).j;
  ok(mine.length >= 2 && mine.every((x) => x.type === 'deal'), 'Provider lists only own deals');
  for (const x of (await call('GET', '/promos/mine', null, prov)).j) await call('DELETE', '/promos/' + x.id, null, prov);
  ok((await call('GET', '/promos/mine', null, prov)).j.length === 0, 'Deals and adverts removed');
  console.log(fails ? `\n${fails} FAILED` : '\nAll promo checks passed.');
  process.exit(fails ? 1 : 0);
})();
